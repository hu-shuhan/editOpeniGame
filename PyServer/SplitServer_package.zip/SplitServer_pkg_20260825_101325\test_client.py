"""
P3-SAM 客户端测试脚本
用于测试服务器是否正常工作
"""
import socket
import struct
import sys


def test_p3sam_server(obj_path, output_vtk, host='127.0.0.1', port=8765):
    """测试P3-SAM服务器"""
    print(f"Connecting to {host}:{port}...")
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(60)  # 60秒超时

    try:
        sock.connect((host, port))
        print("Connected")

        # 读取OBJ文件
        with open(obj_path, 'rb') as f:
            obj_data = f.read()
        print(f"OBJ file size: {len(obj_data)} bytes")

        # 发送参数
        post_process = True

        print(f"Sending request: post_process={post_process}")
        sock.sendall(struct.pack('B', 1 if post_process else 0))

        # 发送OBJ数据
        sock.sendall(struct.pack('<I', len(obj_data)))
        sock.sendall(obj_data)
        print("Request sent, waiting for response...")

        # 接收响应
        success = struct.unpack('B', recv_exact(sock, 1))[0]

        if success == 0:
            # 失败，接收错误消息
            msg_size = struct.unpack('<I', recv_exact(sock, 4))[0]
            error_msg = recv_exact(sock, msg_size).decode('utf-8')
            print(f"Server returned error:\n{error_msg}")
            return False

        # 成功，接收VTK数据
        vtk_size = struct.unpack('<I', recv_exact(sock, 4))[0]
        print(f"Receiving VTK data: {vtk_size} bytes")
        vtk_data = recv_exact(sock, vtk_size)

        # 保存VTK文件
        with open(output_vtk, 'wb') as f:
            f.write(vtk_data)

        print(f"Success! VTK saved to {output_vtk}")
        return True

    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        sock.close()


def recv_exact(sock, size):
    """接收指定字节数"""
    data = b''
    while len(data) < size:
        chunk = sock.recv(size - len(data))
        if not chunk:
            raise ConnectionError("Connection closed")
        data += chunk
    return data


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python test_client.py <input.obj> <output.vtk> [host] [port]")
        sys.exit(1)

    obj_path = sys.argv[1]
    output_vtk = sys.argv[2]
    host = sys.argv[3] if len(sys.argv) > 3 else '127.0.0.1'
    port = int(sys.argv[4]) if len(sys.argv) > 4 else 8765

    success = test_p3sam_server(obj_path, output_vtk, host, port)
    sys.exit(0 if success else 1)
