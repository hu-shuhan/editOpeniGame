"""
P3-SAM 分割服务器
接收OBJ文件，返回VTK分割结果
"""
import os
import sys
import signal

# 添加CUDA DLL路径
if sys.platform == 'win32':
    cuda_paths = [
        'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v12.1/bin',
        'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin',
        'D:/Anaconda/envs/p3sam/Library/bin',
    ]
    for path in cuda_paths:
        if os.path.exists(path):
            os.add_dll_directory(path)

import socket
import struct
import tempfile
import traceback

if '--allow-online' not in sys.argv:
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['HF_HUB_DISABLE_XET'] = '1'

import trimesh
import meshio
import numpy as np
from auto_mask import AutoMask


class P3SAMServer:
    def __init__(self, host='0.0.0.0', port=8765, ckpt_path=None,
                 point_num=10000, prompt_num=250, seed=42):
        self.host = host
        self.port = port
        self.ckpt_path = ckpt_path
        self.point_num = point_num
        self.prompt_num = prompt_num
        self.seed = seed
        self.automask = None
        self.running = True

        # 设置信号处理
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    def _signal_handler(self, signum, frame):
        """处理Ctrl+C等信号"""
        print("\nReceived signal, shutting down gracefully...")
        self.running = False

    def load_model(self):
        """加载P3-SAM模型"""
        print("Loading P3-SAM model...")
        self.automask = AutoMask(self.ckpt_path, point_num=self.point_num, prompt_num=self.prompt_num)
        print("Model loaded successfully")

    def process_request(self, client_socket):
        """处理单个客户端请求"""
        try:
            # 接收参数: post_process
            post_process = struct.unpack('B', self._recv_exact(client_socket, 1))[0] != 0

            print(f"Request: point_num={self.point_num}, prompt_num={self.prompt_num}, seed={self.seed}, post_process={post_process}")

            # 接收OBJ数据
            obj_size = struct.unpack('<I', self._recv_exact(client_socket, 4))[0]
            print(f"Receiving OBJ data: {obj_size} bytes")
            obj_data = self._recv_exact(client_socket, obj_size)

            # 保存临时OBJ文件
            with tempfile.NamedTemporaryFile(suffix='.obj', delete=False) as tmp_obj:
                tmp_obj.write(obj_data)
                tmp_obj_path = tmp_obj.name

            try:
                # 加载mesh
                mesh = trimesh.load(tmp_obj_path, force='mesh', process=False)
                print(f"Loaded mesh: {len(mesh.vertices)} vertices, {len(mesh.faces)} faces")

                # 执行分割
                print("Running P3-SAM segmentation...")
                aabb, face_ids, mesh = self.automask.predict_aabb(
                    mesh,
                    point_num=self.point_num,
                    prompt_num=self.prompt_num,
                    seed=self.seed,
                    is_parallel=False,
                    post_process=post_process,
                    prompt_bs=8
                )

                # 重映射face_ids为连续整数
                unique_ids = sorted([i for i in np.unique(face_ids) if i >= 0])
                id_map = {old: new for new, old in enumerate(unique_ids)}
                remapped = np.array([id_map[i] if i >= 0 else -1 for i in face_ids], dtype=np.int64)

                print(f"Segmentation complete: {len(unique_ids)} parts")

                # 生成VTK
                meshio_mesh = meshio.Mesh(
                    points=mesh.vertices,
                    cells=[("triangle", mesh.faces)],
                    cell_data={"part_id": [remapped]},
                )

                # 保存临时VTK文件
                with tempfile.NamedTemporaryFile(suffix='.vtk', delete=False) as tmp_vtk:
                    tmp_vtk_path = tmp_vtk.name

                meshio_mesh.write(tmp_vtk_path, file_format='vtk')

                # 读取VTK数据
                with open(tmp_vtk_path, 'rb') as f:
                    vtk_data = f.read()

                print(f"VTK data size: {len(vtk_data)} bytes")

                # 发送成功响应
                client_socket.sendall(struct.pack('B', 1))  # success = 1
                client_socket.sendall(struct.pack('<I', len(vtk_data)))
                client_socket.sendall(vtk_data)

                # 清理临时文件
                os.unlink(tmp_vtk_path)

            finally:
                os.unlink(tmp_obj_path)

        except Exception as e:
            error_msg = f"Error: {str(e)}\n{traceback.format_exc()}"
            print(error_msg)
            try:
                # 发送失败响应
                client_socket.sendall(struct.pack('B', 0))  # success = 0
                error_bytes = error_msg.encode('utf-8')
                client_socket.sendall(struct.pack('<I', len(error_bytes)))
                client_socket.sendall(error_bytes)
            except:
                pass

    def _recv_exact(self, sock, size):
        """接收指定字节数"""
        data = b''
        while len(data) < size:
            chunk = sock.recv(size - len(data))
            if not chunk:
                raise ConnectionError("Connection closed")
            data += chunk
        return data

    def run(self):
        """启动服务器"""
        self.load_model()

        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.settimeout(1.0)  # 1秒超时，使accept()可被中断
        server_socket.bind((self.host, self.port))
        server_socket.listen(5)

        print(f"P3-SAM Server listening on {self.host}:{self.port}")
        print("Press Ctrl+C to stop the server.")

        try:
            while self.running:
                try:
                    client_socket, addr = server_socket.accept()
                except socket.timeout:
                    continue  # 超时后检查running标志
                print(f"Client connected from {addr}")
                try:
                    self.process_request(client_socket)
                    print("Request processed successfully")
                except Exception as e:
                    print(f"Error processing request: {e}")
                finally:
                    client_socket.close()
        finally:
            server_socket.close()
            print("Server stopped.")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='0.0.0.0', help='Server host')
    parser.add_argument('--port', type=int, default=8765, help='Server port')
    parser.add_argument('--ckpt_path', default=None, help='Model checkpoint path')
    parser.add_argument('--point_num', type=int, default=10000, help='Number of sampled points')
    parser.add_argument('--prompt_num', type=int, default=250, help='Number of prompt points')
    parser.add_argument('--seed', type=int, default=42, help='Random seed')
    parser.add_argument('--allow-online', action='store_true',
                        help='Allow HuggingFace downloads (disables offline mode)')
    args = parser.parse_args()

    server = P3SAMServer(args.host, args.port, args.ckpt_path,
                         args.point_num, args.prompt_num, args.seed)
    server.run()
