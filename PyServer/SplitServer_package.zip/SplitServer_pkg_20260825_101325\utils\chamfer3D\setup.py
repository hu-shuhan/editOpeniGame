from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

setup(
    name='chamfer_3D',
    ext_modules=[
        CUDAExtension('chamfer_3D', [
            "/".join(__file__.split('/')[:-1] + ['chamfer_cuda.cpp']),
            "/".join(__file__.split('/')[:-1] + ['chamfer3D.cu']),
        ],
        extra_compile_args={
            'nvcc': ['-allow-unsupported-compiler', '-Xcompiler', '/Zc:preprocessor', '-D_ALLOW_COMPILER_AND_STL_VERSION_MISMATCH'],
            'cxx': ['/Zc:preprocessor', '/D_ALLOW_COMPILER_AND_STL_VERSION_MISMATCH']
        }),
    ],
    cmdclass={
        'build_ext': BuildExtension
    })