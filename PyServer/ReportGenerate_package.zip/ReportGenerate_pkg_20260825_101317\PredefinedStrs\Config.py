# A文件夹下的常量文件（简化版）
import os

# 数据库名
CAE_COLLECTION = "CAE_COLLECTION" # 普通的CAE
CAE_REPORT_COLLECTION = "CAE_REPORT_COLLECTION" # CAE报告
SIMULATION_ANALYSIS_COLLECTION = "SIMULATION_ANALYSIS_COLLECTION"

# Embedding模型相关配置
EMBEDDING_API_BASE_URL = "https://api.nuwaapi.com/v1"
EMBEDDING_API_KEY = "sk-jYrjDnqiZ894oHHkJlmtKTsCP4L4RJCz0o7isE5oJ4vZJ90S"
EMBEDDING_MODEL = "text-embedding-3-small"

# 对话模型相关配置
CHAT_API_BASE_URL = "https://api.nuwaapi.com/v1"
CHAT_API_KEY = "sk-jYrjDnqiZ894oHHkJlmtKTsCP4L4RJCz0o7isE5oJ4vZJ90S"
# CHAT_MODEL = "gpt-4o-mini"  #下面那些太贵了
CHAT_MODEL = "gpt-5-mini" # 这个效果会好很多
# CHAT_MODEL = "gpt-5-pro" 
# CHAT_MODEL = "gemini-3-pro-image-preview" 
# CHAT_MODEL = "gemini-3-pro-preview"
# CHAT_MODEL = "gemini-2.5-pro"

# 图片模型相关配置
IMG_API_BASE_URL = "https://api.nuwaapi.com/v1"
IMG_API_KEY = "sk-jYrjDnqiZ894oHHkJlmtKTsCP4L4RJCz0o7isE5oJ4vZJ90S"
IMG_MODEL = "gpt-4o-mini"

# Postgre SQL 相关配置
POSTGRESQL_HOST = "localhost"
POSTGRESQL_PORT = 5432
POSTGRESQL_DB = "IGAMEVISRAGSQLDB"
POSTGRESQL_USER = "IGAMEUSER"
POSTGRESQL_PASSWORD = "IGAMEVISSQLPASSWORD"

# 项目路径相关常量
# 注意：这里假设A文件夹在项目根目录下
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHROMADB_DIR = os.path.join(PROJECT_ROOT, "Chromadb")
IMG_DIR = os.path.join(PROJECT_ROOT, "Images")
KNOWLEDGE_FILE_DIR = os.path.join(PROJECT_ROOT, "KnowledgeFiles")
MEMORY_DB_PATH = os.path.join(PROJECT_ROOT, "memory.db")