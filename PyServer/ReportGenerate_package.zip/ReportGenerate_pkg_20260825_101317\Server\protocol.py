# ============================================================================
# MeshReport TCP 协议编解码
#
# 与 C++ 端 iGameMeshReportClient.cpp 的 requestReport() 严格对应：
#   发送: [4B vtk_size][vtk_data]
#   接收: [1B success][4B report_size][report_data] 或 [1B=0][4B msg_size][error_msg]
#
# 属性过滤在 C++ 端完成（传输的 VTK 只含 part_id 与选中的属性），
# 服务器直接分析收到的全部属性，协议中不再携带字段名列表。
#
# uint32 按小端（与 x86/x64 上 C++ reinterpret_cast<const char*>(&value) 的内存布局一致）。
# ============================================================================

import socket
import struct
from typing import Tuple

_UINT32 = struct.Struct("<I")


def recv_exact(sock: socket.socket, size: int) -> bytes:
    """从 socket 精确读取 size 字节，连接提前关闭时抛出 ConnectionError"""
    chunks = []
    remaining = size
    while remaining > 0:
        chunk = sock.recv(remaining)
        if not chunk:
            raise ConnectionError("Connection closed while receiving data")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def send_all(sock: socket.socket, data: bytes) -> None:
    sock.sendall(data)


def recv_uint32(sock: socket.socket) -> int:
    return _UINT32.unpack(recv_exact(sock, 4))[0]


def send_uint32(sock: socket.socket, value: int) -> None:
    send_all(sock, _UINT32.pack(value))


def recv_data(sock: socket.socket) -> bytes:
    """读取 [4B size][data] 格式的定长数据块"""
    size = recv_uint32(sock)
    return recv_exact(sock, size)


def send_data(sock: socket.socket, data: bytes) -> None:
    """写入 [4B size][data] 格式的定长数据块"""
    send_uint32(sock, len(data))
    send_all(sock, data)


def recv_request(sock: socket.socket) -> Tuple[bytes]:
    """读取一次完整的 MeshReportRequest，返回 (vtk_data,)"""
    vtk_data = recv_data(sock)
    return (vtk_data,)


def send_success(sock: socket.socket, report_data: bytes) -> None:
    send_all(sock, bytes([1]))
    send_data(sock, report_data)


def send_error(sock: socket.socket, error_message: str) -> None:
    send_all(sock, bytes([0]))
    send_data(sock, error_message.encode("utf-8"))
