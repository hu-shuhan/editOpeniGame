# ============================================================================
# MeshReport TCP 服务器
#
# 与 C++ 端 iGameMeshReportGenerator/iGameMeshReportClient 配套的服务端实现。
# 单线程顺序处理：一次只处理一个请求，处理完当前连接才 accept 下一个，
# 避免多个重量级 LLM 报告生成任务互相抢占资源。
#
# 用法: python mesh_report_server.py [--host 127.0.0.1] [--port 8766]
# ============================================================================

import argparse
import logging
import os
import shutil
import socket
import sys
import tempfile

# 将项目根目录（ReportGenerate/）加入 Python 路径，与 utils.py 等模块的做法一致
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)
# ReportGenerator/ 内部模块之间用的是裸导入（如 "from ReportType import ..."、
# "from utils import ..."），原先依赖 main.py 就位于该目录下时 Python 自动把
# 脚本所在目录加入 sys.path[0] 的隐式行为。Server/ 不在该目录下，需要显式补上。
_REPORT_GENERATOR_DIR = os.path.join(_PROJECT_ROOT, "ReportGenerator")
if _REPORT_GENERATOR_DIR not in sys.path:
    sys.path.insert(0, _REPORT_GENERATOR_DIR)
# Server/ 自身也加入路径，以便直接 import 同目录下的 protocol/vtk_adapter
_SERVER_DIR = os.path.dirname(os.path.abspath(__file__))
if _SERVER_DIR not in sys.path:
    sys.path.insert(0, _SERVER_DIR)

from ReportGenerator import GenerateCAEReport  # noqa: E402

import protocol  # noqa: E402
import vtk_adapter  # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("mesh_report_server")


def handle_connection(conn: socket.socket, addr) -> None:
    work_dir = tempfile.mkdtemp(prefix="meshreport_")
    try:
        logger.info("Receiving request from %s", addr)
        (vtk_bytes,) = protocol.recv_request(conn)
        logger.info("Received %d bytes of VTK data", len(vtk_bytes))

        model_path, is_multiblock_processed = vtk_adapter.convert_to_report_input(
            vtk_bytes, work_dir
        )
        logger.info(
            "Converted input: model_path=%s, is_multiblock_processed=%s",
            model_path, is_multiblock_processed,
        )

        output_path = os.path.join(work_dir, "report.docx")
        success = GenerateCAEReport(
            model_path,
            output_path,
            is_multiblock_processed=is_multiblock_processed,
            specified_fields=None,
        )

        if not success or not os.path.exists(output_path):
            logger.error("Report generation failed for request from %s", addr)
            protocol.send_error(conn, "Report generation failed")
            return

        with open(output_path, "rb") as f:
            report_data = f.read()

        protocol.send_success(conn, report_data)
        logger.info("Sent %d bytes of report data to %s", len(report_data), addr)

    except Exception as e:
        logger.exception("Error while handling request from %s", addr)
        try:
            protocol.send_error(conn, str(e))
        except Exception:
            logger.exception("Failed to send error response to %s", addr)
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)
        conn.close()


def serve(host: str, port: int) -> None:
    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_sock.bind((host, port))
    server_sock.listen(5)
    logger.info("MeshReport server listening on %s:%d", host, port)

    try:
        while True:
            conn, addr = server_sock.accept()
            logger.info("Accepted connection from %s", addr)
            handle_connection(conn, addr)
    except KeyboardInterrupt:
        logger.info("Shutting down MeshReport server")
    finally:
        server_sock.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="MeshReport TCP server")
    parser.add_argument("--host", default="127.0.0.1", help="监听地址，默认 127.0.0.1")
    parser.add_argument("--port", type=int, default=8766, help="监听端口，默认 8766")
    args = parser.parse_args()

    serve(args.host, args.port)


if __name__ == "__main__":
    main()
