"""
Camera perspective adjustment module for VTM visualization.
"""

from .camera_calculator import compute_optimal_camera_views

__all__ = ['compute_optimal_camera_views']

