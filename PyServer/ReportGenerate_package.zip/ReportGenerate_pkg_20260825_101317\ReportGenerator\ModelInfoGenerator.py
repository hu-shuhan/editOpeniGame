"""
第二章：仿真模型生成器
负责提取模型信息和生成仿真模型章节内容
"""

import os
import sys
import logging
import base64
import tempfile
from typing import Optional, Dict, List, Tuple
from dataclasses import dataclass, field
import numpy as np
from utils import _encode_image
# 设置日志
logger = logging.getLogger(__name__)


@dataclass
class ModelInfo:
    """仿真模型几何信息"""
    file_path: str                    # 模型文件路径
    file_name: str                    # 模型文件名
    file_format: str                  # 文件格式
    num_points: int = 0               # 顶点数量
    num_cells: int = 0                # 网格单元数量
    bounds: tuple = None              # 包围框 (xmin, xmax, ymin, ymax, zmin, zmax)
    center: tuple = None              # 模型中心点
    size: tuple = None                # 模型尺寸 (width, height, depth)
    model_type: str = ""              # 模型类型描述（通过AI识别）
    model_images: Optional[Dict[str, np.ndarray]] = None  # 模型渲染图像字典
    # 数据场信息（仿真结果）
    point_data_fields: Optional[List[str]] = None  # 点数据场名称列表
    cell_data_fields: Optional[List[str]] = None   # 单元数据场名称列表
    # 背景描述信息（用户提供）
    description: str = ""             # 仿真背景描述信息


# 章节Prompt模板
CHAPTER_PROMPT = """你是一位CAE仿真工程师，正在撰写仿真分析报告的"仿真模型"章节。

{fengjing_description}**模型信息**：
- 文件名：{file_name}
- 文件格式：{file_format}
- 顶点数量：{num_points}
- 网格单元数量：{num_cells}
- 包围框：X方向 [{x_min:.4f}, {x_max:.4f}]，Y方向 [{y_min:.4f}, {y_max:.4f}]，Z方向 [{z_min:.4f}, {z_max:.4f}]
- 模型中心：({center_x:.4f}, {center_y:.4f}, {center_z:.4f})
- 模型尺寸：宽度 {width:.4f}，高度 {height:.4f}，深度 {depth:.4f}
- 模型类型：{model_type}

**仿真结果数据场信息**：
{data_fields_info}

**云图颜色映射**：
{colormap_description}

**章节结构**：
- ### 2.1 模型概述
- ### 2.2 几何模型
- ### 2.3 网格划分
- ### 2.4 仿真类型分析
- ### 2.5 云图颜色映射说明

**写作原则**：
1. **报告身份**：你是这份报告的编写者，报告内容应像工程师已完成分析后撰写的正式文档，读者只能看到最终结论，看不到分析过程
2. **禁止描述过程**：严禁使用"我将"、"基于"、"通过"、"结合"、"采用"等描述分析过程或技术方法的措辞
3. **直接陈述内容**：使用"本模型包含"、"具有"、"采用"等直接陈述方式描述模型信息
4. **内容核实**：仅描述模型信息中实际存在的内容，不添加未经证实的推测
5. **格式规范**：使用Markdown格式，二级标题使用 ###，重要内容使用 **加粗**，用连贯段落形式不用列表
6. **语言风格**：正式、专业，数值必须标注单位

**输出格式**：
直接输出报告内容，不需要任何前缀说明。

输出的内容必须包含以下全部部分，顺序不得打乱：

## 2. 仿真模型

### 2.1 模型概述

（正文内容）

### 2.2 几何模型

（正文内容）

### 2.3 网格划分

（正文内容）

### 2.4 仿真类型分析

（正文内容）

### 2.5 云图颜色映射说明

（正文内容）"""

Model_Prompt = """This is a 3D mesh model from a CAE (Computer-Aided Engineering) simulation.
It represents a finite element mesh or computational grid used for engineering analysis (such as structural analysis, fluid dynamics, thermal analysis, etc.).

Please identify what type of engineering object or structure this mesh model represents.
Consider the overall shape, geometry, and structure visible in the images.

Give a brief description (5-10 words) of what this simulation model represents, for example: "car body structure", "aircraft wing", "ship hull", "mechanical component", etc."""

def extract_model_info(data, file_path: Optional[str] = None) -> Optional[ModelInfo]:
    """
    从VTK数据对象提取几何信息
    
    Args:
        data: VTK数据对象（multiblock或DataSet）
        file_path: 可选的原始文件路径（用于获取文件名和格式信息）
        
    Returns:
        ModelInfo对象，如果提取失败返回None
    """
    try:
        import vtk
        
        if data is None:
            logger.error("数据对象为空")
            return None
        
        # -----------------------------
        # 1. 获取文件信息（如果提供了file_path）
        # -----------------------------
        if file_path:
            file_name = os.path.basename(file_path)
            file_ext = os.path.splitext(file_name)[1].lower()
            
            # 文件格式映射
            format_map = {
                ".vtk": "VTK Legacy",
                ".vtu": "VTK XML Unstructured Grid",
                ".vtp": "VTK XML PolyData",
                ".vtm": "VTK XML MultiBlock",
                ".stl": "STL (Stereolithography)",
                ".obj": "OBJ (Wavefront)",
                ".ply": "PLY (Polygon File Format)",
            }
            file_format = format_map.get(file_ext, f"未知格式 ({file_ext})")
        else:
            # 根据数据类型推断格式
            if isinstance(data, vtk.vtkMultiBlockDataSet):
                file_format = "VTK MultiBlock"
                file_name = "model"
            elif isinstance(data, vtk.vtkPolyData):
                file_format = "VTK PolyData"
                file_name = "model"
            elif isinstance(data, vtk.vtkUnstructuredGrid):
                file_format = "VTK UnstructuredGrid"
                file_name = "model"
            else:
                file_format = f"VTK {type(data).__name__}"
                file_name = "model"


        def accumulate_dataset_info(dataset):
            """
            递归统计 points / cells / bounds / data fields
            """
            total_points = 0
            total_cells = 0
            bounds_acc = None
            point_fields = set()
            cell_fields = set()

            # MultiBlock
            if isinstance(dataset, vtk.vtkMultiBlockDataSet):
                for i in range(dataset.GetNumberOfBlocks()):
                    block = dataset.GetBlock(i)
                    if block is None:
                        continue

                    p, c, b, pf, cf = accumulate_dataset_info(block)
                    total_points += p
                    total_cells += c
                    point_fields.update(pf)
                    cell_fields.update(cf)

                    if b is not None:
                        if bounds_acc is None:
                            bounds_acc = list(b)
                        else:
                            bounds_acc[0] = min(bounds_acc[0], b[0])
                            bounds_acc[1] = max(bounds_acc[1], b[1])
                            bounds_acc[2] = min(bounds_acc[2], b[2])
                            bounds_acc[3] = max(bounds_acc[3], b[3])
                            bounds_acc[4] = min(bounds_acc[4], b[4])
                            bounds_acc[5] = max(bounds_acc[5], b[5])

            # 普通 DataSet
            elif isinstance(dataset, vtk.vtkDataSet):
                total_points = dataset.GetNumberOfPoints()
                total_cells = dataset.GetNumberOfCells()
                bounds_acc = dataset.GetBounds()
                
                # 获取点数据场名称
                point_data = dataset.GetPointData()
                if point_data:
                    for i in range(point_data.GetNumberOfArrays()):
                        arr_name = point_data.GetArrayName(i)
                        if arr_name:
                            point_fields.add(arr_name)
                
                # 获取单元数据场名称
                cell_data = dataset.GetCellData()
                if cell_data:
                    for i in range(cell_data.GetNumberOfArrays()):
                        arr_name = cell_data.GetArrayName(i)
                        if arr_name:
                            cell_fields.add(arr_name)

            return total_points, total_cells, bounds_acc, point_fields, cell_fields


        num_points, num_cells, bounds, point_data_fields, cell_data_fields = accumulate_dataset_info(data)

        if bounds is None:
            logger.error("模型中未包含有效的几何数据")
            return None


        center = (
            (bounds[0] + bounds[1]) / 2.0,
            (bounds[2] + bounds[3]) / 2.0,
            (bounds[4] + bounds[5]) / 2.0,
        )

        size = (
            bounds[1] - bounds[0],  # X
            bounds[3] - bounds[2],  # Y
            bounds[5] - bounds[4],  # Z
        )


        # 转换集合为排序列表
        point_fields_list = sorted(list(point_data_fields)) if point_data_fields else []
        cell_fields_list = sorted(list(cell_data_fields)) if cell_data_fields else []
        
        logger.info(f"发现点数据场: {point_fields_list}")
        logger.info(f"发现单元数据场: {cell_fields_list}")

        return ModelInfo(
            file_path=file_path if file_path else "",
            file_name=file_name,
            file_format=file_format,
            num_points=num_points,
            num_cells=num_cells,
            bounds=bounds,
            center=center,
            size=size,
            point_data_fields=point_fields_list if point_fields_list else None,
            cell_data_fields=cell_fields_list if cell_fields_list else None,
        )

    except ImportError:
        logger.error("VTK 库未安装，请运行: pip install vtk")
        return None
    except Exception as e:
        logger.error(f"读取模型信息时发生错误: {e}", exc_info=True)
        return None


def render_model_images(data) -> Tuple[Dict[str, np.ndarray], Optional[str]]:
    """
    渲染模型图像（纯色渲染，用于仿真模型展示）
    
    Args:
        data: VTK数据对象（multiblock或DataSet）
        
    Returns:
        (图像字典, 错误信息)，如果成功则错误信息为None
    """
    try:
        from DataVisualization import render_solid_color
        from analysis.adjust_perspective.camera_calculator import (
            compute_multiblock_bounds,
            compute_isometric_view_from_bounds
        )
        import vtk
        
        if data is None:
            return {}, "数据对象为空"
        
        # 计算bounds和相机视图
        if isinstance(data, vtk.vtkMultiBlockDataSet):
            bounds = compute_multiblock_bounds(data)
        else:
            bounds = data.GetBounds()
        
        isometric_view = compute_isometric_view_from_bounds(bounds)
        
        # 使用纯色渲染（灰色，0.7, 0.7, 0.7）
        images = render_solid_color(
            data,
            color=(0.7, 0.7, 0.7),  # 统一的灰色
            scalar_field_name=None,  # 不使用标量场
            camera_params=isometric_view,
            window_size=(1600, 1600),
            background_color=(1.0, 1.0, 1.0)
        )
        
        final_images = {'isometric': images}
        
        return final_images, None
        
    except Exception as e:
        logger.error(f"渲染模型图像时发生错误: {e}", exc_info=True)
        return {}, str(e)


def identify_model_type(images: Dict[str, np.ndarray]) -> str:
    """
    使用LLM识别模型类型（使用 utils 统一接口）
    
    Args:
        images: 模型图像字典
        
    Returns:
        模型类型描述
    """
    if not images:
        return "未知模型"
    
    try:
        from utils import call_llm
           
        # 将图像转换为base64格式
        image_inputs = []
        for image_array in images.values():
            base64_data = _encode_image(image_array)
            image_inputs.append(f"data:image/png;base64,{base64_data}")
        
        # 使用统一的LLM调用接口
        result = call_llm(Model_Prompt, images=image_inputs)
        
        if result:
            logger.info(f"模型类型识别结果: {result}")
            return result.strip()
        else:
            logger.warning("LLM返回空结果，使用默认描述")
            return "3D仿真模型"
        
    except Exception as e:
        logger.error(f"识别模型类型时发生错误: {e}", exc_info=True)
        return "3D仿真模型"


def generate_chapter_simulation_model(model_info: ModelInfo, colormap_type: str = "diverging", description: str = "") -> str:
    """
    生成第二章：仿真模型
    
    Args:
        model_info: 模型信息对象
        colormap_type: 颜色映射类型 ("diverging" 或 "default")
        description: 仿真背景描述信息（可选）
        
    Returns:
        生成的章节内容
    """
    from utils import call_llm
    from SimulationResultsGenerator import get_colormap_report_description
    
    if model_info is None:
        return "## 2. 仿真模型\n\n模型信息读取失败，无法生成此章节内容。"
    
    # 如果description为空，尝试从model_info中获取
    if not description and model_info.description:
        description = model_info.description
    
    # 构建数据场信息字符串
    data_fields_lines = []
    if model_info.point_data_fields:
        data_fields_lines.append(f"- 点数据场（{len(model_info.point_data_fields)}个）：{', '.join(model_info.point_data_fields)}")
    else:
        data_fields_lines.append("- 点数据场：无")
    
    if model_info.cell_data_fields:
        data_fields_lines.append(f"- 单元数据场（{len(model_info.cell_data_fields)}个）：{', '.join(model_info.cell_data_fields)}")
    else:
        data_fields_lines.append("- 单元数据场：无")
    
    data_fields_info = "\n".join(data_fields_lines)
    
    # 获取颜色映射说明
    colormap_description = get_colormap_report_description(colormap_type)
    
    # 处理背景描述信息
    fengjing_description_str = ""
    if description:
        fengjing_description_str = f"""**用户提供的仿真背景描述**：
{description}

---

"""
    
    # 准备Prompt参数
    prompt = CHAPTER_PROMPT.format(
        fengjing_description=fengjing_description_str,
        file_name=model_info.file_name,
        file_format=model_info.file_format,
        num_points=model_info.num_points,
        num_cells=model_info.num_cells,
        x_min=model_info.bounds[0] if model_info.bounds else 0,
        x_max=model_info.bounds[1] if model_info.bounds else 0,
        y_min=model_info.bounds[2] if model_info.bounds else 0,
        y_max=model_info.bounds[3] if model_info.bounds else 0,
        z_min=model_info.bounds[4] if model_info.bounds else 0,
        z_max=model_info.bounds[5] if model_info.bounds else 0,
        center_x=model_info.center[0] if model_info.center else 0,
        center_y=model_info.center[1] if model_info.center else 0,
        center_z=model_info.center[2] if model_info.center else 0,
        width=model_info.size[0] if model_info.size else 0,
        height=model_info.size[1] if model_info.size else 0,
        depth=model_info.size[2] if model_info.size else 0,
        model_type=model_info.model_type if model_info.model_type else "3D仿真模型",
        data_fields_info=data_fields_info,
        colormap_description=colormap_description,
    )
    
    # 准备图像输入
    images = None
    if model_info.model_images:
        # 使用公共函数将numpy数组转换为base64格式
        image_inputs = []
        for img_array in model_info.model_images.values():
            base64_data = _encode_image(img_array)
            image_inputs.append(f"data:image/png;base64,{base64_data}")

        images = image_inputs
    
    # 调用统一的LLM函数（支持图像输入）
    return call_llm(prompt, images=images)


__all__ = [
    "ModelInfo",
    "extract_model_info",
    "generate_chapter_simulation_model",
    "render_model_images",
    "identify_model_type",
]

