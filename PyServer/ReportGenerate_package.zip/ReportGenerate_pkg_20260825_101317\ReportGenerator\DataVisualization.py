"""
VTK网格可视化工具模块
提供统一的网格可视化接口，支持多种渲染方式和标量场渲染
"""

import numpy as np
import os
import sys
import vtk
from vtk.util import numpy_support
from typing import Dict, List, Tuple, Optional, Union
import matplotlib.pyplot as plt
import matplotlib.cm as cm


def apply_camera_view(camera, camera_params):
    """
    Apply camera parameters to a VTK camera.
    
    Parameters:
    - camera: VTK camera object
    - camera_params: Dictionary with 'position', 'focal_point', 'view_up'
    """
    camera.SetPosition(camera_params['position'])
    camera.SetFocalPoint(camera_params['focal_point'])
    camera.SetViewUp(camera_params['view_up'])

# ============================================================================
# 辅助函数
# ============================================================================

def _compute_normals_if_needed(data: vtk.vtkDataSet) -> vtk.vtkDataSet:
    """如果需要，计算法向量（支持任意DataSet类型）"""
    # 检查是否已有法向量
    if hasattr(data, 'GetPointData') and data.GetPointData().GetNormals() is not None:
        return data
    
    # 如果数据不是polydata，先转换为polydata
    if not isinstance(data, vtk.vtkPolyData):
        geometry_filter = vtk.vtkGeometryFilter()
        geometry_filter.SetInputData(data)
        geometry_filter.Update()
        data = geometry_filter.GetOutput()
    
    # 计算法向量
    if isinstance(data, vtk.vtkPolyData) and data.GetPointData().GetNormals() is None:
        normals = vtk.vtkPolyDataNormals()
        normals.SetInputData(data)
        normals.ComputePointNormalsOn()
        normals.ComputeCellNormalsOff()
        normals.SplittingOff()
        normals.ConsistencyOn()
        normals.AutoOrientNormalsOn()
        normals.Update()
        return normals.GetOutput()
    
    return data


def _create_colormap(colormap_type: str = "diverging", scalar_min: float = 0.0, scalar_max: float = 1.0):
    """
    创建颜色映射表（使用VTK内置的颜色映射）
    
    Args:
        colormap_type: 颜色映射表类型
            - "default": 默认的HSV颜色映射（vtkLookupTable默认）
            - "diverging": VTK内置的diverging颜色映射（使用vtkColorSeries的预定义方案）
        scalar_min: 标量场最小值
        scalar_max: 标量场最大值
        
    Returns:
        VTK颜色映射表对象（vtkLookupTable）
    """
    lut = vtk.vtkLookupTable()
    lut.SetNumberOfTableValues(256)
    lut.SetRange(scalar_min, scalar_max)
    
    if colormap_type == "diverging":
        # 使用VTK内置的diverging颜色空间（ParaView默认的蓝-白-红）
        ctf = vtk.vtkColorTransferFunction()
        ctf.SetColorSpaceToDiverging()  # 使用发散色彩空间（关键）
        
        # ParaView默认是蓝-白-红
        mid_value = (scalar_min + scalar_max) / 2.0
        ctf.AddRGBPoint(scalar_min, 0.231, 0.298, 0.753)  # 蓝
        ctf.AddRGBPoint(mid_value, 0.865, 0.865, 0.865)   # 白
        ctf.AddRGBPoint(scalar_max, 0.706, 0.016, 0.150)  # 红
        
        # 将ColorTransferFunction转换为LookupTable
        for i in range(256):
            value = scalar_min + (scalar_max - scalar_min) * i / 255.0
            rgb = ctf.GetColor(value)
            lut.SetTableValue(i, rgb[0], rgb[1], rgb[2], 1.0)
    else:
        # 默认使用HSV颜色映射（vtkLookupTable的默认设置）
        pass
    
    lut.Build()
    return lut


def _compute_global_scalar_range(
    data: vtk.vtkDataObject,
    scalar_field_name: str,
    use_cell_data: bool = True,
    component_index: int = -1
) -> Optional[Tuple[float, float]]:
    """
    计算 multiblock 数据集的全局标量范围
    
    Args:
        data: VTK数据对象（multiblock或任意DataSet类型）
        scalar_field_name: 标量场名称
        use_cell_data: 是否使用单元数据（True）或点数据（False）
        component_index: 分量索引（-1表示幅值，0,1,2表示X,Y,Z分量）
        
    Returns:
        全局标量范围 (min, max)，如果无法计算则返回 None
    """
    if scalar_field_name is None:
        return None
    
    global_min = float('inf')
    global_max = float('-inf')
    found_any = False
    
    if isinstance(data, vtk.vtkMultiBlockDataSet):
        for i in range(data.GetNumberOfBlocks()):
            block = data.GetBlock(i)
            if block is None or not isinstance(block, vtk.vtkDataSet):
                continue
            
            if use_cell_data:
                scalar_array = block.GetCellData().GetArray(scalar_field_name)
            else:
                scalar_array = block.GetPointData().GetArray(scalar_field_name)
            
            if scalar_array is not None:
                local_range = scalar_array.GetRange(component_index)
                global_min = min(global_min, local_range[0])
                global_max = max(global_max, local_range[1])
                found_any = True
    
    elif isinstance(data, vtk.vtkDataSet):
        if use_cell_data:
            scalar_array = data.GetCellData().GetArray(scalar_field_name)
        else:
            scalar_array = data.GetPointData().GetArray(scalar_field_name)
        
        if scalar_array is not None:
            local_range = scalar_array.GetRange(component_index)
            global_min = min(global_min, local_range[0])
            global_max = max(global_max, local_range[1])
            found_any = True
    
    if found_any:
        return (global_min, global_max)
    return None


def _setup_scalar_field(
    mapper: vtk.vtkDataSetMapper,
    data: vtk.vtkDataSet,
    scalar_field_name: Optional[str] = None,
    use_cell_data: bool = True,
    colormap_type: str = "diverging",
    global_scalar_range: Optional[Tuple[float, float]] = None,
    component_index: int = -1
) -> bool:
    """
    设置标量场渲染（支持任意DataSet类型）
    
    Args:
        mapper: VTK mapper
        data: VTK数据集（DataSet类型，包括PolyData、UnstructuredGrid等）
        scalar_field_name: 标量场名称，如果为None则使用第一个可用的标量场
        use_cell_data: 是否使用单元数据（True）或点数据（False）
        colormap_type: 颜色映射表类型
        global_scalar_range: 可选的全局标量范围，用于multiblock数据集的统一颜色映射
        component_index: 分量索引（-1表示幅值，0,1,2表示X,Y,Z分量）
        
    Returns:
        是否成功设置标量场
    """
    if not isinstance(data, vtk.vtkDataSet):
        return False
    
    if scalar_field_name is None:
        # 自动查找标量场
        if use_cell_data and data.GetCellData().GetScalars():
            scalar_field_name = data.GetCellData().GetScalars().GetName()
        elif not use_cell_data and data.GetPointData().GetScalars():
            scalar_field_name = data.GetPointData().GetScalars().GetName()
        else:
            return False
    
    if scalar_field_name:
        # 设置ActiveScalars（需要在mapper设置之前）
        target_use_cell_data = use_cell_data
        
        # 自动检测：如果指定位置没有该数组，但另一处有，则切换
        if use_cell_data:
            if not data.GetCellData().HasArray(scalar_field_name):
                if data.GetPointData().HasArray(scalar_field_name):
                    target_use_cell_data = False
        else:
            if not data.GetPointData().HasArray(scalar_field_name):
                if data.GetCellData().HasArray(scalar_field_name):
                    target_use_cell_data = True
                    
        if component_index >= 0:
            # 渲染特定分量
            mapper.ScalarVisibilityOn()
            if target_use_cell_data:
                mapper.SetScalarModeToUseCellFieldData()
            else:
                mapper.SetScalarModeToUsePointFieldData()
            mapper.SelectColorArray(scalar_field_name)
            mapper.SetArrayComponent(component_index)
        else:
            # 渲染标量或矢量幅值
            if target_use_cell_data:
                if data.GetCellData().HasArray(scalar_field_name):
                    data.GetCellData().SetActiveScalars(scalar_field_name)
                else:
                    return False
            else:
                if data.GetPointData().HasArray(scalar_field_name):
                    data.GetPointData().SetActiveScalars(scalar_field_name)
                else:
                    return False
            
            mapper.ScalarVisibilityOn()
            if target_use_cell_data:
                mapper.SetScalarModeToUseCellData()
            else:
                mapper.SetScalarModeToUsePointData()
        
        # 获取标量场的范围（优先使用全局范围）
        if global_scalar_range is not None:
            scalar_min, scalar_max = global_scalar_range
        else:
            if target_use_cell_data:
                scalar_array = data.GetCellData().GetArray(scalar_field_name)
            else:
                scalar_array = data.GetPointData().GetArray(scalar_field_name)
            
            if scalar_array is not None:
                scalar_range = scalar_array.GetRange(component_index)
                scalar_min, scalar_max = scalar_range[0], scalar_range[1]
            else:
                # 如果无法获取范围，使用默认值
                scalar_min, scalar_max = 0.0, 1.0
        
        # 创建颜色映射表（使用VTK内置的颜色映射）
        lut = _create_colormap(colormap_type, scalar_min, scalar_max)
        mapper.SetLookupTable(lut)
        mapper.SetUseLookupTableScalarRange(True)
        
        return True
    return False


# ============================================================================
# Actor创建函数
# ============================================================================

def _create_solid_color_actor(
    data: vtk.vtkDataObject,
    color: Tuple[float, float, float] = (0.7, 0.7, 0.7),
    scalar_field_name: Optional[str] = None,
    use_cell_data: bool = True,
    colormap_type: str = "default",
    component_index: int = -1
) -> Union[vtk.vtkActor, List[vtk.vtkActor]]:
    """
    创建纯色渲染的actor
    
    Returns:
        单个actor或actor列表
    """
    # 如果是multiblock，为每个block创建actor（使用统一颜色）
    if isinstance(data, vtk.vtkMultiBlockDataSet):
        # 先计算全局标量范围
        global_scalar_range = _compute_global_scalar_range(data, scalar_field_name, use_cell_data, component_index)
        
        actors = []
        for i in range(data.GetNumberOfBlocks()):
            block = data.GetBlock(i)
            if block is None or not isinstance(block, vtk.vtkDataSet):
                continue
            
            # 计算法向量（如果需要）
            block = _compute_normals_if_needed(block)
            
            mapper = vtk.vtkDataSetMapper()
            mapper.SetInputData(block)
            
            # 设置标量场（如果指定），使用全局标量范围
            has_scalar = _setup_scalar_field(mapper, block, scalar_field_name, use_cell_data, colormap_type, global_scalar_range, component_index)
            
            if not has_scalar:
                mapper.ScalarVisibilityOff()
            
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            
            if not has_scalar:
                actor.GetProperty().SetColor(color)
            
            actor.GetProperty().SetLighting(True)
            actor.GetProperty().SetAmbient(0.3)
            actor.GetProperty().SetDiffuse(0.7)
            actor.GetProperty().SetSpecular(0.2)
            actor.GetProperty().SetSpecularPower(30.0)
            
            actors.append(actor)
        
        return actors if len(actors) > 1 else (actors[0] if actors else None)
    
    # 单个数据集
    elif isinstance(data, vtk.vtkDataSet):
        # 计算法向量（如果需要）
        data = _compute_normals_if_needed(data)
        
        mapper = vtk.vtkDataSetMapper()
        mapper.SetInputData(data)
        
        # 设置标量场（如果指定）
        has_scalar = _setup_scalar_field(mapper, data, scalar_field_name, use_cell_data, colormap_type, component_index=component_index)
        
        if not has_scalar:
            mapper.ScalarVisibilityOff()
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        
        if not has_scalar:
            actor.GetProperty().SetColor(color)
        
        actor.GetProperty().SetLighting(True)
        actor.GetProperty().SetAmbient(0.3)
        actor.GetProperty().SetDiffuse(0.7)
        actor.GetProperty().SetSpecular(0.2)
        actor.GetProperty().SetSpecularPower(30.0)
        
        return actor
    
    else:
        raise ValueError(f"不支持的数据类型: {type(data)}")


def _create_multiblock_index_color_actors(
    multiblock: vtk.vtkMultiBlockDataSet,
    scalar_field_name: Optional[str] = None,
    use_cell_data: bool = True,
    colormap_type: str = "default",
    component_index: int = -1
) -> List[vtk.vtkActor]:
    """创建多块按index颜色渲染的actors"""
    num_blocks = multiblock.GetNumberOfBlocks()
    
    # 生成颜色映射
    if num_blocks <= 10:
        cmap = plt.colormaps['tab10']
    elif num_blocks <= 20:
        cmap = plt.colormaps['tab20']
    else:
        cmap = plt.colormaps['hsv']
    
    # 先计算全局标量范围
    global_scalar_range = _compute_global_scalar_range(multiblock, scalar_field_name, use_cell_data, component_index)
    
    actors = []
    for i in range(num_blocks):
        block = multiblock.GetBlock(i)
        if block is None or not isinstance(block, vtk.vtkDataSet):
            continue
        
        # 计算法向量（如果需要）
        block = _compute_normals_if_needed(block)
        
        mapper = vtk.vtkDataSetMapper()
        mapper.SetInputData(block)
        
        # 设置标量场（如果指定），使用全局标量范围
        has_scalar = _setup_scalar_field(mapper, block, scalar_field_name, use_cell_data, colormap_type, global_scalar_range, component_index)
        
        if not has_scalar:
            mapper.ScalarVisibilityOff()
            # 使用index颜色
            color = cmap(i / max(num_blocks - 1, 1))[:3]
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        
        if not has_scalar:
            actor.GetProperty().SetColor(color)
        
        actor.GetProperty().SetLighting(True)
        actor.GetProperty().SetAmbient(0.3)
        actor.GetProperty().SetDiffuse(0.7)
        actor.GetProperty().SetSpecular(0.2)
        actor.GetProperty().SetSpecularPower(30.0)
        
        actors.append(actor)
    
    return actors


def _create_focus_block_actors(
    multiblock: vtk.vtkMultiBlockDataSet,
    focus_block_idx: int,
    focus_rgba: Tuple[float, float, float, float] = (1.0, 0.5, 0.0, 1.0),
    other_rgba: Tuple[float, float, float, float] = (0.75, 0.75, 0.75, 0.25),
    scalar_field_name: Optional[str] = None,
    use_cell_data: bool = True,
    colormap_type: str = "default",
    component_index: int = -1
) -> List[vtk.vtkActor]:
    """创建聚焦块渲染的actors（直接使用DataSet接口）"""
    num_blocks = multiblock.GetNumberOfBlocks()
    
    if focus_block_idx < 0 or focus_block_idx >= num_blocks:
        raise ValueError(f"focus_block_idx {focus_block_idx} 超出范围 [0, {num_blocks-1}]")
    
    # 先计算全局标量范围
    global_scalar_range = _compute_global_scalar_range(multiblock, scalar_field_name, use_cell_data, component_index)
    
    actors = []
    for i in range(num_blocks):
        block = multiblock.GetBlock(i)
        if block is None or not isinstance(block, vtk.vtkDataSet):
            continue
        
        # 计算法向量（如果需要）
        block = _compute_normals_if_needed(block)
        
        mapper = vtk.vtkDataSetMapper()
        mapper.SetInputData(block)
        
        # 设置标量场（如果指定），使用全局标量范围
        has_scalar = _setup_scalar_field(mapper, block, scalar_field_name, use_cell_data, colormap_type, global_scalar_range, component_index)
        
        if not has_scalar:
            mapper.ScalarVisibilityOff()
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        
        # 设置透明度（无论是否有标量场，都需要设置透明度以实现聚焦效果）
        if i == focus_block_idx:
            actor.GetProperty().SetOpacity(focus_rgba[3])
        else:
            actor.GetProperty().SetOpacity(other_rgba[3])
        
        # 如果没有标量场，设置颜色
        if not has_scalar:
            if i == focus_block_idx:
                actor.GetProperty().SetColor(focus_rgba[:3])
            else:
                actor.GetProperty().SetColor(other_rgba[:3])
        
        actor.GetProperty().SetLighting(True)
        actor.GetProperty().SetAmbient(0.3)
        actor.GetProperty().SetDiffuse(0.7)
        actor.GetProperty().SetSpecular(0.2)
        actor.GetProperty().SetSpecularPower(30.0)
        
        actors.append(actor)
    
    return actors


# ============================================================================
# 渲染函数
# ============================================================================


def _render_actors(
    actors: Union[vtk.vtkActor, List[vtk.vtkActor]],
    camera_params: Optional[Dict] = None,
    window_size: Tuple[int, int] = (1600, 1600),
    background_color: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    focus_bounds: Optional[Tuple[float, float, float, float, float, float]] = None
) -> np.ndarray:
    """
    渲染actors并返回numpy数组
    
    Args:
        actors: 要渲染的actor或actor列表
        camera_params: 可选的相机参数，包含 position、focal_point、view_up
                      如果提供，则完全使用这些参数设置相机，window_size 只影响分辨率
        window_size: 渲染窗口大小（只影响输出分辨率，不影响视图内容）
        background_color: 背景颜色
        focus_bounds: 可选的聚焦区域包围盒（仅当 camera_params 为 None 时使用）
    
    Returns:
        渲染后的图像数组 (H, W, C)
    """
    if actors is None:
        raise ValueError("没有可渲染的actors")
    if isinstance(actors, vtk.vtkActor):
        actors = [actors]
    
    # 创建渲染窗口
    renderer = vtk.vtkRenderer()
    render_window = vtk.vtkRenderWindow()
    render_window.SetOffScreenRendering(1)
    render_window.AddRenderer(renderer)
    render_window.SetSize(window_size[0], window_size[1])
    renderer.SetBackground(background_color)
    
    # 添加actors
    for actor in actors:
        renderer.AddActor(actor)
    
    # 设置相机
    camera = renderer.GetActiveCamera()
    bounds = renderer.ComputeVisiblePropBounds()
    
    # 计算模型包围框的中心
    if focus_bounds is not None:
        center = np.array([
            (focus_bounds[0] + focus_bounds[1]) / 2.0,
            (focus_bounds[2] + focus_bounds[3]) / 2.0,
            (focus_bounds[4] + focus_bounds[5]) / 2.0
        ])
        bounds_for_camera = focus_bounds
    else:
        center = np.array([
            (bounds[0] + bounds[1]) / 2.0,
            (bounds[2] + bounds[3]) / 2.0,
            (bounds[4] + bounds[5]) / 2.0
        ])
        bounds_for_camera = bounds
    
    # 固定的参考视角角度（用于确保不同分辨率下视图一致）
    REFERENCE_VIEW_ANGLE = 30.0  # 度
    
    if camera_params is not None:
        # 如果提供了相机参数，直接使用它们
        # 这些参数已经是基于 OBB/PCA 计算的最佳视角
        apply_camera_view(camera, camera_params)
        
        # 设置固定的视角角度，确保不同 window_size 下视图一致
        # VTK 默认使用垂直视角（Vertical View Angle）
        camera.SetViewAngle(REFERENCE_VIEW_ANGLE)
        
        # 获取当前相机参数用于后续计算
        focal_point = np.array(camera.GetFocalPoint())
        view_up = np.array(camera.GetViewUp())
        position = np.array(camera.GetPosition())
        
        # 处理长宽比问题：
        # VTK 的视角是垂直方向的，水平方向会根据窗口宽高比自动调整
        # 如果宽高比不是 1:1，需要调整以保持视图内容一致
        window_width, window_height = window_size
        aspect_ratio = window_width / window_height
        
        if abs(aspect_ratio - 1.0) > 0.01:  # 非正方形窗口
            # 对于非正方形窗口，调整视角以确保视图内容一致
            # 方法：调整垂直视角，使得可视范围保持一致
            # 如果窗口更宽（aspect > 1），水平方向自动扩展，无需调整
            # 如果窗口更高（aspect < 1），需要增大垂直视角以显示相同内容
            if aspect_ratio < 1.0:
                # 窗口更高，需要调整垂直视角
                adjusted_angle = 2.0 * np.rad2deg(np.arctan(
                    np.tan(np.deg2rad(REFERENCE_VIEW_ANGLE / 2.0)) / aspect_ratio
                ))
                camera.SetViewAngle(adjusted_angle)
    else:
        # 如果没有提供相机参数，使用默认设置并自动计算位置
        focal_point = center
        view_up = np.array([0.0, 1.0, 0.0])
        camera_offset = np.array([0.4, 0.0, 1.0])
        camera_offset = camera_offset / np.linalg.norm(camera_offset)
        
        # 设置固定的视角角度
        camera.SetViewAngle(REFERENCE_VIEW_ANGLE)
        
        # 计算模型的有效尺寸
        size = np.array([
            bounds_for_camera[1] - bounds_for_camera[0],
            bounds_for_camera[3] - bounds_for_camera[2],
            bounds_for_camera[5] - bounds_for_camera[4]
        ])
        
        # 使用包围球直径来确保全方位包含
        effective_size = np.linalg.norm(size)
        
        # 根据固定视角角度计算距离，使模型尽可能充满视图
        # target_ratio = 0.95 留出少量边距
        target_ratio = 0.95 
        view_angle_rad = np.deg2rad(REFERENCE_VIEW_ANGLE)
        
        # 计算距离：使得包围球正好位于视锥体内
        # distance = radius / sin(half_fov)
        distance = (effective_size / 2.0) / np.sin(view_angle_rad / 2.0) / target_ratio
        
        # 调整距离以考虑相机偏移向量的长度
        offset_norm = np.linalg.norm(camera_offset)
        distance = distance / offset_norm if offset_norm > 0 else distance
        
        # 设置相机位置：从焦点沿偏移方向移动计算出的距离
        position = focal_point + distance * camera_offset
        camera.SetPosition(*position)
        camera.SetFocalPoint(*focal_point)
        camera.SetViewUp(*view_up)
    
    renderer.ResetCameraClippingRange(bounds)
    
    # 添加光照
    key_light = vtk.vtkLight()
    key_light.SetLightTypeToCameraLight()
    key_light.SetIntensity(0.8)
    renderer.AddLight(key_light)
    
    fill_light = vtk.vtkLight()
    fill_light.SetLightTypeToHeadlight()
    fill_light.SetIntensity(0.4)
    renderer.AddLight(fill_light)
    
    # 渲染
    render_window.Render()
    
    # 捕获图像
    window_to_image = vtk.vtkWindowToImageFilter()
    window_to_image.SetInput(render_window)
    window_to_image.Update()
    
    vtk_image = window_to_image.GetOutput()
    width, height, _ = vtk_image.GetDimensions()
    vtk_array = vtk_image.GetPointData().GetScalars()
    components = vtk_array.GetNumberOfComponents()
    img_array = numpy_support.vtk_to_numpy(vtk_array).reshape(height, width, components)
    img_array = np.flipud(img_array)
    
    # 清理
    render_window.Finalize()
    del render_window, renderer
    
    return img_array


# ============================================================================
# 公共API
# ============================================================================

def render_solid_color(
    data: vtk.vtkDataObject,
    color: Tuple[float, float, float] = (0.7, 0.7, 0.7),
    scalar_field_name: Optional[str] = None,
    use_cell_data: bool = True,
    camera_params: Optional[Dict] = None,
    window_size: Tuple[int, int] = (1600, 1600),
    background_color: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    colormap_type: str = "diverging",
    component_index: int = -1
) -> np.ndarray:
    """
    纯色渲染
    
    Args:
        data: VTK数据对象（multiblock或任意DataSet类型）
        color: RGB颜色 (0-1)
        scalar_field_name: 可选的标量场名称，如果指定则按标量场渲染
        use_cell_data: 标量场使用单元数据（True）或点数据（False）
        camera_params: 可选的相机参数
        window_size: 窗口大小
        background_color: 背景颜色
        colormap_type: 颜色映射表类型
            - "default": 默认的HSV颜色映射（vtkLookupTable默认）
            - "diverging": VTK内置的diverging颜色映射（类似于红白蓝，蓝色->白色->红色）
        
    Returns:
        渲染后的图像数组 (H, W, C)
    """
    actors = _create_solid_color_actor(data, color, scalar_field_name, use_cell_data, colormap_type, component_index)
    return _render_actors(actors, camera_params, window_size, background_color)


def render_multiblock_index_color(
    multiblock: vtk.vtkMultiBlockDataSet,
    scalar_field_name: Optional[str] = None,
    use_cell_data: bool = True,
    camera_params: Optional[Dict] = None,
    window_size: Tuple[int, int] = (1600, 1600),
    background_color: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    colormap_type: str = "diverging",
    component_index: int = -1
) -> np.ndarray:
    """
    多块模型按index颜色渲染
    
    Args:
        multiblock: VTK multiblock数据集
        scalar_field_name: 可选的标量场名称，如果指定则按标量场渲染
        use_cell_data: 标量场使用单元数据（True）或点数据（False）
        camera_params: 可选的相机参数
        window_size: 窗口大小
        background_color: 背景颜色
        colormap_type: 颜色映射表类型
            - "default": 默认的HSV颜色映射（vtkLookupTable默认）
            - "diverging": VTK内置的diverging颜色映射（类似于红白蓝，蓝色->白色->红色）
        
    Returns:
        渲染后的图像数组 (H, W, C)
    """
    if not isinstance(multiblock, vtk.vtkMultiBlockDataSet):
        raise ValueError("此函数仅支持multiblock数据集")
    
    actors = _create_multiblock_index_color_actors(multiblock, scalar_field_name, use_cell_data, colormap_type, component_index)
    return _render_actors(actors, camera_params, window_size, background_color)


def render_focus_block(
    multiblock: vtk.vtkMultiBlockDataSet,
    focus_block_idx: int,
    focus_rgba: Tuple[float, float, float, float] = (1.0, 0.5, 0.0, 1.0),
    other_rgba: Tuple[float, float, float, float] = (0.75, 0.75, 0.75, 0.25),
    scalar_field_name: Optional[str] = None,
    use_cell_data: bool = True,
    camera_params: Optional[Dict] = None,
    window_size: Tuple[int, int] = (1600, 1600),
    background_color: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    colormap_type: str = "diverging",
    component_index: int = -1
) -> np.ndarray:
    """
    聚焦块渲染（选中块和未选中块不同颜色）
    
    Args:
        multiblock: VTK multiblock数据集
        focus_block_idx: 聚焦的块索引
        focus_rgba: 聚焦块的RGBA颜色
        other_rgba: 其他块的RGBA颜色
        scalar_field_name: 可选的标量场名称，如果指定则按标量场渲染
        use_cell_data: 标量场使用单元数据（True）或点数据（False）
        camera_params: 可选的相机参数
        window_size: 窗口大小
        background_color: 背景颜色
        colormap_type: 颜色映射表类型
            - "default": 默认的HSV颜色映射（vtkLookupTable默认）
            - "diverging": VTK内置的diverging颜色映射（类似于红白蓝，蓝色->白色->红色）
        
    Returns:
        渲染后的图像数组 (H, W, C)
    """
    if not isinstance(multiblock, vtk.vtkMultiBlockDataSet):
        raise ValueError("此函数仅支持multiblock数据集")
    
    # 获取聚焦部件的bounds，用于计算相机距离
    focus_block = multiblock.GetBlock(focus_block_idx)
    focus_bounds = None
    if focus_block is not None and isinstance(focus_block, vtk.vtkDataSet):
        focus_bounds = focus_block.GetBounds()
    
    actors = _create_focus_block_actors(
        multiblock, focus_block_idx, focus_rgba, other_rgba,
        scalar_field_name, use_cell_data, colormap_type, component_index
    )
    return _render_actors(actors, camera_params, window_size, background_color, focus_bounds)


__all__ = [
    "render_solid_color",
    "render_multiblock_index_color",
    "render_focus_block",
]

