# PredefinedStrs package

