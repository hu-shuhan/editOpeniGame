"""
CAE仿真分析报告生成器
根据仿真模型文件自动生成Word格式的仿真分析报告

报告结构：
- 第一章：概述
- 第二章：仿真模型
- 第三章：仿真结果
- 第四章：结果讨论
- 第五章：总结

生成顺序：第二章 → 第三章 → 第四章 → 第五章 → 第一章
"""

import os
import sys
import logging
import uuid
from typing import Dict, Optional, List

# 将项目根目录添加到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from ReportConverter import ConvertTextToWordReport

# 导入各章节生成器
from ModelInfoGenerator import (
    ModelInfo, 
    extract_model_info, 
    generate_chapter_simulation_model,
    render_model_images,
    identify_model_type
)
from utils import read_mesh_file
from utils import cleanup_temp_images
from SimulationResultsGenerator import generate_chapter_simulation_results
from DiscussionGenerator import generate_chapter_discussion
from SummaryGenerator import generate_chapter_summary
from OverviewGenerator import generate_chapter_overview
from utils import reset_dialogue

# 设置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

import copy
def filter_model_data_fields(
    model_info: ModelInfo,
    required_point_fields: Optional[List[str]] = None,
    required_cell_fields: Optional[List[str]] = None,
    inplace: bool = False,
) -> ModelInfo:
    """
    过滤 ModelInfo 中的属性场信息，仅保留指定的属性场名称

    使用精确匹配：只保留名称完全匹配的属性场

    Args:
        model_info: 原始 ModelInfo
        required_point_fields: 需要保留的点属性场名称列表
        required_cell_fields: 需要保留的单元属性场名称列表
        inplace: 是否原地修改

    Returns:
        处理后的 ModelInfo
    """
    if model_info is None:
        return None

    target = model_info if inplace else copy.deepcopy(model_info)

    def _filter_fields(existing_fields, required_names):
        if not existing_fields:
            return []
        if not required_names:
            return []

        # 精确匹配：只保留名称在 required_names 中的字段
        required_set = set(required_names)
        return [name for name in existing_fields if name in required_set]

    # -------- 点属性场过滤 --------
    if required_point_fields is not None:
        target.point_data_fields = _filter_fields(
            target.point_data_fields,
            required_point_fields,
        )

    # -------- 单元属性场过滤 --------
    if required_cell_fields is not None:
        target.cell_data_fields = _filter_fields(
            target.cell_data_fields,
            required_cell_fields,
        )

    return target


class ReportGenerator:
    """
    CAE仿真分析报告生成器
    
    输入仿真模型文件路径，通过LLM自动生成各章节内容，
    最终输出Word格式的仿真分析报告。
    """
    
    def __init__(
        self,
        user_id: str = "report_generator",
        is_multiblock_processed: bool = False,
        specified_fields: Optional[List[str]] = None,
        colormap_type: str = "diverging",
        description: str = "",
    ):
        """
        初始化报告生成器
        
        Args:
            user_id: 用户ID，用于对话历史管理（每次生成报告时会自动创建新的会话ID）
            is_multiblock_processed: 是否是已做部件处理的模型（MultiBlock模型），
                                     如果为True，将使用专门的部件分析流程
            specified_fields: 指定要分析的属性场名称列表（精确匹配），
                             如 ["Velocity"] 只会匹配名为 "Velocity" 的字段
                             如果为 None，则分析所有属性场
            colormap_type: 颜色映射类型，可选值：
                          - "diverging": 红白蓝发散色彩（默认）
                          - "default": HSV彩虹色彩
            description: 仿真背景描述信息，用于提供已知的仿真背景知识，
                        帮助AI更准确地理解和分析仿真结果。例如可以提供：
                        - 仿真对象的描述（如"某型号汽车发动机缸盖"）
                        - 仿真目的（如"分析高温高压下的热应力分布"）
                        - 工况条件（如"入口压力10MPa，温度300℃"）
                        - 已知的设计要求或安全系数等
                        如果为空，则使用模型数据自动推断
        """
        self.user_id = user_id
        self.is_multiblock_processed = is_multiblock_processed
        self.specified_fields = specified_fields
        self.colormap_type = colormap_type
        self.description = description
        
        # 存储各章节内容
        self.chapters: Dict[str, str] = {}
        
        # 模型信息
        self.model_info: Optional[ModelInfo] = None
        
        # 模型数据（VTK DataObject）
        self.model_data: Optional[object] = None
        
        # 图片ID到文件路径的映射（用于报告转换时插入图片）
        self.image_map: Dict[str, str] = {}
        
        logger.info(f"报告生成器初始化完成，部件处理模式: {is_multiblock_processed}, 分析属性场: {specified_fields}, 颜色映射: {colormap_type}, 背景描述: {'已提供' if description else '未提供'}")
    
    def generate(self, model_path: str, output_path: str, description: str = "") -> bool:
        """
        生成CAE仿真分析报告
        
        Args:
            model_path: 仿真模型文件路径
            output_path: 输出Word文档路径
            description: 仿真背景描述信息（可选），用于提供已知的仿真背景知识，
                        帮助AI更准确地理解和分析仿真结果。
                        如果为空，则使用初始化时传入的description参数。
                        
        Returns:
            是否成功
        """
        # 如果传入的description为空，则使用初始化时的description
        if not description and self.description:
            description = self.description
        
        try:
            # 每次生成报告时，使用唯一的 conversation_id，确保没有历史记录干扰
            unique_conversation_id = f"report_{uuid.uuid4().hex[:16]}"
            logger.info(f"开始生成报告，模型文件: {model_path}, 会话ID: {unique_conversation_id}, 背景描述: {'已提供' if description else '未提供'}")
            
            # 重置 dialogue，使用新的 conversation_id，确保每次生成都是全新的对话
            reset_dialogue(self.user_id, unique_conversation_id)
            
            # 0. 读取模型数据
            logger.info("正在读取模型数据...")
            try:
                self.model_data = read_mesh_file(model_path, read_all_fields=False)
                logger.info("模型数据读取完成")
            except Exception as e:
                logger.error(f"读取模型数据失败: {e}")
                return False
            
            # 1. 提取模型信息
            logger.info("正在提取模型信息...")
            self.model_info = extract_model_info(self.model_data, file_path=model_path)
            if self.model_info is None:
                logger.error("无法提取模型信息")
                return False
            logger.info(f"模型信息提取完成: {self.model_info.num_points} 个顶点, {self.model_info.num_cells} 个单元")
            
            # 过滤属性场（如果指定了 specified_fields）
            if self.specified_fields:
                logger.info(f"过滤属性场，仅保留: {self.specified_fields}")
                self.model_info = filter_model_data_fields(
                    self.model_info,
                    required_point_fields=self.specified_fields,
                    required_cell_fields=self.specified_fields
                )
                logger.info(f"过滤后点属性场: {self.model_info.point_data_fields}")
                logger.info(f"过滤后单元属性场: {self.model_info.cell_data_fields}")

            # 1.1 生成模型图像
            logger.info("正在生成模型图像...")
            model_images, error = render_model_images(self.model_data)
            if error:
                logger.warning(f"生成模型图像时出错: {error}，将不使用图像分析")
                self.model_info.model_images = None
            else:
                self.model_info.model_images = model_images
                logger.info(f"模型图像生成完成: {len(model_images)} 张图像")
            
            # 1.2 识别模型类型
            if self.model_info.model_images:
                logger.info("正在识别模型类型...")
                try:
                    model_type = identify_model_type(self.model_info.model_images)
                    self.model_info.model_type = model_type
                    logger.info(f"模型类型识别完成: {model_type}")
                except Exception as e:
                    logger.warning(f"识别模型类型时出错: {e}，使用默认描述")
                    self.model_info.model_type = "3D仿真模型"
            else:
                self.model_info.model_type = "3D仿真模型"
            
            # 将description保存到model_info中，方便各章节使用
            if description:
                self.model_info.description = description
            
            # 2. 按顺序生成各章节内容
            # 生成顺序：第二章 → 第三章 → 第四章 → 第五章 → 第一章
            
            logger.info("正在生成第二章：仿真模型...")
            self.chapters["chapter_simulation_model"] = self._generate_chapter_simulation_model(description)
            
            logger.info("正在生成第三章：仿真结果...")
            self.chapters["chapter_simulation_results"] = self._generate_chapter_simulation_results(description)
            
            logger.info("正在生成第四章：结果讨论...")
            self.chapters["chapter_discussion"] = self._generate_chapter_discussion(description)
            
            logger.info("正在生成第五章：总结...")
            self.chapters["chapter_summary"] = self._generate_chapter_summary(description)
            
            logger.info("正在生成第一章：概述...")
            self.chapters["chapter_overview"] = self._generate_chapter_overview(description)
            
            # 3. 组合所有章节为完整报告
            logger.info("正在组合报告内容...")
            full_report = self._combine_chapters()
            
            # 4. 输出报告内容到txt文档，路径为output_path的同目录下
            logger.info("正在输出报告内容到txt文档...")
            with open(os.path.join(os.path.dirname(output_path), "report_content.txt"), "w", encoding="utf-8") as f:
                f.write(full_report)
            
            # 5. 调用Converter生成Word文档（传入图片映射）
            logger.info("正在生成Word文档...")
            success = ConvertTextToWordReport(full_report, output_path, image_map=self.image_map)
            
            if success:
                logger.info(f"报告生成成功: {output_path}")
            else:
                logger.error("报告生成失败")
            
            return success
            
        except Exception as e:
            logger.error(f"生成报告时发生错误: {e}", exc_info=True)
            return False
    
    def _generate_chapter_simulation_model(self, description: str = "") -> str:
        """生成第二章：仿真模型"""
        return generate_chapter_simulation_model(self.model_info, colormap_type=self.colormap_type, description=description)
    
    def _generate_chapter_simulation_results(self, description: str = "") -> str:
        """
        生成第三章：仿真结果
        
        对模型中的每个属性场进行可视化分析，生成完整的仿真结果章节。
        如果是部件处理过的模型，将使用专门的部件分析流程。
        """
        chapter_content, image_map = generate_chapter_simulation_results(
            self.model_info, 
            self.model_data, 
            self.is_multiblock_processed,
            description=description
        )
        self.image_map.update(image_map)
        return chapter_content
    
    def _generate_chapter_discussion(self, description: str = "") -> str:
        """生成第四章：结果讨论"""
        chapter_simulation_results_content = self.chapters.get("chapter_simulation_results", "")
        return generate_chapter_discussion(chapter_simulation_results_content, description=description)
    
    def _generate_chapter_summary(self, description: str = "") -> str:
        """生成第五章：总结"""
        chapter_simulation_results_content = self.chapters.get("chapter_simulation_results", "")
        chapter_discussion_content = self.chapters.get("chapter_discussion", "")
        return generate_chapter_summary(
            chapter_simulation_results_content,
            chapter_discussion_content,
            description=description
        )
    
    def _generate_chapter_overview(self, description: str = "") -> str:
        """生成第一章：概述"""
        return generate_chapter_overview(
            self.chapters.get("chapter_simulation_model", ""),
            self.chapters.get("chapter_simulation_results", ""),
            self.chapters.get("chapter_discussion", ""),
            self.chapters.get("chapter_summary", ""),
            description=description
        )
    
    def _combine_chapters(self) -> str:
        """
        将各章节内容组合为完整报告

        注意：报告大标题已在第一章内容中由LLM自动生成，这里不再重复添加。

        Returns:
            完整的报告文本（Markdown格式）
        """
        # 按顺序组合各章节（第一章 → 第二章 → 第三章 → 第四章 → 第五章）
        chapters_order = [
            "chapter_overview",
            "chapter_simulation_model",
            "chapter_simulation_results",
            "chapter_discussion",
            "chapter_summary"
        ]

        report_content = ""
        for chapter_key in chapters_order:
            chapter_content = self.chapters.get(chapter_key, "")
            if chapter_content:
                report_content += chapter_content + "\n\n"

        return report_content.strip()


# 便捷函数
def GenerateCAEReport(
    model_path: str, 
    output_path: str, 
    user_id: str = "report_generator",
    is_multiblock_processed: bool = False,
    specified_fields: Optional[List[str]] = None,
    colormap_type: str = "diverging",
    description: str = "",
) -> bool:
    """
    便捷函数：生成CAE仿真分析报告
    
    Args:
        model_path: 仿真模型文件路径
        output_path: 输出Word文档路径
        user_id: 用户ID，用于对话历史管理（每次生成报告时会自动创建新的会话ID）
        is_multiblock_processed: 是否是已做部件处理的模型（MultiBlock模型），
                                 如果为True，将使用专门的部件分析流程，
                                 会读取每个block的名称，对标量场进行区域分析，
                                 并聚焦渲染需要关注的部件区域
        specified_fields: 指定要分析的属性场名称列表（精确匹配），
                         如 ["Velocity"] 只会匹配名为 "Velocity" 的字段
                         如果为 None，则分析所有属性场
        colormap_type: 颜色映射类型，可选值：
                      - "diverging": 红白蓝发散色彩（默认）
                      - "default": HSV彩虹色彩
        description: 仿真背景描述信息，用于提供已知的仿真背景知识，
                    帮助AI更准确地理解和分析仿真结果。例如可以提供：
                    - 仿真对象的描述（如"某型号汽车发动机缸盖"）
                    - 仿真目的（如"分析高温高压下的热应力分布"）
                    - 工况条件（如"入口压力10MPa，温度300℃"）
                    - 已知的设计要求或安全系数等
        
    Returns:
        是否成功
        
    Example:
        # 普通模型
        success = GenerateCAEReport(
            model_path="/path/to/model.vtk",
            output_path="/path/to/report.docx"
        )
        
        # 部件处理过的MultiBlock模型
        success = GenerateCAEReport(
            model_path="/path/to/model.vtm",
            output_path="/path/to/report.docx",
            is_multiblock_processed=True
        )
        
        # 只分析 Velocity 相关属性场
        success = GenerateCAEReport(
            model_path="/path/to/model.vtm",
            output_path="/path/to/report.docx",
            is_multiblock_processed=True,
            specified_fields=["Velocity"]
        )
        
        # 提供仿真背景描述
        success = GenerateCAEReport(
            model_path="/path/to/model.vtk",
            output_path="/path/to/report.docx",
            description="某型号汽车发动机缸盖，分析高温高压下的热应力分布"
        )
    """
    # 清空上次生成的临时渲染图片，避免残留文件干扰本次报告
    cleanup_temp_images()

    generator = ReportGenerator(
        user_id=user_id, 
        is_multiblock_processed=is_multiblock_processed,
        specified_fields=specified_fields,
        colormap_type=colormap_type,
        description=description
    )
    return generator.generate(model_path, output_path)


# 导出
__all__ = [
    "ModelInfo",
    "ReportGenerator",
    "GenerateCAEReport",
]


if __name__ == "__main__":
    # 测试示例
    import argparse
    
    parser = argparse.ArgumentParser(description="CAE仿真分析报告生成器")
    parser.add_argument("model_path", help="仿真模型文件路径")
    parser.add_argument("-o", "--output", default="cae_report.docx", help="输出报告路径")
    
    args = parser.parse_args()
    
    success = GenerateCAEReport(args.model_path, args.output)
    
    if success:
        print(f"✓ 报告已成功生成: {args.output}")
    else:
        print("✗ 报告生成失败")
        sys.exit(1)

