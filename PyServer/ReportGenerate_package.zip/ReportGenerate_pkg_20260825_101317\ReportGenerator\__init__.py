"""
CAE仿真分析报告生成器模块

包含:
- ReportGenerator: 报告生成器，根据模型文件自动生成报告
- ReportConverter: 报告转换器，将标记文本转换为Word文档
- ReportType: 报告类型和模板定义
"""

from ReportGenerator.ReportType import (
    ReportElementType,
    TextStyle,
    CAEReportTemplate,
)

from ReportGenerator.ReportConverter import (
    TextElement,
    ReportParser,
    WordExporter,
    ReportConverter,
    ConvertTextToWordReport,
    ConvertMdToWordReport,
)

from ReportGenerator.ReportGenerator import (
    ModelInfo,
    ReportGenerator,
    GenerateCAEReport,
)

__all__ = [
    # ReportType
    "ReportElementType",
    "TextStyle",
    "CAEReportTemplate",
    # ReportConverter
    "TextElement",
    "ReportParser",
    "WordExporter",
    "ReportConverter",
    "ConvertTextToWordReport",
    "ConvertMdToWordReport",
    # ReportGenerator
    "ModelInfo",
    "ReportGenerator",
    "GenerateCAEReport",
]
