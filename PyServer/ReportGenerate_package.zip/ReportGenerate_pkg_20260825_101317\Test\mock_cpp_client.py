# ============================================================================
# MeshReport 服务器测试客户端
#
# 模拟 C++ 端 MeshReportGenerator/MeshReportClient 的行为：
# 读取一个本地 VTK 文件，通过 MeshReport 协议发给服务器，
# 把收到的报告文件（或错误信息）保存在本目录下。
#
# 本文件完全独立，不依赖 Server/ 下的任何模块，自行内联实现协议编解码
# （与 Server/protocol.py 描述的协议格式严格一致，仅用于本地测试）：
#   发送: [4B vtk_size][vtk_data]
#   接收: [1B success][4B report_size][report_data] 或 [1B=0][4B msg_size][error_msg]
#
# 属性过滤在 C++ 端完成，测试客户端直接发送文件中的全部属性。
#
# 用法:
#   python mock_cpp_client.py <vtk文件路径> [--host 127.0.0.1] [--port 8766]
#                              [--output report.docx]
#
# 若不指定 <vtk文件路径>，默认使用本目录下的 input.vtk。
# ============================================================================

import argparse
import os
import socket
import struct
import sys
from datetime import datetime
from typing import Tuple

_TEST_DIR = os.path.dirname(os.path.abspath(__file__))

_UINT32 = struct.Struct("<I")


def _recv_exact(sock: socket.socket, size: int) -> bytes:
    """从 socket 精确读取 size 字节，连接提前关闭时抛出 ConnectionError"""
    chunks = []
    remaining = size
    while remaining > 0:
        chunk = sock.recv(remaining)
        if not chunk:
            raise ConnectionError("Connection closed while receiving data")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def _send_uint32(sock: socket.socket, value: int) -> None:
    sock.sendall(_UINT32.pack(value))


def _recv_uint32(sock: socket.socket) -> int:
    return _UINT32.unpack(_recv_exact(sock, 4))[0]


def _send_data(sock: socket.socket, data: bytes) -> None:
    """写入 [4B size][data] 格式的定长数据块"""
    _send_uint32(sock, len(data))
    sock.sendall(data)


def _recv_data(sock: socket.socket) -> bytes:
    """读取 [4B size][data] 格式的定长数据块"""
    size = _recv_uint32(sock)
    return _recv_exact(sock, size)


def send_request(sock: socket.socket, vtk_data: bytes) -> None:
    """发送一次完整的 MeshReportRequest（模拟 C++ MeshReportClient::requestReport）"""
    _send_data(sock, vtk_data)


def recv_response(sock: socket.socket) -> Tuple[bool, bytes]:
    """
    接收一次完整的 MeshReportResponse

    Returns:
        (success, payload)
        success=True 时 payload 是报告文件二进制内容
        success=False 时 payload 是 utf-8 编码的错误信息
    """
    success_flag = _recv_exact(sock, 1)
    success = success_flag == bytes([1])
    payload = _recv_data(sock)
    return success, payload


def main() -> None:
    parser = argparse.ArgumentParser(description="MeshReport 服务器测试客户端（模拟 C++ 端）")
    parser.add_argument(
        "vtk_file",
        nargs="?",
        default=os.path.join(_TEST_DIR, "input.vtk"),
        help="要发送的 VTK 文件路径，默认 Test/input.vtk",
    )
    parser.add_argument("--host", default="127.0.0.1", help="服务器地址，默认 127.0.0.1")
    parser.add_argument("--port", type=int, default=8766, help="服务器端口，默认 8766")
    parser.add_argument(
        "--output", default=None,
        help="报告保存路径，默认 Test/report_<时间戳>.docx",
    )
    args = parser.parse_args()

    if not os.path.exists(args.vtk_file):
        print(f"错误: VTK 文件不存在: {args.vtk_file}")
        sys.exit(1)

    with open(args.vtk_file, "rb") as f:
        vtk_data = f.read()
    print(f"已读取 VTK 文件: {args.vtk_file} ({len(vtk_data)} 字节)")

    output_path = args.output
    if output_path is None:
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        output_path = os.path.join(_TEST_DIR, f"report_{timestamp}.docx")

    print(f"正在连接服务器 {args.host}:{args.port} ...")
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect((args.host, args.port))
        print("已连接，发送请求...")
        send_request(sock, vtk_data)

        print("请求已发送，等待服务器处理并返回报告（报告生成可能耗时较长）...")
        success, payload = recv_response(sock)
    except Exception as e:
        print(f"通信过程中发生错误: {e}")
        sys.exit(1)
    finally:
        sock.close()

    if not success:
        error_message = payload.decode("utf-8", errors="replace")
        print(f"服务器返回错误: {error_message}")
        sys.exit(1)

    with open(output_path, "wb") as f:
        f.write(payload)
    print(f"报告已保存: {output_path} ({len(payload)} 字节)")


if __name__ == "__main__":
    main()
