"""
第四章：结果讨论生成器
负责生成结果讨论章节内容，对仿真结果进行深入分析和讨论
"""

import logging

# 设置日志
logger = logging.getLogger(__name__)


# 章节Prompt模板
CHAPTER_PROMPT = """你是一位CAE仿真工程师，正在撰写仿真分析报告的第四章"结果讨论"。

{fengjing_description}**第三章仿真结果内容**：
{chapter_simulation_results_content}

**写作原则**：
1. **报告身份**：你是这份报告的编写者，报告内容应像工程师已完成分析后撰写的正式文档，读者只能看到最终结论，看不到分析过程
2. **禁止描述过程**：严禁使用"我将"、"本节将"、"基于以上分析"、"通过XX方法"、"结合XX进行"等描述分析过程或思考路径的措辞
3. **直接陈述结论**：使用直接陈述方式呈现结论和分析发现，例如"结果表明"、"分布特征显示"、"分析表明"等，而非"我将对这些现象进行分析"
4. **内容边界**：仅基于第三章中实际呈现的仿真结果内容进行讨论和分析，不凭空编造任何不存在于原内容中的现象或结论
5. **禁止假设**：不添加原内容中未提及的建议、推测或优化方向，第四章为分析性讨论章节，主要职责是解读现象，非提出改进方案
6. **数据引用**：如需引用具体数值，必须确保该数值在第三章内容中实际存在，严格基于事实

**章节结构**：
- ### 4.1 仿真类型与应用场景
- ### 4.2 结果分布特征分析
- ### 4.3 极值区域分析
- ### 4.4 合理性评估
- ### 4.5 典型区域特征

**格式要求**：
- 使用Markdown格式，二级标题使用 ###
- 用连贯段落形式描述，不使用列表形式
- 语言正式、专业，数值必须标注单位
- 以工程技术报告的规范行文，直接、客观陈述分析结论

**输出格式**：
直接输出报告内容，不需要任何前缀说明。

输出的内容必须包含以下全部部分，顺序不得打乱：

## 4. 结果讨论

### 4.1 仿真类型与应用场景

（正文内容）

### 4.2 结果分布特征分析

（正文内容）

### 4.3 极值区域分析

（正文内容）

### 4.4 合理性评估

（正文内容）

### 4.5 典型区域特征

（正文内容）"""


def generate_chapter_discussion(chapter_simulation_results_content: str, description: str = "") -> str:
    """
    生成第四章：结果讨论
    
    对第三章的仿真结果进行深入的专业讨论和分析，包括：
    - 仿真类型与应用场景分析
    - 结果合理性评估
    - 潜在问题识别与原因分析
    - 工程影响评估
    - 优化建议与改进方向
    
    Args:
        chapter_simulation_results_content: 第三章仿真结果的内容
        description: 仿真背景描述信息（可选）
        
    Returns:
        生成的章节内容（Markdown格式）
    """
    from utils import call_llm, reset_dialogue
    import uuid
    
    # 创建独立的对话会话，避免受到其他章节的影响
    conversation_id = f"discussion_{uuid.uuid4().hex[:12]}"
    reset_dialogue("report_generator", conversation_id)
    logger.info(f"为第四章创建独立对话会话: {conversation_id}")
    
    # 处理背景描述信息
    fengjing_description_str = ""
    if description:
        fengjing_description_str = f"""**用户提供的仿真背景描述**：
{description}

---

"""
    
    prompt = CHAPTER_PROMPT.format(
        fengjing_description=fengjing_description_str,
        chapter_simulation_results_content=chapter_simulation_results_content
    )
    
    chapter_content = call_llm(prompt)
    
    logger.info("第四章：结果讨论 生成完成")
    return chapter_content


__all__ = [
    "generate_chapter_discussion",
]
