# ============================================================================
# 辅助函数
# ============================================================================

import os
import vtk
import numpy as np
from PIL import Image
from io import BytesIO
import base64

import sys
import logging
from typing import Optional, List

# 将项目根目录添加到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from Dialogue.Dialogue import Dialogue, create_dialogue
from PredefinedStrs.Config import CAE_COLLECTION
# 设置日志
logger = logging.getLogger(__name__)

# 全局Dialogue实例（延迟初始化）
_global_dialogue: Optional[Dialogue] = None


def _get_dialogue() -> Dialogue:
    """
    获取全局Dialogue实例（单例模式）
    
    Returns:
        Dialogue实例
    """
    global _global_dialogue
    if _global_dialogue is None:
        _global_dialogue = create_dialogue(
            user_id="report_generator",
            conversation_id="cae_report",
            collection_name=None,
            stream=False,  # 报告生成使用非流式输出
            enable_rerank=False,  # 报告生成不需要rerank
        )
    return _global_dialogue


def call_llm(prompt: str, images: Optional[List] = None) -> str:
    """
    统一的LLM调用函数（支持图像输入）
    
    Args:
        prompt: 提示词
        images: 可选的图像列表（base64字符串或文件路径）
        
    Returns:
        LLM生成的内容
    """
    try:
        dialogue = _get_dialogue()
        
        # 调用chat接口，收集所有输出
        if images:
            response = ''.join(dialogue.chat(prompt, images=images))
        else:
            response = ''.join(dialogue.chat(prompt))
        
        return response.strip()
    except Exception as e:
        logger.error(f"调用LLM时发生错误: {e}")
        return ""


def reset_dialogue(user_id: str = "report_generator", conversation_id: str = "cae_report"):
    """
    重置全局Dialogue实例（用于切换用户或会话）
    
    Args:
        user_id: 用户ID
        conversation_id: 会话ID
    """
    _global_dialogue=_get_dialogue()
    _global_dialogue.set_user_and_conversation(user_id, conversation_id)



def read_mesh_file(filename: str, read_all_fields: bool = False) -> vtk.vtkDataObject:
    """
    读取VTK格式的网格文件
    
    Args:
        filename: 文件路径
        read_all_fields: 是否读取所有字段（包括非激活字段）
        
    Returns:
        VTK数据对象（multiblock或polydata）
    """
    if not os.path.exists(filename):
        raise FileNotFoundError(f"文件不存在: {filename}")
    
    file_ext = os.path.splitext(filename)[1].lower().lstrip('.')
    
    readers = {
        'vtm': vtk.vtkXMLMultiBlockDataReader,
        'vtk': vtk.vtkDataSetReader,
        'vtu': vtk.vtkXMLUnstructuredGridReader,
        'vtp': vtk.vtkXMLPolyDataReader,
        'ply': vtk.vtkPLYReader,
        'obj': vtk.vtkOBJReader,
        'stl': vtk.vtkSTLReader,
    }
    
    if file_ext == 'glb':
        try:
            reader = vtk.vtkGLTFReader()
            reader.SetFileName(filename)
            reader.Update()
            return reader.GetOutput()
        except:
            raise ValueError("GLB格式需要VTK的GLTF支持，请先转换为其他格式")
    
    if file_ext not in readers:
        raise ValueError(f"不支持的文件格式: {file_ext}")
    
    reader = readers[file_ext]()
    reader.SetFileName(filename)
    
    # 启用读取所有字段（如果支持）
    if read_all_fields:
        if hasattr(reader, 'ReadAllScalarsOn'):
            reader.ReadAllScalarsOn()
        if hasattr(reader, 'ReadAllVectorsOn'):
            reader.ReadAllVectorsOn()
        if hasattr(reader, 'ReadAllTensorsOn'):
            reader.ReadAllTensorsOn()
        if hasattr(reader, 'ReadAllFieldsOn'):
            reader.ReadAllFieldsOn()
    
    reader.Update()
    return reader.GetOutput()


def write_mesh_file(filename: str, data: vtk.vtkDataObject) -> bool:
    """
    将VTK数据对象写入文件
    
    Args:
        filename: 文件路径
        data: VTK数据对象
        
    Returns:
        是否成功写入
    """
    try:
        file_ext = os.path.splitext(filename)[1].lower().lstrip('.')
        
        writers = {
            'vtm': vtk.vtkXMLMultiBlockDataWriter,
            'vtu': vtk.vtkXMLUnstructuredGridWriter,
            'vtp': vtk.vtkXMLPolyDataWriter,
            'vtk': vtk.vtkDataSetWriter,
            'ply': vtk.vtkPLYWriter,
            'stl': vtk.vtkSTLWriter,
        }
        
        if file_ext not in writers:
            logger.warning(f"不支持的写入格式: {file_ext}，尝试使用 vtkDataSetWriter")
            writer = vtk.vtkDataSetWriter()
        else:
            writer = writers[file_ext]()
            
        writer.SetFileName(filename)
        writer.SetInputData(data)
        
        if hasattr(writer, 'SetDataModeToBinary'):
            writer.SetDataModeToBinary()
            
        return writer.Write() == 1
    except Exception as e:
        logger.error(f"写入网格文件时发生错误: {e}")
        return False


def _encode_image(image_array: np.ndarray) -> str:
    """
    将numpy数组转换为base64字符串
    
    Args:
        image_array: numpy数组图像
        
    Returns:
        base64编码的字符串
    """
    # 确保是uint8类型
    if image_array.dtype != np.uint8:
        if image_array.max() <= 1.0:
            image_array = (image_array * 255).astype(np.uint8)
        else:
            image_array = image_array.astype(np.uint8)
    
    pil_image = Image.fromarray(image_array)
    buffer = BytesIO()
    pil_image.save(buffer, format="PNG")
    buffer.seek(0)
    return base64.b64encode(buffer.read()).decode('utf-8')


def cleanup_temp_images() -> None:
    """
    清空 TempData 目录中的所有旧 PNG 图片。
    在每次报告生成前调用，避免上一次生成的渲染图片残留
    干扰本次生成的图像选择/引用。
    """
    try:
        temp_dir = os.path.join(project_root, "TempData")
        if not os.path.isdir(temp_dir):
            logger.info("TempData 目录不存在，跳过清理: %s", temp_dir)
            return
        removed = 0
        for name in os.listdir(temp_dir):
            if name.lower().endswith(".png"):
                file_path = os.path.join(temp_dir, name)
                try:
                    os.remove(file_path)
                    removed += 1
                except OSError as e:
                    logger.warning("清理旧图片失败: %s (%s)", file_path, e)
        logger.info("已清理 TempData 中的旧 PNG 图片 %d 个", removed)
    except Exception as e:
        logger.error(f"清空 TempData 时发生错误: {e}", exc_info=True)


def save_image_to_temp(image_array: np.ndarray, filename: str) -> Optional[str]:
    """
    将图像保存到临时文件夹 TempData 中
    
    Args:
        image_array: 渲染后的图像数组 (H, W, C)，numpy.ndarray 类型
        filename: 文件名（可以包含扩展名，如果不包含则默认使用 .png）
        
    Returns:
        保存的文件完整路径，失败返回 None
    """
    try:
        # 确保是uint8类型
        if image_array.dtype != np.uint8:
            if image_array.max() <= 1.0:
                image_array = (image_array * 255).astype(np.uint8)
            else:
                image_array = image_array.astype(np.uint8)
        
        # 创建 TempData 文件夹（在项目根目录下）
        temp_dir = os.path.join(project_root, "TempData")
        os.makedirs(temp_dir, exist_ok=True)
        
        # 确保文件名有扩展名
        if not os.path.splitext(filename)[1]:
            filename = filename + ".png"
        
        # 构建完整路径
        file_path = os.path.join(temp_dir, filename)
        
        # 转换为 PIL Image 并保存
        pil_image = Image.fromarray(image_array)
        pil_image.save(file_path, format="PNG")
        
        logger.info(f"图像已保存到: {file_path}")
        return file_path
        
    except Exception as e:
        logger.error(f"保存图像到临时文件夹时发生错误: {e}", exc_info=True)
        return None


__all__ = [
    "call_llm",
    "reset_dialogue",
    "read_mesh_file",
    "write_mesh_file",
    "_encode_image",
    "save_image_to_temp",
    "cleanup_temp_images",
]

