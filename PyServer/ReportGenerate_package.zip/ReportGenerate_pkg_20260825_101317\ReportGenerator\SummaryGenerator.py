"""
第五章：总结生成器
负责生成总结章节内容，包括主要结论、建议和参考文献
"""

import logging
from typing import List, Optional

# 设置日志
logger = logging.getLogger(__name__)


# 章节Prompt模板
CHAPTER_PROMPT = """你是一位CAE仿真工程师，正在撰写仿真分析报告的第五章"总结"。

{fengjing_description}**第三章仿真结果摘要**：
{chapter_simulation_results_summary}

**第四章结果讨论摘要**：
{chapter_discussion_summary}

**写作原则**：
1. **报告身份**：你是这份报告的编写者，报告内容应像工程师已完成分析后撰写的正式文档，读者只能看到最终结论，看不到分析过程
2. **禁止描述过程**：严禁使用"我将"、"本章总结"、"通过分析"、"基于以上"等描述分析过程或思考路径的措辞
3. **直接陈述结论**：使用直接陈述方式呈现总结，例如"分析表明"、"结果表明"、"本次仿真显示"等，而非"下面进行总结"
4. **内容范围**：仅基于第三章仿真结果和第四章讨论中实际呈现的内容进行总结，不添加任何未经证实的推测或假设
5. **数据引用**：如需引用具体数值，确保该数值在上述摘要内容中实际出现过，不得凭空编造
6. **禁止事项**：
   - 禁止使用"根据观测结果"、"通过工具识别"等工具视角描述
   - 禁止添加摘要中未涉及的分析结论或建议
   - 禁止使用"令人惊讶的是"、"值得注意的是"等主观评价色彩浓厚的措辞

**格式要求**：
使用连贯段落形式，不使用列表，以专业工程技术报告的规范行文

**输出格式**：
直接输出报告内容，不需要任何前缀说明。格式如下：

## 5. 总结

（总结段落，2-3段话，概括主要仿真结论和发现）"""


def _get_summary(content: str, max_len: int = 800) -> str:
    """提取内容摘要"""
    if not content:
        return "（无内容）"
    if len(content) > max_len:
        return content[:max_len] + "..."
    return content


def _format_references(references: List[str]) -> str:
    """
    格式化参考文献列表
    
    Args:
        references: 参考文献列表（知识库来源）
        
    Returns:
        格式化的参考文献字符串
    """
    if not references:
        return ""
    
    ref_lines = ["", "## 参考文献", ""]
    for i, ref in enumerate(references, 1):
        # 格式化参考文献条目 [REF:编号:内容]
        ref_lines.append(f"[REF:{i}:{ref}]")
    
    return "\n".join(ref_lines)


def generate_chapter_summary(
    chapter_simulation_results_content: str,
    chapter_discussion_content: str,
    references: Optional[List[str]] = None,
    description: str = "",
) -> str:
    """
    生成第五章：总结
    
    包含主要结论、改进建议和参考文献（如有）
    
    Args:
        chapter_simulation_results_content: 第三章仿真结果的内容
        chapter_discussion_content: 第四章结果讨论的内容
        references: 参考文献列表（来自知识库的引用）
        description: 仿真背景描述信息（可选）
        
    Returns:
        生成的章节内容（包含参考文献）
    """
    from utils import call_llm, reset_dialogue
    import uuid
    
    # 创建独立的对话会话
    conversation_id = f"summary_{uuid.uuid4().hex[:12]}"
    reset_dialogue("report_generator", conversation_id)
    logger.info(f"为第五章创建独立对话会话: {conversation_id}")
    
    # 处理背景描述信息
    fengjing_description_str = ""
    if description:
        fengjing_description_str = f"""**用户提供的仿真背景描述**：
{description}

---

"""
    
    prompt = CHAPTER_PROMPT.format(
        fengjing_description=fengjing_description_str,
        chapter_simulation_results_summary=_get_summary(chapter_simulation_results_content),
        chapter_discussion_summary=_get_summary(chapter_discussion_content)
    )
    
    chapter_content = call_llm(prompt)
    
    # 添加参考文献（如果有）
    if references:
        ref_section = _format_references(references)
        chapter_content += ref_section
        logger.info(f"添加了 {len(references)} 条参考文献")
    
    logger.info("第五章：总结 生成完成")
    return chapter_content


__all__ = [
    "generate_chapter_summary",
]
