"""
CAE仿真分析报告生成器
将AI生成的标记文本转换为格式化的Word文档
"""

import re
import logging
from typing import List, Optional, Tuple, Dict
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn

# 将项目根目录添加到 Python 路径
import os
import sys
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from ReportType import (
    ReportElementType,
    TextStyle,
    CAEReportTemplate,
)

# 设置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class TextElement:
    """文本元素类，表示解析后的文本片段"""
    
    def __init__(self, element_type: ReportElementType, content: str, 
                 inline_styles: Optional[List[Tuple[str, int, int]]] = None,
                 image_path: Optional[str] = None,
                 caption: Optional[str] = None):
        """
        Args:
            element_type: 元素类型
            content: 文本内容（对于图片元素，可以是图片ID或描述）
            inline_styles: 内联样式列表，格式为 [(style_type, start, end), ...]
                          style_type可以是'bold'或'italic'
            image_path: 图片文件路径（仅用于IMAGE类型元素）
            caption: 图片图注（仅用于IMAGE类型元素）
        """
        self.element_type = element_type
        self.content = content
        self.inline_styles = inline_styles or []
        self.image_path = image_path  # 图片文件路径
        self.caption = caption  # 图片图注


class ReportParser:
    """报告文本解析器，将标记文本解析为结构化元素"""
    
    def __init__(self, template: CAEReportTemplate = None):
        self.template = template or CAEReportTemplate()
    
    def parse(self, text: str) -> List[TextElement]:
        """
        解析标记文本，返回文本元素列表
        
        Args:
            text: 包含标记的文本字符串
            
        Returns:
            文本元素列表
        """
        elements = []
        lines = text.split('\n')
        
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            if not line:
                i += 1
                continue
            
            # 检查标题标记
            if line.startswith('# '):
                # 报告主题
                title = line[2:].strip()
                elements.append(TextElement(ReportElementType.TITLE, title))
            elif line.startswith('## '):
                # 一级标题
                heading = line[3:].strip()
                elements.append(TextElement(ReportElementType.HEADING_1, heading))
            elif line.startswith('### '):
                # 二级标题
                heading = line[4:].strip()
                elements.append(TextElement(ReportElementType.HEADING_2, heading))
            elif line.startswith('#### '):
                # 三级标题
                heading = line[5:].strip()
                elements.append(TextElement(ReportElementType.HEADING_3, heading))
            elif line.startswith('- '):
                # 列表项
                list_content = line[2:].strip()
                # 解析内联样式（加粗、斜体）
                inline_styles = self._parse_inline_styles(list_content)
                elements.append(TextElement(ReportElementType.LIST_ITEM, list_content, inline_styles))
            elif line.startswith('[REF:') and line.endswith(']'):
                # 参考文献条目 [REF:编号:内容]
                ref_match = re.match(r'\[REF:(\d+):(.+)\]', line)
                if ref_match:
                    ref_num = ref_match.group(1)
                    ref_content = ref_match.group(2)
                    elements.append(TextElement(ReportElementType.REFERENCE, f"[{ref_num}] {ref_content}"))
                else:
                    inline_styles = self._parse_inline_styles(line)
                    elements.append(TextElement(ReportElementType.PARAGRAPH, line, inline_styles))
            elif line == '## 参考文献' or line == '## References':
                # 参考文献标题
                elements.append(TextElement(ReportElementType.REFERENCE_TITLE, "参考文献"))
            elif line.strip().startswith('[IMAGE:'):
                # 独立的图片标记行 [IMAGE:image_id:caption]
                # 提取图片ID和图注
                image_match = re.match(r'\[IMAGE:([^:\]]+)(?::([^\]]+))?\]', line.strip())
                if image_match:
                    image_id = image_match.group(1)
                    caption = image_match.group(2) if image_match.group(2) else None
                    element = TextElement(ReportElementType.IMAGE, image_id)
                    element.caption = caption
                    elements.append(element)
                else:
                    # 如果格式不对，作为普通文本处理
                    inline_styles = self._parse_inline_styles(line)
                    elements.append(TextElement(ReportElementType.PARAGRAPH, line, inline_styles))
            else:
                # 普通段落，需要处理内联样式（加粗、斜体）和图片标记
                paragraph = line
                # 处理多行段落（直到遇到空行或下一个标题）
                while i + 1 < len(lines):
                    next_line = lines[i + 1].strip()
                    if not next_line or next_line.startswith('#'):
                        break
                    if next_line.startswith('- '):
                        break
                    # 注意：不再检查 [IMAGE:，让图片标记在下一轮单独处理
                    # 图片标记不会打断段落合并，它会被单独提取为元素
                    paragraph += ' ' + next_line
                    i += 1
                
                # 检查并提取图片标记 [IMAGE:image_id:caption] 或 ![image_id]
                paragraph_parts = self._extract_images_from_text(paragraph)
                
                for part_type, part_content, part_caption in paragraph_parts:
                    if part_type == 'image':
                        # 图片元素：content 存储图片ID，image_path 在后续处理中设置
                        # 使用 caption 作为额外的属性（暂时存储在 content 中，后续会处理）
                        element = TextElement(ReportElementType.IMAGE, part_content)
                        element.caption = part_caption  # 存储图注
                        elements.append(element)
                    else:
                        # 文本段落
                        inline_styles = self._parse_inline_styles(part_content)
                        elements.append(TextElement(ReportElementType.PARAGRAPH, part_content, inline_styles))
            
            i += 1
        
        return elements
    
    def _parse_inline_styles(self, text: str) -> List[Tuple[str, int, int]]:
        """
        解析文本中的内联样式标记（加粗、斜体）
        
        Args:
            text: 原始文本
            
        Returns:
            样式列表，格式为 [(style_type, start, end), ...]
        """
        styles = []
        
        # 处理加粗标记 **text**
        bold_pattern = r'\*\*(.+?)\*\*'
        for match in re.finditer(bold_pattern, text):
            start = match.start()
            end = match.end()
            content = match.group(1)
            # 记录加粗样式（需要减去标记符号的长度）
            styles.append(('bold', start, start + len(content) + 4))
        
        # 处理斜体标记 *text*（但不在**内部）
        italic_pattern = r'(?<!\*)\*([^*]+?)\*(?!\*)'
        for match in re.finditer(italic_pattern, text):
            start = match.start()
            end = match.end()
            content = match.group(1)
            # 检查是否在加粗标记内部
            in_bold = False
            for bold_start, bold_end, _ in [(s[1], s[2], s[0]) for s in styles if s[0] == 'bold']:
                if bold_start <= start < bold_end:
                    in_bold = True
                    break
            if not in_bold:
                styles.append(('italic', start, start + len(content) + 2))
        
        return styles
    
    def _extract_images_from_text(self, text: str) -> List[Tuple[str, str, Optional[str]]]:
        """
        从文本中提取图片标记，将文本分割为文本片段和图片标记
        
        Args:
            text: 原始文本
            
        Returns:
            片段列表，格式为 [('text', '文本内容', None), ('image', 'image_id', 'caption'), ...]
        """
        parts = []
        # 匹配 [IMAGE:image_id:caption] 或 [IMAGE:image_id] 或 ![image_id] 格式
        # 支持带图注和不带图注两种格式
        image_pattern = r'\[IMAGE:([^:\]]+)(?::([^\]]+))?\]|!\[([^\]]+)\]'
        
        last_pos = 0
        for match in re.finditer(image_pattern, text):
            # 添加标记前的文本
            if match.start() > last_pos:
                text_part = text[last_pos:match.start()].strip()
                if text_part:
                    parts.append(('text', text_part, None))
            
            # 提取图片ID和图注
            if match.group(1):  # [IMAGE:image_id:caption] 或 [IMAGE:image_id]
                image_id = match.group(1)
                caption = match.group(2) if match.group(2) else None
            else:  # ![image_id]
                image_id = match.group(3)
                caption = None
            
            if image_id:
                parts.append(('image', image_id, caption))
            
            last_pos = match.end()
        
        # 添加剩余的文本
        if last_pos < len(text):
            text_part = text[last_pos:].strip()
            if text_part:
                parts.append(('text', text_part, None))
        
        # 如果没有找到图片标记，返回整个文本
        if not parts:
            parts.append(('text', text, None))
        
        return parts
    

class WordExporter:
    """Word文档导出器"""
    
    def __init__(self, template: CAEReportTemplate = None):
        self.template = template or CAEReportTemplate()
        self.image_counter = 0  # 图片计数器，用于生成"图1"、"图2"等编号
    
    def export(self, elements: List[TextElement], output_path: str) -> bool:
        """
        将文本元素列表导出为Word文档
        
        Args:
            elements: 文本元素列表
            output_path: 输出文件路径
            
        Returns:
            是否成功
        """
        try:
            doc = Document()
            
            # 设置文档默认字体
            self._set_document_fonts(doc)
            
            for element in elements:
                self._add_element(doc, element)
            
            # 确保输出目录存在
            os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else '.', exist_ok=True)
            
            doc.save(output_path)
            logger.info(f"报告已成功导出到: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"导出Word文档失败: {e}", exc_info=True)
            return False
    
    def _set_document_fonts(self, doc: Document):
        """设置文档的默认中英文字体"""
        # 设置正文样式
        style = doc.styles['Normal']
        font = style.font
        font.name = '宋体'
        font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), '宋体')
        font.size = Pt(12)
    
    def _add_element(self, doc: Document, element: TextElement):
        """向文档添加一个文本元素"""
        style_config = self.template.get_style(element.element_type)
        
        if element.element_type == ReportElementType.TITLE:
            self._add_title(doc, element.content, style_config)
        elif element.element_type in [ReportElementType.HEADING_1, 
                                      ReportElementType.HEADING_2, 
                                      ReportElementType.HEADING_3]:
            self._add_heading(doc, element.content, element.element_type, style_config)
        elif element.element_type == ReportElementType.LIST_ITEM:
            self._add_list_item(doc, element.content, style_config, element.inline_styles)
        elif element.element_type == ReportElementType.PARAGRAPH:
            self._add_paragraph(doc, element.content, style_config, element.inline_styles)
        elif element.element_type == ReportElementType.IMAGE:
            self._add_image(doc, element)
        elif element.element_type == ReportElementType.REFERENCE_TITLE:
            self._add_reference_title(doc, element.content, style_config)
        elif element.element_type == ReportElementType.REFERENCE:
            self._add_reference(doc, element.content, style_config)
    
    def _add_title(self, doc: Document, text: str, style: TextStyle):
        """添加标题"""
        paragraph = doc.add_paragraph()
        paragraph.alignment = self._get_alignment(style.alignment)
        
        run = paragraph.add_run(text)
        run.font.name = style.font_name
        run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
        run.font.size = Pt(style.font_size)
        run.bold = style.bold
        
        paragraph.paragraph_format.space_before = Pt(style.space_before)
        paragraph.paragraph_format.space_after = Pt(style.space_after)
    
    def _add_heading(self, doc: Document, text: str, element_type: ReportElementType, style: TextStyle):
        """添加标题（一级、二级、三级）"""
        paragraph = doc.add_paragraph()
        paragraph.alignment = self._get_alignment(style.alignment)
        
        run = paragraph.add_run(text)
        run.font.name = style.font_name
        run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
        run.font.size = Pt(style.font_size)
        run.bold = style.bold
        
        paragraph.paragraph_format.space_before = Pt(style.space_before)
        paragraph.paragraph_format.space_after = Pt(style.space_after)
    
    def _add_paragraph(self, doc: Document, text: str, style: TextStyle, inline_styles: List[Tuple[str, int, int]]):
        """添加段落，支持内联样式"""
        paragraph = doc.add_paragraph()
        paragraph.alignment = self._get_alignment(style.alignment)
        
        # 设置段落格式
        paragraph.paragraph_format.space_before = Pt(style.space_before)
        paragraph.paragraph_format.space_after = Pt(style.space_after)
        if style.line_spacing:
            paragraph.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
            paragraph.paragraph_format.line_spacing = style.line_spacing
        # 设置首行缩进（用于实现首行空两格）
        if style.first_line_indent:
            paragraph.paragraph_format.first_line_indent = Pt(style.first_line_indent)
        
        # 处理内联样式：需要先移除标记符号，然后应用样式
        # 重新解析文本，移除标记并记录样式位置
        clean_text, style_ranges = self._process_inline_styles(text, inline_styles)
        
        if not style_ranges:
            # 没有内联样式，直接添加文本
            run = paragraph.add_run(clean_text)
            run.font.name = style.font_name
            run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
            run.font.size = Pt(style.font_size)
        else:
            # 有内联样式，分段添加
            last_pos = 0
            for style_type, start, end in sorted(style_ranges, key=lambda x: x[1]):
                # 添加样式前的普通文本
                if start > last_pos:
                    normal_text = clean_text[last_pos:start]
                    if normal_text:
                        run = paragraph.add_run(normal_text)
                        run.font.name = style.font_name
                        run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
                        run.font.size = Pt(style.font_size)
                
                # 添加带样式的文本
                styled_text = clean_text[start:end]
                if styled_text:
                    run = paragraph.add_run(styled_text)
                    run.font.name = style.font_name
                    run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
                    run.font.size = Pt(style.font_size)
                    if style_type == 'bold':
                        run.bold = True
                    elif style_type == 'italic':
                        run.italic = True
                
                last_pos = end
            
            # 添加剩余的普通文本
            if last_pos < len(clean_text):
                normal_text = clean_text[last_pos:]
                if normal_text:
                    run = paragraph.add_run(normal_text)
                    run.font.name = style.font_name
                    run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
                    run.font.size = Pt(style.font_size)
    
    def _process_inline_styles(self, text: str, inline_styles: List[Tuple[str, int, int]]) -> Tuple[str, List[Tuple[str, int, int]]]:
        """
        处理内联样式，移除标记符号并重新计算样式位置
        
        Returns:
            (清理后的文本, 新的样式范围列表)
        """
        # 使用更简单的方法：直接构建清理后的文本和样式映射
        clean_text_parts = []
        style_ranges = []  # (style_type, start_in_clean, end_in_clean)
        
        i = 0
        clean_pos = 0
        
        while i < len(text):
            # 检查加粗标记 **text**
            if i < len(text) - 3 and text[i:i+2] == '**':
                # 找到结束的 **
                end_pos = text.find('**', i + 2)
                if end_pos != -1:
                    content = text[i+2:end_pos]
                    # 记录样式
                    style_ranges.append(('bold', clean_pos, clean_pos + len(content)))
                    # 添加到清理文本（不包括标记）
                    clean_text_parts.append(content)
                    clean_pos += len(content)
                    i = end_pos + 2
                    continue
            
            # 检查斜体标记 *text*（但不在**内部）
            if text[i] == '*' and (i == 0 or text[i-1] != '*') and (i == len(text) - 1 or text[i+1] != '*'):
                # 找到结束的 *
                end_pos = i + 1
                while end_pos < len(text) and text[end_pos] != '*':
                    end_pos += 1
                if end_pos < len(text) and (end_pos == len(text) - 1 or text[end_pos+1] != '*'):
                    content = text[i+1:end_pos]
                    # 检查是否在加粗范围内（简化检查）
                    in_bold = False
                    for bold_start, bold_end in [(s[1], s[2]) for s in style_ranges if s[0] == 'bold']:
                        if bold_start <= clean_pos < bold_end:
                            in_bold = True
                            break
                    if not in_bold:
                        style_ranges.append(('italic', clean_pos, clean_pos + len(content)))
                    clean_text_parts.append(content)
                    clean_pos += len(content)
                    i = end_pos + 1
                    continue
            
            # 普通字符
            clean_text_parts.append(text[i])
            clean_pos += 1
            i += 1
        
        clean_text = ''.join(clean_text_parts)
        return clean_text, sorted(style_ranges, key=lambda x: x[1])
    
    def _add_list_item(self, doc: Document, text: str, style: TextStyle, inline_styles: List[Tuple[str, int, int]] = None):
        """添加列表项，支持内联样式"""
        paragraph = doc.add_paragraph()
        paragraph.alignment = self._get_alignment(style.alignment)
        
        # 设置段落格式
        paragraph.paragraph_format.space_before = Pt(style.space_before)
        paragraph.paragraph_format.space_after = Pt(style.space_after)
        if style.first_line_indent:
            paragraph.paragraph_format.first_line_indent = Pt(style.first_line_indent)
        
        # 处理内联样式：需要先移除标记符号，然后应用样式
        if inline_styles:
            clean_text, style_ranges = self._process_inline_styles(text, inline_styles)
            
            if not style_ranges:
                # 没有内联样式，直接添加文本
                run = paragraph.add_run(clean_text)
                run.font.name = style.font_name
                run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
                run.font.size = Pt(style.font_size)
            else:
                # 有内联样式，分段添加
                last_pos = 0
                for style_type, start, end in sorted(style_ranges, key=lambda x: x[1]):
                    # 添加样式前的普通文本
                    if start > last_pos:
                        normal_text = clean_text[last_pos:start]
                        if normal_text:
                            run = paragraph.add_run(normal_text)
                            run.font.name = style.font_name
                            run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
                            run.font.size = Pt(style.font_size)
                    
                    # 添加带样式的文本
                    styled_text = clean_text[start:end]
                    if styled_text:
                        run = paragraph.add_run(styled_text)
                        run.font.name = style.font_name
                        run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
                        run.font.size = Pt(style.font_size)
                        if style_type == 'bold':
                            run.bold = True
                        elif style_type == 'italic':
                            run.italic = True
                    
                    last_pos = end
                
                # 添加剩余的普通文本
                if last_pos < len(clean_text):
                    normal_text = clean_text[last_pos:]
                    if normal_text:
                        run = paragraph.add_run(normal_text)
                        run.font.name = style.font_name
                        run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
                        run.font.size = Pt(style.font_size)
        else:
            # 没有内联样式，直接添加文本
            run = paragraph.add_run(text)
            run.font.name = style.font_name
            run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
            run.font.size = Pt(style.font_size)
    
    def _get_alignment(self, alignment: str):
        """获取对齐方式枚举值"""
        mapping = {
            'left': WD_ALIGN_PARAGRAPH.LEFT,
            'center': WD_ALIGN_PARAGRAPH.CENTER,
            'right': WD_ALIGN_PARAGRAPH.RIGHT,
            'justify': WD_ALIGN_PARAGRAPH.JUSTIFY,
        }
        return mapping.get(alignment, WD_ALIGN_PARAGRAPH.LEFT)
    
    def _add_image(self, doc: Document, element: TextElement):
        """添加图片到文档，包括图片和图注"""
        image_path = element.image_path
        
        if not image_path or not os.path.exists(image_path):
            logger.warning(f"图片文件不存在: {image_path}，跳过插入")
            # 如果图片不存在，添加一个占位文本
            paragraph = doc.add_paragraph()
            run = paragraph.add_run(f"[图片: {element.content}]")
            run.font.name = '宋体'
            run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), '宋体')
            run.font.size = Pt(12)
            run.italic = True
            return
        
        try:
            # 增加图片计数器
            self.image_counter += 1
            figure_number = self.image_counter
            
            # 创建图片段落并居中
            img_paragraph = doc.add_paragraph()
            img_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            # 添加图片
            run = img_paragraph.add_run()
            # 设置图片宽度为 5 英寸（约 12.7 厘米），保持宽高比
            run.add_picture(image_path, width=Inches(5.0))
            
            # 设置图片段落间距
            img_paragraph.paragraph_format.space_before = Pt(6)
            img_paragraph.paragraph_format.space_after = Pt(3)
            
            # 创建图注段落并居中
            caption_paragraph = doc.add_paragraph()
            caption_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            # 构建图注文本：图x 图注内容
            caption_text = f"图{figure_number}"
            if element.caption:
                caption_text += f" {element.caption}"
            else:
                # 如果没有提供图注，使用默认格式
                caption_text += f" {element.content}标量场云图"
            
            # 添加图注
            caption_run = caption_paragraph.add_run(caption_text)
            caption_run.font.name = '宋体'
            caption_run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), '宋体')
            caption_run.font.size = Pt(10.5)  # 图注使用稍小的字号
            caption_run.italic = False
            
            # 设置图注段落间距
            caption_paragraph.paragraph_format.space_before = Pt(0)
            caption_paragraph.paragraph_format.space_after = Pt(6)
            
            logger.info(f"成功插入图片: {image_path}, 图注: {caption_text}")
        except Exception as e:
            logger.error(f"插入图片失败: {image_path}, 错误: {e}", exc_info=True)
            # 添加占位文本
            paragraph = doc.add_paragraph()
            run = paragraph.add_run(f"[图片插入失败: {element.content}]")
            run.font.name = '宋体'
            run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), '宋体')
            run.font.size = Pt(12)
            run.italic = True
    
    def _add_reference_title(self, doc: Document, text: str, style: TextStyle):
        """添加参考文献标题"""
        paragraph = doc.add_paragraph()
        paragraph.alignment = self._get_alignment(style.alignment)
        
        run = paragraph.add_run(text)
        run.font.name = style.font_name
        run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
        run.font.size = Pt(style.font_size)
        run.bold = style.bold
        
        paragraph.paragraph_format.space_before = Pt(style.space_before)
        paragraph.paragraph_format.space_after = Pt(style.space_after)
    
    def _add_reference(self, doc: Document, text: str, style: TextStyle):
        """添加参考文献条目"""
        paragraph = doc.add_paragraph()
        paragraph.alignment = self._get_alignment(style.alignment)
        
        run = paragraph.add_run(text)
        run.font.name = style.font_name
        run.font._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), style.font_name)
        run.font.size = Pt(style.font_size)
        
        paragraph.paragraph_format.space_before = Pt(style.space_before)
        paragraph.paragraph_format.space_after = Pt(style.space_after)
        if style.line_spacing:
            paragraph.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
            paragraph.paragraph_format.line_spacing = style.line_spacing


class ReportConverter:
    """报告转换器，用于将字符串文本转换为Word格式的报告文档"""
    
    def __init__(self, template: CAEReportTemplate = None, image_map: Optional[Dict[str, str]] = None):
        """
        Args:
            template: 报告模板
            image_map: 图片ID到文件路径的映射字典，格式为 {image_id: file_path}
        """
        self.template = template or CAEReportTemplate()
        self.parser = ReportParser(self.template)
        self.exporter = WordExporter(self.template)
        self.image_map = image_map or {}  # 图片ID到文件路径的映射
    
    def convert(self, text: str, output_path: str) -> bool:
        """
        将标记文本转换为Word报告文档
        
        Args:
            text: 包含标记的文本字符串
            output_path: 输出Word文档路径
            
        Returns:
            是否成功
        """
        try:
            logger.info("开始解析报告文本...")
            elements = self.parser.parse(text)
            logger.info(f"解析完成，共 {len(elements)} 个元素")
            
            # 构建图片ID到编号的映射（按出现顺序）
            image_id_to_number = {}
            image_counter = 0
            
            # 为图片元素设置文件路径，并建立ID到编号的映射
            for element in elements:
                if element.element_type == ReportElementType.IMAGE:
                    image_id = element.content
                    if image_id in self.image_map:
                        element.image_path = self.image_map[image_id]
                        image_counter += 1
                        image_id_to_number[image_id] = image_counter
                        logger.info(f"为图片ID '{image_id}' 设置路径: {element.image_path}, 编号: 图{image_counter}")
                    else:
                        logger.warning(f"未找到图片ID '{image_id}' 的路径映射")
            
            # 在文本元素中替换图片引用（如图X、图X显示了等）
            # 将图片ID替换为实际编号
            for element in elements:
                if element.element_type == ReportElementType.PARAGRAPH:
                    # 替换文本中的图片引用
                    # 匹配模式：图{image_id}、如图{image_id}、图{image_id}显示了等
                    for image_id, figure_num in image_id_to_number.items():
                        # 替换各种引用格式
                        patterns = [
                            (f'如图{image_id}所示', f'如图{figure_num}所示'),
                            (f'图{image_id}所示', f'图{figure_num}所示'),
                            (f'图{image_id}显示', f'图{figure_num}显示'),
                            (f'图{image_id}说明了', f'图{figure_num}说明了'),
                            (f'图{image_id}表明', f'图{figure_num}表明'),
                            (f'图{image_id}可见', f'图{figure_num}可见'),
                            (f'图{image_id}展示', f'图{figure_num}展示'),
                            (f'图{image_id}呈现', f'图{figure_num}呈现'),
                            (f'图{image_id}中', f'图{figure_num}中'),
                            (f'如图{image_id}', f'如图{figure_num}'),
                            (f'见图{image_id}', f'见图{figure_num}'),
                            (f'图{image_id}', f'图{figure_num}'),  # 最后匹配最通用的格式
                            (image_id, f'图{figure_num}'),  # 匹配独立的 image_id
                        ]
                        for old_pattern, new_pattern in patterns:
                            element.content = element.content.replace(old_pattern, new_pattern)
            
            logger.info("开始导出Word文档...")
            success = self.exporter.export(elements, output_path)
            
            if success:
                logger.info("报告转换成功！")
            else:
                logger.error("报告转换失败！")
            
            return success
            
        except Exception as e:
            logger.error(f"转换报告时发生错误: {e}", exc_info=True)
            return False


# 便捷函数
def ConvertTextToWordReport(text: str, output_path: str, template: CAEReportTemplate = None, image_map: Optional[Dict[str, str]] = None) -> bool:
    """
    便捷函数：将标记文本转换为Word报告文档

    Args:
        text: 包含标记的文本字符串
        output_path: 输出Word文档路径
        template: 报告模板（可选，默认使用CAEReportTemplate）
        image_map: 图片ID到文件路径的映射字典（可选）

    Returns:
        是否成功

    Example:
        text = '''
        # CAE仿真分析报告

        ## 1. 概述
        本报告对**汽车侧面碰撞**进行了CAE仿真分析。

        ## 2. 仿真模型
        ### 2.1 几何模型
        几何模型采用*有限元方法*进行建模。

        ### 2.2 材料属性
        - 材料1：钢材
        - 材料2：铝合金
        '''
        ConvertTextToWordReport(text, "output/report.docx")
    """
    converter = ReportConverter(template, image_map=image_map)
    return converter.convert(text, output_path)


def ConvertMdToWordReport(
    md_path: str,
    output_path: Optional[str] = None,
    temp_image_dir: Optional[str] = None,
    template: CAEReportTemplate = None,
) -> bool:
    """
    直接将 Markdown 文件转换为 Word 报告文档（支持自动查找图片）。

    会自动从正文中提取所有 [IMAGE:image_id:caption] 和 ![image_id] 格式的图片标记，
    然后在指定目录（默认为项目 TempData 文件夹）中查找 image_id 对应的图片文件，
    构建 image_map 后调用 ReportConverter 进行转换。

    Args:
        md_path: Markdown 文件路径（支持 .md 和 .txt）
        output_path: 输出 Word 文档路径。
                    如果为 None，则在 md_path 同目录下生成同名 .docx 文件。
        temp_image_dir: 图片文件所在目录，默认为项目根目录下的 TempData 文件夹。
                       函数会在此目录下搜索 image_id.png 或 image_id.jpg 文件。
        template: 报告模板（可选，默认使用 CAEReportTemplate）

    Returns:
        是否成功

    Example:
        # 基本用法：直接转换同目录下的 md 文件
        ConvertMdToWordReport("/path/to/report_content.txt")

        # 指定输出路径
        ConvertMdToWordReport("/path/to/report_content.txt", "/path/to/output.docx")

        # 指定图片目录
        ConvertMdToWordReport("/path/to/report_content.txt",
                              temp_image_dir="/path/to/TempData")
    """
    import re

    # ---- 1. 读取 Markdown 文件 ----
    if not os.path.isfile(md_path):
        logger.error(f"Markdown 文件不存在: {md_path}")
        return False

    with open(md_path, "r", encoding="utf-8") as f:
        text = f.read()
    logger.info(f"已读取 Markdown 文件: {md_path}")

    # ---- 2. 确定图片目录 ----
    if temp_image_dir is None:
        temp_image_dir = os.path.join(project_root, "TempData")

    # ---- 3. 提取所有 image_id ----
    image_pattern = r'\[IMAGE:([^:\]]+)(?::[^\]]+)?\]|!\[([^\]]+)\]'
    image_ids = set()
    for match in re.finditer(image_pattern, text):
        image_id = match.group(1) or match.group(2)
        if image_id:
            image_ids.add(image_id)

    if not image_ids:
        logger.info("Markdown 文件中未找到图片标记，跳过图片查找")

    # ---- 4. 在 temp_image_dir 中查找图片，构建 image_map ----
    image_map: Dict[str, str] = {}
    found_count = 0
    for image_id in image_ids:
        for ext in (".png", ".jpg", ".jpeg"):
            candidate = os.path.join(temp_image_dir, image_id + ext)
            if os.path.isfile(candidate):
                image_map[image_id] = candidate
                found_count += 1
                break
        else:
            logger.warning(f"未找到图片: {image_id} (在 {temp_image_dir} 中搜索失败)")

    logger.info(f"图片映射完成: {found_count}/{len(image_ids)} 张图片已匹配")

    # ---- 5. 确定输出路径 ----
    if output_path is None:
        base = os.path.splitext(md_path)[0]
        output_path = base + ".docx"

    # ---- 6. 调用 ReportConverter ----
    converter = ReportConverter(template, image_map=image_map)
    return converter.convert(text, output_path)


# 导出
__all__ = [
    "TextElement",
    "ReportParser",
    "WordExporter",
    "ReportConverter",
    "ConvertTextToWordReport",
    "ConvertMdToWordReport",
]

if __name__ == "__main__":
    # 简单测试
    import sys
    if len(sys.argv) < 2:
        print("用法: python ReportConverter.py <markdown_file> [output_docx]")
        sys.exit(1)
    md_path = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else None
    success = ConvertMdToWordReport(md_path, output_path)
    sys.exit(0 if success else 1)

