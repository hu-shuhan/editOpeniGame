# 功能说明：图像处理模块
# 支持多种图像输入格式的处理，转换为LangChain支持的格式

import os
import base64
import logging
from typing import List, Optional, Dict, Union
import requests
from PIL import Image
from io import BytesIO

# 设置日志
logger = logging.getLogger(__name__)

# 图像输入类型定义
ImageInput = Union[str, bytes]  # 支持：文件路径、Base64字符串、URL


def process_images(images: List[ImageInput]) -> List[Dict[str, str]]:
    """
    处理图像输入列表，将多种格式的图像转换为LangChain支持的格式
    
    支持3种图像输入格式：
    1. 本地文件路径 (如 "/path/to/image.jpg")
    2. Base64编码字符串 (如 "data:image/jpeg;base64,..." 或纯Base64字符串)
    3. 网络URL (如 "https://example.com/image.jpg")
    
    参数:
        images: 图像输入列表，每个元素可以是文件路径、Base64字符串或URL
        
    返回:
        处理后的图像数据列表，每个元素是LangChain支持的图像格式字典
        格式: {"type": "image_url", "image_url": {"url": "data:image/...;base64,..."}}
    """
    processed_images = []
    
    for image in images:
        try:
            image_data = _process_single_image(image)
            if image_data:
                processed_images.append(image_data)
        except Exception as e:
            # 跳过无效图像，不返回错误信息
            logger.warning(f"处理图像时跳过无效输入: {str(e)}")
            continue
    
    return processed_images


def _process_single_image(image_input: ImageInput) -> Optional[Dict[str, str]]:
    """
    处理单个图像输入
    
    参数:
        image_input: 单个图像输入（文件路径、Base64字符串或URL）
        
    返回:
        LangChain支持的图像格式字典，如果处理失败返回None
    """
    if not image_input:
        return None
    
    image_input_str = str(image_input).strip()
    
    # 情况1: 已经是完整的data URL格式 (data:image/...;base64,...)
    if image_input_str.startswith("data:image"):
        return {
            "type": "image_url",
            "image_url": {"url": image_input_str}
        }
    
    # 情况2: 网络URL
    if image_input_str.startswith(("http://", "https://")):
        return _process_url_image(image_input_str)
    
    # 情况3: 本地文件路径
    if os.path.exists(image_input_str):
        return _process_local_image(image_input_str)
    
    # 情况4: 纯Base64字符串（尝试解码验证）
    return _process_base64_image(image_input_str)


def _process_local_image(file_path: str) -> Optional[Dict[str, str]]:
    """
    处理本地图像文件
    
    参数:
        file_path: 本地文件路径
        
    返回:
        LangChain支持的图像格式字典
    """
    try:
        # 使用Pillow打开并验证图像
        with Image.open(file_path) as img:
            # 获取图像格式
            img_format = img.format.lower() if img.format else "png"
            if img_format == "jpg":
                img_format = "jpeg"
            
            # 转换为Base64
            buffer = BytesIO()
            # 如果是RGBA模式且要保存为JPEG，需要转换为RGB
            if img_format == "jpeg" and img.mode == "RGBA":
                img = img.convert("RGB")
            img.save(buffer, format=img_format.upper())
            base64_data = base64.b64encode(buffer.getvalue()).decode("utf-8")
            
            return {
                "type": "image_url",
                "image_url": {"url": f"data:image/{img_format};base64,{base64_data}"}
            }
    except Exception as e:
        logger.warning(f"处理本地图像文件失败 {file_path}: {str(e)}")
        return None


def _process_url_image(url: str) -> Optional[Dict[str, str]]:
    """
    处理网络URL图像
    
    参数:
        url: 图像的网络URL
        
    返回:
        LangChain支持的图像格式字典
    """
    try:
        # 下载图像
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        
        # 使用Pillow验证图像数据
        img = Image.open(BytesIO(response.content))
        img_format = img.format.lower() if img.format else "png"
        if img_format == "jpg":
            img_format = "jpeg"
        
        # 转换为Base64
        base64_data = base64.b64encode(response.content).decode("utf-8")
        
        return {
            "type": "image_url",
            "image_url": {"url": f"data:image/{img_format};base64,{base64_data}"}
        }
    except Exception as e:
        logger.warning(f"处理URL图像失败 {url}: {str(e)}")
        return None


def _process_base64_image(base64_string: str) -> Optional[Dict[str, str]]:
    """
    处理Base64编码的图像字符串
    
    参数:
        base64_string: Base64编码的图像数据
        
    返回:
        LangChain支持的图像格式字典
    """
    try:
        # 尝试解码Base64
        image_data = base64.b64decode(base64_string)
        
        # 使用Pillow验证是否为有效图像
        img = Image.open(BytesIO(image_data))
        img_format = img.format.lower() if img.format else "png"
        if img_format == "jpg":
            img_format = "jpeg"
        
        return {
            "type": "image_url",
            "image_url": {"url": f"data:image/{img_format};base64,{base64_string}"}
        }
    except Exception as e:
        logger.warning(f"处理Base64图像失败: {str(e)}")
        return None

