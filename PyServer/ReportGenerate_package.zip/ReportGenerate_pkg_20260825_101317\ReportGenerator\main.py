import os
from ReportGenerator import GenerateCAEReport
from datetime import datetime
if __name__ == "__main__":
    """主函数：演示报告生成"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # 模型路径
    model_path = os.path.join(base_dir, "ExampleDatas", "driver_just_car_with_simulation.vtm")
    # 输出路径
    time = datetime.now().strftime("%Y%m%d%H%M%S")
    output_path = os.path.join(base_dir, "ExampleOutputs", f"cae_report_example_pressure_{time}.docx")
    
    # 指定要分析的数据场（用于测试，只分析指定的字段）
    # 设置为 None 则分析所有数据场
    specified_fields = ["Pressure"]  # 精确匹配，只分析名为 specified_fields 的字段
    # 生成报告
    print("开始生成CAE报告...")
    success = GenerateCAEReport(
        model_path, 
        output_path, 
        is_multiblock_processed= True,  # 测试智能可视化流程（设为True会触发部件模型流程）
        specified_fields=specified_fields  # 指定要分析的数据场
    )
    if success:
        print(f"报告已成功生成: {output_path}")
    else:
        print("报告生成失败")

    # model_path = "/home/xs/Project/iGameRagCenter/SimulationData/yf17.vtm"
    # time = datetime.now().strftime("%Y%m%d%H%M%S")
    # output_path = f"/home/xs/Project/iGameRagCenter/ReportGenerator/cae_report_example_yf17_{time}.docx"
    # specified_fields = ["Pressure"]
    #
    # success = GenerateCAEReport(
    #     model_path,
    #     output_path,
    #     is_multiblock_processed= False,  # 测试智能可视化流程（设为True会触发部件模型流程）
    #     specified_fields=specified_fields  # 指定要分析的数据场
    # )
    # if success:
    #     print(f"报告已成功生成: {output_path}")
    # else:
    #     print("报告生成失败")