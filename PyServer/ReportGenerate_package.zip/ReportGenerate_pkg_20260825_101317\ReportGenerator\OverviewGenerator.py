"""
第一章：概述生成器
负责生成概述章节内容（包含引言和分析目标两段）
"""

import logging

# 设置日志
logger = logging.getLogger(__name__)


# 章节Prompt模板
CHAPTER_PROMPT = """你是一位CAE仿真工程师，正在撰写仿真分析报告的"概述"章节。

{fengjing_description}**第二章仿真模型内容摘要**：
{chapter_simulation_model_summary}

**第三章仿真结果分析摘要**：
{chapter_simulation_results_summary}

**【必须严格遵守的输出格式】**：

输出的内容必须包含以下全部部分，顺序不得打乱：

# 报告标题（一级标题，用简洁的词语概括仿真主题，如"汽车外形压力场仿真分析报告"，不要加日期或编号）

## 1. 概述

（引言段落，3-5句话，介绍仿真背景、分析目的和应用场景）

（分析概述段落，3-5句话，概括仿真内容、方法和主要发现方向，不涉及具体数据）

---

**写作原则**（严格遵守，否则视为不合格）：
1. **报告身份**：你是这份报告的编写者，报告内容应像工程师已完成分析后撰写的正式文档，读者只能看到最终结论，看不到分析过程
2. **禁止描述过程**：严禁使用"我将"、"本次分析采用"、"通过XX方法"、"基于XX技术"、"结合XX进行"等描述分析过程或思考路径的措辞
3. **直接陈述结论**：使用直接陈述方式呈现结论，例如"该区域压力值较高"、"速度分布呈现明显梯度"等，而非"我将指出该区域压力值较高"
4. **概述定位**：从全局视角概括整个仿真分析工作，包括仿真目的、应用场景、方法、主要发现方向，仅限宏观层面，不涉及具体数据
5. **语言风格**：以"本报告"、"本次仿真"、"分析表明"等直接陈述，不使用"检测到"、"识别到"等工具描述口吻
6. **禁止事项**：
   - 禁止提及具体数值数据（如压力值、温度值、速度值等）
   - 禁止提及模型几何尺寸、包围盒尺寸等参数
   - 禁止提及云图颜色映射对应的具体数值
   - 禁止提及仿真场名称的具体数值范围
7. **标题缺失惩罚**：若输出内容中不包含"# 报告标题"（一级标题格式），视为严重错误

直接输出报告内容，不需要任何前缀说明。"""


def _get_summary(content: str, max_len: int = 1000) -> str:
    """提取内容摘要（增加长度以包含更多实际内容）"""
    if not content:
        return "（无内容）"
    if len(content) > max_len:
        return content[:max_len] + "..."
    return content


def generate_chapter_overview(
    chapter_simulation_model_content: str,
    chapter_simulation_results_content: str,
    chapter_discussion_content: str = "",
    chapter_summary_content: str = "",
    description: str = "",
) -> str:
    """
    生成第一章：概述（简短版，1-2段话）
    
    Args:
        chapter_simulation_model_content: 第二章仿真模型的内容
        chapter_simulation_results_content: 第三章仿真结果分析的内容
        chapter_discussion_content: 第四章结果讨论的内容（可选）
        chapter_summary_content: 第五章总结的内容（可选）
        description: 仿真背景描述信息（可选）
        
    Returns:
        生成的章节内容
    """
    from utils import call_llm, reset_dialogue
    import uuid
    
    # 创建独立的对话会话
    conversation_id = f"overview_{uuid.uuid4().hex[:12]}"
    reset_dialogue("report_generator", conversation_id)
    logger.info(f"为第一章创建独立对话会话: {conversation_id}")
    
    # 处理背景描述信息
    fengjing_description_str = ""
    if description:
        fengjing_description_str = f"""**用户提供的仿真背景描述**：
{description}

---

"""
    
    prompt = CHAPTER_PROMPT.format(
        fengjing_description=fengjing_description_str,
        chapter_simulation_model_summary=_get_summary(chapter_simulation_model_content),
        chapter_simulation_results_summary=_get_summary(chapter_simulation_results_content),
    )
    
    chapter_content = call_llm(prompt)
    
    logger.info("第一章：概述 生成完成")
    return chapter_content


__all__ = [
    "generate_chapter_overview",
]
