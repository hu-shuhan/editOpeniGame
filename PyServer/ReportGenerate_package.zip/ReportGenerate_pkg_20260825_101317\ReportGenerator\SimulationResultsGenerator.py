"""
第三章：仿真结果生成器
负责生成仿真结果章节内容，包括标量场可视化和分析
"""

import logging
import numpy as np
import vtk
from typing import Optional, Dict, List, Tuple

from utils import _encode_image, call_llm, save_image_to_temp

# 设置日志
logger = logging.getLogger(__name__)


# ============================================================================
# Prompt 模板（统一管理）
# ============================================================================

# 单个物理场分析 Prompt
SCALAR_FIELD_ANALYSIS_PROMPT = """你是一位CAE仿真工程师，正在撰写仿真分析报告中物理场分布特征的描述内容。

{fengjing_description}**物理场信息**：
- 物理场名称：{field_name}
- 数据类型：{data_type}
- 数值范围：[{min_value:.6g}, {max_value:.6g}]
- 模型类型：{model_type}
{vector_component_info}
**云图颜色映射说明**：
{colormap_description}
**物理场渲染云图**：
{image_list}

**写作原则**：
1. **报告身份**：你是这份报告的编写者，报告内容应像工程师已完成分析后撰写的正式文档，读者只能看到最终结论，看不到分析过程
2. **禁止描述过程**：严禁使用"我将"、"基于"、"通过"、"结合"、"采用"等描述分析过程或技术方法的措辞
3. **直接陈述分布特征**：使用"该物理场在XX区域呈现XX分布"、"分布特征表明"、"结果表明"等直接陈述方式
4. **内容要求**：基于云图图像，描述该物理场在模型上的分布规律，包括高值区（红色区域）、低值区（蓝色区域）的大致分布位置和形态特征
5. **数据引用**：数值必须标注单位（如 Pa、m/s、K 等），引用数值时使用"数值为XX"、"最大值达XX"等客观陈述
6. **图片引用**：在描述时穿插引用云图，使用"[IMAGE:图片ID:图注描述]"格式，1-3张云图

**输出格式**：
直接输出分析内容段落，在段落中适当位置插入云图。"""

# 章节整合 Prompt
CHAPTER_INTEGRATION_PROMPT = """你是一位CAE仿真工程师，正在撰写仿真分析报告的综合评估部分。

{fengjing_description}**模型信息**：
- 模型类型：{model_type}
- 顶点数量：{num_points}
- 网格单元数量：{num_cells}

**各仿真场的分析结果摘要**：
{field_analyses}

**写作原则**：
1. **报告身份**：你是这份报告的编写者，报告内容应像工程师已完成分析后撰写的正式文档，读者只能看到最终结论，看不到分析过程
2. **禁止描述过程**：严禁使用"我将"、"基于"、"通过"、"综合来看"等描述分析过程或思考路径的措辞
3. **直接陈述结论**：使用"分析表明"、"结果表明"、"综合分析显示"等直接陈述方式
4. **内容范围**：对各仿真场的结果做整体概括，总结主要发现，内容必须基于上述摘要中实际呈现的数据，不得编造
5. **矢量场分析**：如有矢量分量场，分析各分量的协调性和整体矢量场特征
6. **数据核实**：判断数值范围的合理性时，仅基于摘要中提供的范围信息进行判断，不凭空假设

**输出格式**：
直接输出评估内容段落，使用连贯段落形式，不需要任何前缀说明。"""

# 智能生成图注的 Prompt
IMAGE_CAPTION_GENERATION_PROMPT = """你是一位专业的CAE仿真工程师。请根据以下上下文信息，为一张仿真云图生成简洁专业的图注。

标量场信息：
- 标量场名称：{field_name}
- 视角标识：{view_name}
- 数值范围：[{min_value:.6g}, {max_value:.6g}]
{vector_info}
上下文（图片在文本中被引用的位置附近内容）：
{context}

请生成一个简洁的图注（15-30个字符），格式要求：
1. 包含标量场名称
2. 可以根据上下文描述图片展示的内容或特征
3. 可以包含分布特征的简要描述
4. 不要使用标点符号结尾

直接输出图注内容，不要有任何额外说明。

示例输出格式：
- Velocity_0标量场分布云图
- 应力场最大值区域分布
- 温度场热点分布特征
- Pressure标量场局部放大图"""

# 无数据场时的框架 Prompt
NO_DATA_CHAPTER_PROMPT = """你是一位专业的CAE仿真工程师，正在撰写仿真分析报告的"仿真结果"章节。

当前模型信息：
- 模型类型：{model_type}
- 顶点数量：{num_points}
- 网格单元数量：{num_cells}

注意：当前模型中未包含仿真结果数据场，无法进行具体的结果分析。

请生成一个说明性的第三章内容，说明模型当前状态。

要求：
1. 使用Markdown格式输出，一级标题使用 ## ，二级标题使用 ### 
2. 章节标题为"## 3. 仿真结果"
3. 说明模型目前仅包含几何和网格信息，尚未进行仿真计算或未包含结果数据
4. 可以简要说明后续仿真分析的一般流程
5. 不要输出报告大标题（#开头的标题）"""


# ============================================================================
# 部件模型分析相关的 Prompt 模板
# ============================================================================

# 部件模型综合评估 Prompt
MULTIBLOCK_CHAPTER_INTEGRATION_PROMPT = """你是一位CAE仿真工程师，正在撰写仿真分析报告的综合评估部分（部件模型）。

{fengjing_description}**模型信息**：
- 模型类型：{model_type}
- 顶点数量：{num_points}
- 网格单元数量：{num_cells}
- 部件数量：{num_blocks}

**部件列表**：
{blocks_list}

**各关注区域的分析摘要**：
{region_analyses}

**写作原则**：
1. **报告身份**：你是这份报告的编写者，报告内容应像工程师已完成分析后撰写的正式文档，读者只能看到最终结论，看不到分析过程
2. **禁止描述过程**：严禁使用"我将"、"基于"、"通过"等描述分析过程或思考路径的措辞
3. **直接陈述结论**：使用"部件分析表明"、"分布特征显示"、"各部件对比可见"等直接陈述
4. **内容范围**：对各部件和关注区域的结果做整体概括，汇总主要特征
5. **部件描述**：将部件名称转换为可读的中文工程术语，如"后视镜"、"车身"等
6. **数据核实**：分析各部件之间的数值分布关系时，严格基于摘要中提供的数据，不凭空编造对比结论

**输出格式**：
直接输出评估内容段落，使用连贯段落形式，不需要任何前缀说明。"""


# ============================================================================
# 两阶段分析提示词（multiblock专用）
# ============================================================================

# 第一阶段：整体分析 + 决定需要聚焦的部件
MULTIBLOCK_PHASE1_PROMPT = """你是一位CAE仿真工程师，正在基于仿真结果描述物理场的分布特征。

**模型信息**：
- 模型类型：{model_type}
- 部件数量：{num_blocks}

**当前分析的标量场信息**：
- 标量场名称：{field_name}
- 数据类型：{data_type}
- 数值范围：[{min_value:.6g}, {max_value:.6g}]
{vector_component_info}

**部件列表及统计信息**：
{blocks_stats}

**全模型多视角渲染云图**：
{global_image_list}

请完成以下两个任务：

**任务1：整体分布分析**（2-3段）
描述该标量场在整个模型上的分布规律，包括高值区、低值区的大致位置和形态特征。使用"分布特征为"、"呈现"、"存在"等直接陈述词汇，禁止使用"我将"、"基于"、"通过"、"结合"等描述分析过程的措辞。

**任务2：确定需要聚焦分析的部件**
根据上述分布规律，确定哪些部件需要进行详细的聚焦分析。请从以下部件中选择（最多选择3个）：
{blocks_list}

选择标准：
- 存在极值（最大值或最小值）的部件
- 存在显著分布特征或高梯度变化的部件
- 具有重要工程意义需要详细分析的部件
- 如果整体分布较为均匀，可以选择0个部件（不需要聚焦分析）

**部件名称要求**：
所有部件名称必须转换为人类可读的工程描述，如"后视镜"、"车门"、"发动机舱盖"等。

**输出格式要求**：
请严格按照以下JSON格式输出，不要包含其他内容：

```json
{{
    "global_analysis": "整体分布分析的文本内容（2-3段，使用直接陈述方式，不包含图片标记）",
    "selected_image_ids": ["img_xxx", "img_yyy"],
    "focus_blocks": [
        {{"block_idx": 0, "block_name": "部件名称（工程描述）", "reason": "选择该部件进行聚焦分析的理由"}},
        {{"block_idx": 2, "block_name": "部件名称（工程描述）", "reason": "选择该部件进行聚焦分析的理由"}}
    ]
}}
```

注意：
- `global_analysis` 是纯文本，使用直接陈述方式描述分布特征，不包含图片标记
- `selected_image_ids` 是选择要插入的全模型图片ID列表
- `focus_blocks` 是选择要聚焦分析的部件列表，包含索引、工程名称和选择理由
- 如果不需要聚焦任何部件，`focus_blocks` 可以是空数组 `[]`"""

# 第二阶段：基于聚焦图像生成最终分析
MULTIBLOCK_PHASE2_PROMPT = """你是一位CAE仿真工程师，正在撰写仿真分析报告中物理场分布特征的描述内容。

**标量场信息**：
- 标量场名称：{field_name}
- 数据类型：{data_type}
- 数值范围：[{min_value:.6g}, {max_value:.6g}]
{vector_component_info}

**第一阶段整体分析结果**：
{global_analysis}

**可用的全模型图片**：
{global_image_list}

**聚焦部件渲染云图**（高亮显示聚焦部件，其他部件半透明）：
{focus_image_list}

**写作原则**：
1. **报告身份**：你是这份报告的编写者，报告内容应像工程师已完成分析后撰写的正式文档，读者只能看到最终结论，看不到分析过程
2. **禁止描述过程**：严禁使用"我将"、"基于"、"通过"、"结合"、"首先"、"其次"等描述分析过程或思考路径的措辞
3. **直接陈述**：使用"分布特征为"、"呈现"、"存在"、"分析表明"等直接陈述词汇，禁止使用"检测到"、"观察到"、"发现"等描述性观察者口吻
4. **整体分布描述**：描述标量场在全模型上的分布规律，包括高值区和低值区的大致位置
5. **聚焦部件分析**：针对每个聚焦部件，详细描述该部件上物理场的分布特征

**禁止事项**：
- 禁止使用Block索引（如"Block 0"、"Block 5"、"(Block 2)"等）
- 禁止使用技术性部件名称（如"air_curtain"、"tyres_fr"、"fast_back"等原始标签名）
- 禁止提及部件数量（如"本模型包含10个部件"）
- 禁止添加任何建议或优化方案
- 禁止使用"我将"、"基于以上"、"通过分析"等过程描述

**部件名称规范**：
所有部件名称必须转换为人类可读的中文工程描述：
- "mirror" → "后视镜"
- "tyres_fr" → "前轮"
- "wheels_rear" → "后轮"
- "body" → "车身"
- "underbody" → "车底"
- 以此类推，所有部件都需转换为工程术语

**图片引用**：
- 整体分析必须插入至少1张全模型图
- 每个聚焦部件分析必须插入对应的聚焦图
- 使用格式：[IMAGE:图片ID:图注描述]

**正确的输出示例**：
```
{field_name}在模型表面呈现明显的梯度分布特征，高值区域主要集中在车身前部和后视镜附近。

[IMAGE:img_abc123:{field_name}标量场全模型分布云图]

后视镜区域的物理场分布显示该区域速度值明显偏高。

[IMAGE:img_def456:{field_name}在后视镜的聚焦视图]

该区域的分布特征表明在高速行驶时，后视镜附近的气流受到较大干扰。
```"""


# ============================================================================
# 辅助函数：颜色映射信息和矢量分量检测
# ============================================================================

def get_colormap_description(colormap_type: str, min_value: float, max_value: float) -> str:
    """
    根据颜色映射类型生成颜色映射的描述信息
    
    Args:
        colormap_type: 颜色映射类型 ("diverging" 或 "default")
        min_value: 标量场最小值
        max_value: 标量场最大值
        
    Returns:
        颜色映射描述字符串
    """
    mid_value = (min_value + max_value) / 2.0
    
    if colormap_type == "diverging":
        return f"""颜色映射说明（蓝-白-红发散色彩）：
- **蓝色区域**：表示较低值，对应数值范围约 [{min_value:.6g}, {mid_value:.6g}]
- **白色区域**：表示中间值，对应数值约 {mid_value:.6g}
- **红色区域**：表示较高值，对应数值范围约 [{mid_value:.6g}, {max_value:.6g}]
- 颜色越深（蓝或红），表示偏离中间值越远；颜色越接近白色，表示越接近中间值"""
    else:
        # 默认HSV颜色映射
        return f"""颜色映射说明（HSV彩虹色彩）：
- **蓝色/紫色区域**：表示较低值，对应数值接近 {min_value:.6g}
- **青色/绿色区域**：表示中低值
- **黄色/橙色区域**：表示中高值
- **红色区域**：表示较高值，对应数值接近 {max_value:.6g}
- 颜色按照彩虹顺序从低值到高值渐变"""


def get_colormap_report_description(colormap_type: str) -> str:
    """
    获取颜色映射的报告说明文本（用于报告第二章，不包含具体数值）
    
    Args:
        colormap_type: 颜色映射类型 ("diverging" 或 "default")
        
    Returns:
        颜色映射说明文本
    """
    if colormap_type == "diverging":
        return """本报告使用**红白蓝（Diverging）**颜色映射来可视化仿真结果：
- **蓝色**表示**低值区域**（接近最小值）
- **白色**表示**中间值区域**
- **红色**表示**高值区域**（接近最大值）
- 颜色渐变规则：蓝色 → 白色 → 红色，对应数值从小到大
- 颜色越深（蓝或红），表示偏离中间值越远；颜色越接近白色，表示越接近中间值"""
    else:
        # 默认HSV颜色映射
        return """本报告使用**HSV彩虹**颜色映射来可视化仿真结果：
- **蓝色/紫色**表示**低值区域**（接近最小值）
- **青色/绿色**表示**中低值区域**
- **黄色/橙色**表示**中高值区域**
- **红色**表示**高值区域**（接近最大值）
- 颜色按照彩虹顺序从低值到高值渐变"""


def detect_vector_component_info(field_name: str) -> Optional[Dict[str, str]]:
    """
    检测标量场名称是否为矢量的分量，并返回相关信息
    
    Args:
        field_name: 标量场名称
        
    Returns:
        如果是矢量分量，返回包含以下键的字典：
        - 'base_name': 矢量场的基础名称
        - 'component': 分量标识（如 '0', '1', '2' 或 'x', 'y', 'z'）
        - 'direction': 分量方向描述
        - 'description': 完整描述
        否则返回 None
    """
    import re
    
    # 模式1: 以 _0, _1, _2 结尾的数字分量
    numeric_pattern = r'^(.+)_([0-2])$'
    match = re.match(numeric_pattern, field_name)
    if match:
        base_name = match.group(1)
        component = match.group(2)
        direction_map = {'0': 'X方向', '1': 'Y方向', '2': 'Z方向'}
        axis_map = {'0': 'X', '1': 'Y', '2': 'Z'}
        direction = direction_map.get(component, f'第{int(component)+1}方向')
        axis = axis_map.get(component, component)
        return {
            'base_name': base_name,
            'component': component,
            'direction': direction,
            'axis': axis,
            'description': f"这是矢量场 **{base_name}** 的 **{direction}分量**（{axis}轴方向）。该分量反映了{base_name}在{axis}轴方向上的投影值。"
        }
    
    # 模式2: 以 _x, _y, _z 结尾的坐标分量（不区分大小写）
    coord_pattern = r'^(.+)_([xyzXYZ])$'
    match = re.match(coord_pattern, field_name)
    if match:
        base_name = match.group(1)
        component = match.group(2).upper()
        direction = f'{component}方向'
        return {
            'base_name': base_name,
            'component': component.lower(),
            'direction': direction,
            'axis': component,
            'description': f"这是矢量场 **{base_name}** 的 **{direction}分量**（{component}轴方向）。该分量反映了{base_name}在{component}轴方向上的投影值。"
        }
    
    # 模式3: 以 X, Y, Z 结尾（直接大写，无下划线）如 VelocityX
    suffix_pattern = r'^(.+)(X|Y|Z)$'
    match = re.match(suffix_pattern, field_name)
    if match:
        base_name = match.group(1)
        component = match.group(2)
        # 确保base_name不是空的且有意义
        if len(base_name) >= 2:
            direction = f'{component}方向'
            return {
                'base_name': base_name,
                'component': component.lower(),
                'direction': direction,
                'axis': component,
                'description': f"这是矢量场 **{base_name}** 的 **{direction}分量**（{component}轴方向）。该分量反映了{base_name}在{component}轴方向上的投影值。"
            }
    
    # 模式4: 常见的分量命名模式，如 U, V, W（速度分量）
    uvw_patterns = {
        'U': ('速度', 'X', 'X方向（流向）'),
        'V': ('速度', 'Y', 'Y方向（法向）'),
        'W': ('速度', 'Z', 'Z方向（展向）'),
    }
    if field_name in uvw_patterns:
        base, axis, direction = uvw_patterns[field_name]
        return {
            'base_name': base,
            'component': field_name.lower(),
            'direction': direction,
            'axis': axis,
            'description': f"**{field_name}** 通常表示 **{base}** 的 **{direction}分量**。"
        }
    
    return None


# ============================================================================
# 标量场渲染函数
# ============================================================================

def render_scalar_field(
    data: vtk.vtkDataObject,
    scalar_field_name: str,
    use_cell_data: bool = True,
    window_size: Tuple[int, int] = (1600, 1600),
    num_views: int = 4,
    colormap_type: str = "diverging",
    component_index: int = -1
) -> Tuple[Dict[str, Tuple[np.ndarray, str]], str]:
    """
    从多个视角渲染指定标量场的可视化图像
    
    Args:
        data: VTK 数据对象（multiblock 或 DataSet）
        scalar_field_name: 标量场名称
        use_cell_data: 是否使用单元数据（True）或点数据（False）
        window_size: 渲染窗口大小
        num_views: 生成的视角数量（最多8个：isometric, front, back, left, right, top, bottom, isometric_back）
        colormap_type: 颜色映射类型 ("diverging" 或 "default")
        component_index: 分量索引（-1表示幅值，0,1,2表示X,Y,Z分量）
        
    Returns:
        元组 (图片字典, 颜色映射类型)
        - 图片字典格式为 {view_name: (image_array, base64_string)}
        - 失败返回 ({}, colormap_type)
    """
    try:
        from DataVisualization import render_solid_color
        from analysis.adjust_perspective.camera_calculator import (
            compute_multiblock_bounds,
            compute_eight_views
        )
        
        if data is None:
            logger.error("渲染标量场失败：数据对象为空")
            return {}, colormap_type
        
        # 计算 bounds 和多个相机视图
        if isinstance(data, vtk.vtkMultiBlockDataSet):
            bounds = compute_multiblock_bounds(data)
        else:
            bounds = data.GetBounds()
        
        # 获取多个视角的相机参数
        all_views = compute_eight_views(bounds)
        # 选择前 num_views 个视角（优先选择 isometric, front, left, top）
        preferred_views = ['isometric', 'front', 'left', 'top', 'right', 'back', 'bottom', 'isometric_back']
        selected_views = {}
        for view_name in preferred_views[:num_views]:
            if view_name in all_views:
                selected_views[view_name] = all_views[view_name]
        
        if not selected_views:
            logger.warning("无法生成任何视角，使用默认等轴测视图")
            from analysis.adjust_perspective.camera_calculator import compute_isometric_view_from_bounds
            selected_views = {'isometric': compute_isometric_view_from_bounds(bounds)}
        
        # 渲染每个视角
        images = {}
        for view_name, camera_params in selected_views.items():
            try:
                image_array = render_solid_color(
                    data,
                    color=(0.7, 0.7, 0.7),  # 默认颜色（被标量场覆盖）
                    scalar_field_name=scalar_field_name,
                    use_cell_data=use_cell_data,
                    camera_params=camera_params,
                    window_size=window_size,
                    background_color=(1.0, 1.0, 1.0),
                    colormap_type=colormap_type,
                    component_index=component_index
                )
                
                # 转换为 base64
                base64_image = _encode_image(image_array)
                images[view_name] = (image_array, base64_image)
                logger.info(f"成功渲染标量场 '{scalar_field_name}' 的 {view_name} 视角")
            except Exception as e:
                logger.warning(f"渲染视角 {view_name} 时出错: {e}")
                continue
        
        return images, colormap_type
        
    except Exception as e:
        logger.error(f"渲染标量场 '{scalar_field_name}' 时发生错误: {e}", exc_info=True)
        return {}, colormap_type


def render_multiblock_scalar_field_global(
    multiblock: vtk.vtkMultiBlockDataSet,
    scalar_field_name: str,
    use_cell_data: bool = True,
    window_size: Tuple[int, int] = (1600, 1600),
    num_views: int = 4,
    colormap_type: str = "diverging",
    component_index: int = -1
) -> Dict[str, Tuple[np.ndarray, str]]:
    """
    渲染部件模型的全模型标量场云图（纯标量渲染，不带透明度）
    
    Args:
        multiblock: VTK MultiBlock数据集
        scalar_field_name: 标量场名称
        use_cell_data: 是否使用单元数据
        window_size: 渲染窗口大小
        num_views: 生成的视角数量
        colormap_type: 颜色映射类型
        component_index: 分量索引（-1表示幅值，0,1,2表示X,Y,Z分量）
        
    Returns:
        图片字典 {view_name: (image_array, base64_string)}
    """
    try:
        from DataVisualization import render_solid_color
        from analysis.adjust_perspective.camera_calculator import (
            compute_multiblock_bounds,
            compute_eight_views
        )
        
        if multiblock is None:
            logger.error("渲染全模型标量场失败：数据对象为空")
            return {}
        
        # 计算整体bounds和多个相机视图
        bounds = compute_multiblock_bounds(multiblock)
        all_views = compute_eight_views(bounds)
        
        # 选择前num_views个视角
        preferred_views = ['isometric', 'front', 'left', 'top', 'right', 'back', 'bottom', 'isometric_back']
        selected_views = {}
        for view_name in preferred_views[:num_views]:
            if view_name in all_views:
                selected_views[view_name] = all_views[view_name]
        
        if not selected_views:
            logger.warning("无法生成任何视角，使用默认等轴测视图")
            from analysis.adjust_perspective.camera_calculator import compute_isometric_view_from_bounds
            selected_views = {'isometric': compute_isometric_view_from_bounds(bounds)}
        
        # 渲染每个视角（使用render_solid_color，纯标量渲染）
        images = {}
        for view_name, camera_params in selected_views.items():
            try:
                image_array = render_solid_color(
                    multiblock,
                    color=(0.7, 0.7, 0.7),  # 默认颜色（被标量场覆盖）
                    scalar_field_name=scalar_field_name,
                    use_cell_data=use_cell_data,
                    camera_params=camera_params,
                    window_size=window_size,
                    background_color=(1.0, 1.0, 1.0),
                    colormap_type=colormap_type,
                    component_index=component_index
                )
                
                base64_image = _encode_image(image_array)
                images[view_name] = (image_array, base64_image)
                logger.info(f"成功渲染全模型标量场 '{scalar_field_name}' 的 {view_name} 视角")
            except Exception as e:
                logger.warning(f"渲染全模型视角 {view_name} 时出错: {e}")
                continue
        
        return images
        
    except Exception as e:
        logger.error(f"渲染全模型标量场 '{scalar_field_name}' 时发生错误: {e}", exc_info=True)
        return {}


def render_focused_block_scalar_field(
    multiblock: vtk.vtkMultiBlockDataSet,
    focus_block_idx: int,
    scalar_field_name: str,
    use_cell_data: bool = True,
    window_size: Tuple[int, int] = (1600, 1600),
    num_views: int = 2,
    colormap_type: str = "diverging",
    component_index: int = -1
) -> Dict[str, Tuple[np.ndarray, str]]:
    """
    渲染聚焦部件的标量场云图（计算最佳视角，展示聚焦部件）
    
    使用camera_calculator计算最佳视角，聚焦部件高亮，其他部件半透明
    
    Args:
        multiblock: VTK MultiBlock数据集
        focus_block_idx: 聚焦的部件索引
        scalar_field_name: 标量场名称
        use_cell_data: 是否使用单元数据
        window_size: 渲染窗口大小
        num_views: 生成的视角数量
        colormap_type: 颜色映射类型
        component_index: 分量索引（-1表示幅值，0,1,2表示X,Y,Z分量）
        
    Returns:
        图片字典 {view_name: (image_array, base64_string)}
    """
    try:
        from DataVisualization import render_focus_block
        from analysis.adjust_perspective.camera_calculator import (
            compute_block_rendering_views,
            get_block_bounds,
            compute_block_center
        )
        
        if multiblock is None:
            logger.error("渲染聚焦部件失败：数据对象为空")
            return {}
        
        num_blocks = multiblock.GetNumberOfBlocks()
        if focus_block_idx < 0 or focus_block_idx >= num_blocks:
            logger.error(f"聚焦部件索引 {focus_block_idx} 超出范围 [0, {num_blocks-1}]")
            return {}
        
        block = multiblock.GetBlock(focus_block_idx)
        if block is None:
            logger.error(f"部件 {focus_block_idx} 为空")
            return {}
        
        # 使用camera_calculator计算最佳视角
        camera_views = compute_block_rendering_views(
            block=block,
            block_index=focus_block_idx,
            multiblock_data=multiblock,
            auto_analyze_geometry=True,
            max_detail_views=num_views
        )
        
        if not camera_views:
            logger.warning(f"无法计算部件 {focus_block_idx} 的视角")
            return {}
        
        # 渲染每个视角（只使用 detail_* 视角，过滤掉 context_* 上下文视角）
        # 上下文视角用于展示部件在整体模型中的位置，不是真正的聚焦视角
        images = {}
        detail_views = {k: v for k, v in camera_views.items() if k.startswith('detail_')}
        
        if not detail_views:
            logger.warning(f"部件 {focus_block_idx} 没有可用的详细视角，使用所有视角")
            detail_views = camera_views
        
        for view_name, camera_params in detail_views.items():
            try:
                image_array = render_focus_block(
                    multiblock,
                    focus_block_idx=focus_block_idx,
                    focus_rgba=(1.0, 1.0, 1.0, 1.0),  # 聚焦块：不透明，使用标量场颜色
                    other_rgba=(0.75, 0.75, 0.75, 0.2),  # 其他块：灰色半透明
                    scalar_field_name=scalar_field_name,
                    use_cell_data=use_cell_data,
                    camera_params=camera_params,
                    window_size=window_size,
                    background_color=(1.0, 1.0, 1.0),
                    colormap_type=colormap_type,
                    component_index=component_index
                )
                
                base64_image = _encode_image(image_array)
                images[view_name] = (image_array, base64_image)
                logger.info(f"成功渲染聚焦部件 {focus_block_idx} 的 {view_name} 视角")
            except Exception as e:
                logger.warning(f"渲染聚焦部件视角 {view_name} 时出错: {e}")
                continue
        
        return images
        
    except Exception as e:
        logger.error(f"渲染聚焦部件 {focus_block_idx} 时发生错误: {e}", exc_info=True)
        return {}


def get_scalar_field_range(
    data: vtk.vtkDataObject,
    scalar_field_name: str,
    use_cell_data: bool = True,
    component_index: int = -1
) -> Optional[Tuple[float, float]]:
    """
    获取标量场的数值范围
    
    Args:
        data: VTK 数据对象
        scalar_field_name: 标量场名称
        use_cell_data: 是否使用单元数据
        component_index: 分量索引（-1表示幅值，0,1,2表示X,Y,Z分量）
        
    Returns:
        (min_value, max_value) 元组，失败返回 None
    """
    try:
        def get_range_from_dataset(dataset):
            """从单个数据集获取标量范围"""
            if not isinstance(dataset, vtk.vtkDataSet):
                return None
            
            if use_cell_data:
                data_arrays = dataset.GetCellData()
            else:
                data_arrays = dataset.GetPointData()
            
            if data_arrays.HasArray(scalar_field_name):
                array = data_arrays.GetArray(scalar_field_name)
                if array is not None:
                    return array.GetRange(component_index)
            return None
        
        if isinstance(data, vtk.vtkMultiBlockDataSet):
            # 遍历所有块，合并范围
            global_min, global_max = float('inf'), float('-inf')
            found = False
            
            for i in range(data.GetNumberOfBlocks()):
                block = data.GetBlock(i)
                if block is None:
                    continue
                
                range_result = get_range_from_dataset(block)
                if range_result is not None:
                    found = True
                    global_min = min(global_min, range_result[0])
                    global_max = max(global_max, range_result[1])
            
            return (global_min, global_max) if found else None
        else:
            return get_range_from_dataset(data)
            
    except Exception as e:
        logger.error(f"获取标量场 '{scalar_field_name}' 范围时发生错误: {e}")
        return None


# ============================================================================
# 后处理函数：确保图片标记存在
# ============================================================================

def _generate_smart_caption(
    image_id: str,
    image_path: str,
    context: str,
    field_name: str,
    value_range: Tuple[float, float],
    vector_info: Optional[Dict[str, str]] = None
) -> str:
    """
    使用LLM智能生成图注
    
    Args:
        image_id: 图片ID
        image_path: 图片文件路径
        context: 图片被引用位置的上下文文本
        field_name: 标量场名称
        value_range: 数值范围 (min, max)
        vector_info: 矢量分量信息（如果有）
        
    Returns:
        生成的图注字符串
    """
    try:
        # 从图片路径中提取视角标识信息
        import os
        filename = os.path.basename(image_path)
        # 文件名格式: {field_name}_{data_type}_{view_name}_{image_id}.png
        # 直接使用文件名作为视角标识，不做特定映射，保持通用性
        view_name = filename.replace('.png', '')  # 去掉扩展名作为标识
        
        # 构建矢量信息字符串
        vector_info_str = ""
        if vector_info:
            vector_info_str = f"- 矢量分量信息：{vector_info.get('description', '')}"
        
        # 构建Prompt
        prompt = IMAGE_CAPTION_GENERATION_PROMPT.format(
            field_name=field_name,
            view_name=view_name,
            min_value=value_range[0],
            max_value=value_range[1],
            vector_info=vector_info_str,
            context=context[:500] if len(context) > 500 else context  # 限制上下文长度
        )
        
        # 调用LLM生成图注
        caption = call_llm(prompt)
        
        if caption and len(caption.strip()) > 0:
            # 清理生成的图注（去除多余的换行、空格等）
            caption = caption.strip().replace('\n', ' ').replace('  ', ' ')
            # 确保不超过合理长度
            if len(caption) > 50:
                caption = caption[:47] + "..."
            logger.info(f"为图片 {image_id} 智能生成图注: {caption}")
            return caption
        
    except Exception as e:
        logger.warning(f"智能生成图注失败: {e}")
    
    # 默认图注
    return f"{field_name}标量场分布云图"


def _ensure_image_markers(
    text: str,
    image_map: Dict[str, str],
    field_name: str = "",
    value_range: Tuple[float, float] = (0.0, 1.0),
    vector_info: Optional[Dict[str, str]] = None,
    use_smart_caption: bool = True
) -> str:
    """
    后处理函数：检查文本中的图片引用，如果缺少对应的[IMAGE:...]标记，自动补充
    
    Args:
        text: 原始文本内容
        image_map: 图片ID到文件路径的映射字典
        field_name: 标量场名称（用于生成图注）
        value_range: 数值范围（用于生成图注）
        vector_info: 矢量分量信息（用于生成图注）
        use_smart_caption: 是否使用LLM智能生成图注
        
    Returns:
        处理后的文本（确保所有被引用的图片都有对应的标记）
    """
    import re
    
    if not text or not image_map:
        return text
    
    # 1. 提取所有已存在的图片标记中的image_id
    existing_markers = set()
    marker_pattern = r'\[IMAGE:([^:\]]+)(?::[^\]]+)?\]'
    for match in re.finditer(marker_pattern, text):
        image_id = match.group(1)
        existing_markers.add(image_id)
    
    # 2. 提取文本中所有图片引用（如图img_xxx、图img_xxx显示了等）
    referenced_images = set()
    # 匹配模式：图img_xxx、如图img_xxx、图img_xxx显示、图img_xxx说明了等
    reference_patterns = [
        r'图(img_[a-f0-9]+)',  # 图img_xxx
        r'如图(img_[a-f0-9]+)',  # 如图img_xxx
        r'图(img_[a-f0-9]+)显示',  # 图img_xxx显示
        r'图(img_[a-f0-9]+)说明',  # 图img_xxx说明
        r'图(img_[a-f0-9]+)表明',  # 图img_xxx表明
        r'图(img_[a-f0-9]+)可见',  # 图img_xxx可见
    ]
    
    for pattern in reference_patterns:
        for match in re.finditer(pattern, text):
            image_id = match.group(1)
            if image_id in image_map:  # 确保这个ID在image_map中存在
                referenced_images.add(image_id)
    
    # 3. 找出被引用但没有标记的图片
    missing_markers = referenced_images - existing_markers
    
    if not missing_markers:
        # 所有被引用的图片都有标记，无需处理
        return text
    
    # 4. 为缺失的图片添加标记
    logger.info(f"检测到 {len(missing_markers)} 个图片引用缺少标记，正在自动补充...")
    
    # 找到第一个引用这些图片的位置，在附近插入标记
    result_text = text
    for image_id in missing_markers:
        # 找到第一个引用该图片的位置（使用具体的image_id构建模式）
        first_ref_match = None
        # 为每个image_id构建具体的匹配模式
        specific_patterns = [
            rf'图{re.escape(image_id)}',  # 图img_xxx
            rf'如图{re.escape(image_id)}',  # 如图img_xxx
            rf'图{re.escape(image_id)}显示',  # 图img_xxx显示
            rf'图{re.escape(image_id)}说明',  # 图img_xxx说明
            rf'图{re.escape(image_id)}表明',  # 图img_xxx表明
            rf'图{re.escape(image_id)}可见',  # 图img_xxx可见
        ]
        
        for pattern in specific_patterns:
            match = re.search(pattern, result_text)
            if match:
                first_ref_match = match
                break
        
        if first_ref_match:
            # 在该引用之前插入图片标记
            insert_pos = first_ref_match.start()
            
            # 提取上下文（引用位置前后各200个字符）
            context_start = max(0, insert_pos - 200)
            context_end = min(len(result_text), insert_pos + 200)
            context = result_text[context_start:context_end]
            
            # 生成图注
            if use_smart_caption and image_id in image_map:
                caption = _generate_smart_caption(
                    image_id=image_id,
                    image_path=image_map[image_id],
                    context=context,
                    field_name=field_name,
                    value_range=value_range,
                    vector_info=vector_info
                )
            else:
                # 默认图注
                caption = f"{field_name}标量场云图" if field_name else "标量场云图"
            
            # 构建图片标记
            image_marker = f"\n\n[IMAGE:{image_id}:{caption}]\n\n"
            
            # 插入标记
            result_text = result_text[:insert_pos] + image_marker + result_text[insert_pos:]
            logger.info(f"已为图片ID '{image_id}' 补充图片标记: {caption}")
    
    return result_text


# ============================================================================
# 单个物理场分析函数
# ============================================================================

def get_field_num_components(
    data: vtk.vtkDataObject,
    field_name: str,
    use_cell_data: bool
) -> int:
    """
    获取场的分量数量
    """
    try:
        def get_comps(dataset):
             if not isinstance(dataset, vtk.vtkDataSet): return 0
             attr = dataset.GetCellData() if use_cell_data else dataset.GetPointData()
             if attr.HasArray(field_name):
                 arr = attr.GetArray(field_name)
                 return arr.GetNumberOfComponents() if arr else 0
             return 0

        if isinstance(data, vtk.vtkMultiBlockDataSet):
            for i in range(data.GetNumberOfBlocks()):
                block = data.GetBlock(i)
                if block:
                    n = get_comps(block)
                    if n > 0: return n
            return 0
        else:
            return get_comps(data)
    except:
        return 0


def analyze_single_scalar_field(
    data: vtk.vtkDataObject,
    field_name: str,
    use_cell_data: bool,
    model_type: str = "3D仿真模型",
    num_views: int = 4,
    colormap_type: str = "diverging",
    component_index: int = -1,
    description: str = "",
) -> Optional[Dict]:
    """
    分析单个物理场（标量或矢量分量）：从多个视角渲染图像，让AI分析并决定哪些图片值得插入报告
    
    Args:
        data: VTK 数据对象
        field_name: 场名称
        use_cell_data: 是否是单元数据
        model_type: 模型类型描述
        num_views: 生成的视角数量（默认4个）
        colormap_type: 颜色映射类型 ("diverging" 或 "default")
        component_index: 分量索引（-1表示幅值，0,1,2表示X,Y,Z分量）
        
    Returns:
        包含分析结果的字典
    """
    try:
        import uuid
        from utils import save_image_to_temp
        
        data_type_str = "单元数据" if use_cell_data else "点数据"
        
        # 确定显示用的场名称
        display_field_name = field_name
        if component_index >= 0:
            axis_map = {0: 'X', 1: 'Y', 2: 'Z'}
            suffix = axis_map.get(component_index, str(component_index))
            display_field_name = f"{field_name}_{suffix}"
            logger.info(f"开始分析物理场分量: {display_field_name} (原场: {field_name}, 分量: {component_index})")
        else:
            logger.info(f"开始分析物理场: {field_name} ({data_type_str})")
        
        # 1. 获取数值范围
        value_range = get_scalar_field_range(data, field_name, use_cell_data, component_index)
        if value_range is None:
            logger.warning(f"无法获取场 '{field_name}' (分量 {component_index}) 的数值范围")
            value_range = (0.0, 1.0)  # 默认范围
        
        # 2. 检测/构建矢量分量信息
        vector_info = None
        if component_index >= 0:
            # 明确指定了分量
            axis_map = {0: ('X', 'X方向'), 1: ('Y', 'Y方向'), 2: ('Z', 'Z方向')}
            axis_code, axis_dir = axis_map.get(component_index, (str(component_index), f"第{component_index}分量"))
            
            vector_info = {
                'base_name': field_name,
                'component': str(component_index),
                'direction': axis_dir,
                'axis': axis_code,
                'description': f"这是矢量场 **{field_name}** 的 **{axis_dir}**（{axis_code}轴分量）。该分量反映了{field_name}在{axis_code}轴方向上的投影值。"
            }
        else:
            # 尝试自动检测（针对 Velocity_0 这种命名）
            vector_info = detect_vector_component_info(field_name)
            if vector_info:
                logger.info(f"检测到矢量分量命名: {field_name} 是 {vector_info['base_name']} 的 {vector_info['direction']}分量")
        
        # 3. 从多个视角渲染图像
        images_dict, used_colormap = render_scalar_field(
            data, field_name, use_cell_data, 
            num_views=num_views, colormap_type=colormap_type,
            component_index=component_index
        )
        
        if not images_dict:
            logger.warning(f"无法渲染场 '{display_field_name}' 的任何视角")
            return None
        
        # 4. 为每张图片生成唯一ID并保存
        image_map = {}  # {image_id: image_path}
        image_list_parts = []  # 用于构建Prompt中的图片列表
        image_inputs = []  # 用于传给LLM的base64图片列表
        
        safe_field_name = display_field_name.replace(" ", "_").replace("/", "_")
        data_type_str_file = "cell" if use_cell_data else "point"
        
        for view_name, (image_array, base64_image) in images_dict.items():
            # 生成唯一的图片ID
            image_id = f"img_{uuid.uuid4().hex[:12]}"
            
            # 保存图片
            image_filename = f"{safe_field_name}_{data_type_str_file}_{view_name}_{image_id}.png"
            image_path = save_image_to_temp(image_array, image_filename)
            
            if image_path:
                image_map[image_id] = image_path
                image_list_parts.append(f"- {view_name} 视角: 图片ID = {image_id}")
                image_inputs.append(f"data:image/png;base64,{base64_image}")
                logger.info(f"保存图片: {view_name} 视角, ID: {image_id}")
            else:
                logger.warning(f"无法保存 {view_name} 视角的图片")
        
        if not image_map:
            logger.warning(f"没有成功保存任何图片")
            return None
        
        # 5. 创建独立对话实例
        from utils import reset_dialogue
        field_conversation_id = f"field_{safe_field_name}_{uuid.uuid4().hex[:12]}"
        reset_dialogue("report_generator", field_conversation_id)
        
        # 6. 构建分析提示词
        image_list_text = "\n".join(image_list_parts)
        
        colormap_description = get_colormap_description(
            used_colormap, value_range[0], value_range[1]
        )
        
        vector_component_info_str = ""
        if vector_info:
            vector_component_info_str = f"""
**矢量分量信息**：
{vector_info['description']}
- 基础矢量场：{vector_info['base_name']}
- 分量方向：{vector_info['direction']}
"""
        elif component_index == -1:
             # 检查是否是矢量的Magnitude
             # 如果原始场分量数 > 1 且 component_index == -1，说明是Magnitude
             num_comps = get_field_num_components(data, field_name, use_cell_data)
             if num_comps > 1:
                 vector_component_info_str = f"""
**场信息**：
这是矢量场 **{field_name}** 的 **幅值(Magnitude)** 分布。
"""

        # 处理背景描述信息
        fengjing_description_str = ""
        if description:
            fengjing_description_str = f"""**用户提供的仿真背景描述**：
{description}

---

"""

        prompt = SCALAR_FIELD_ANALYSIS_PROMPT.format(
            fengjing_description=fengjing_description_str,
            field_name=display_field_name,
            data_type=data_type_str,
            min_value=value_range[0],
            max_value=value_range[1],
            model_type=model_type,
            image_list=image_list_text,
            colormap_description=colormap_description,
            vector_component_info=vector_component_info_str
        )
        
        # 7. 调用 LLM
        analysis = call_llm(prompt, images=image_inputs)
        
        if not analysis:
            analysis = f"物理场 {display_field_name} 的分析内容生成失败。"
        
        # 8. 后处理
        analysis = _ensure_image_markers(
            text=analysis,
            image_map=image_map,
            field_name=display_field_name,
            value_range=value_range,
            vector_info=vector_info,
            use_smart_caption=True
        )
        
        return {
            'field_name': display_field_name,
            'original_field_name': field_name, # 保留原始名称
            'component_index': component_index,
            'data_type': 'cell_data' if use_cell_data else 'point_data',
            'value_range': value_range,
            'image_map': image_map,
            'analysis': analysis,
            'vector_info': vector_info
        }
        
    except Exception as e:
        logger.error(f"分析物理场 '{field_name}' (idx={component_index}) 时发生错误: {e}", exc_info=True)
        return None


def analyze_single_field(
    data: vtk.vtkDataObject,
    field_name: str,
    use_cell_data: bool,
    model_type: str = "3D仿真模型",
    num_views: int = 4,
    colormap_type: str = "diverging",
    description: str = "",
) -> Dict:
    """
    分析单个场（自动识别标量或矢量）
    返回结构化分析结果
    """
    # 获取分量数量
    num_components = get_field_num_components(data, field_name, use_cell_data)
    logger.info(f"场 '{field_name}' 包含 {num_components} 个分量")
    
    if num_components == 3:
        # 矢量：分析幅值和XYZ分量
        logger.info(f"识别为矢量场，将进行分层分析")
        
        sub_analyses = []
        
        # 1. 分析幅值
        res_mag = analyze_single_scalar_field(
            data, field_name, use_cell_data, model_type, num_views, colormap_type, 
            component_index=-1, description=description
        )
        if res_mag:
            # 修正名称以明确是Magnitude
            if not res_mag['field_name'].endswith("Magnitude") and not res_mag['field_name'].endswith("幅值"):
                 res_mag['field_name'] = f"{field_name}_Magnitude"
            res_mag['subtitle'] = "幅值(Magnitude)分析"
            sub_analyses.append(res_mag)
            
        # 2. 分析分量
        for i in range(3):
            res_comp = analyze_single_scalar_field(
                data, field_name, use_cell_data, model_type, num_views, colormap_type,
                component_index=i, description=description
            )
            if res_comp:
                axis_name = ['X', 'Y', 'Z'][i]
                res_comp['subtitle'] = f"{axis_name}分量分析"
                sub_analyses.append(res_comp)
        
        return {
            'type': 'vector',
            'field_name': field_name,
            'sub_analyses': sub_analyses,
            'description': f"矢量场 **{field_name}** 包含3个分量（X, Y, Z）及幅值(Magnitude)。以下将分别对幅值及各分量进行详细分析。"
        }
                
    else:
        # 标量或其他
        res = analyze_single_scalar_field(
            data, field_name, use_cell_data, model_type, num_views, colormap_type,
            component_index=-1, description=description
        )
        if res:
            res['type'] = 'scalar'
            return res
            
    return None


# ============================================================================
# 主接口函数
# ============================================================================

def generate_chapter_simulation_results(
    model_info,
    model_data: vtk.vtkDataObject,
    is_multiblock_processed: bool = False,
    description: str = "",
) -> Tuple[str, Dict[str, str]]:
    """
    生成第三章：仿真结果
    
    对模型中的每个数据场进行可视化分析，生成完整的仿真结果章节。
    
    Args:
        model_info: ModelInfo 对象，包含模型信息
        model_data: VTK 数据对象（multiblock 或 DataSet）
        is_multiblock_processed: 是否是已做部件处理的模型，如果为True，
                                 将使用专门的部件分析流程
        description: 仿真背景描述信息（可选）
        
    Returns:
        (生成的章节内容（Markdown 格式）, 图片ID到文件路径的映射字典)
    """
    logger.info("开始生成第三章：仿真结果")
    
    # 如果description为空，尝试从model_info中获取
    if not description and model_info.description:
        description = model_info.description
    
    # 如果是部件处理过的模型，使用专门的处理函数
    if is_multiblock_processed and isinstance(model_data, vtk.vtkMultiBlockDataSet):
        logger.info("检测到部件处理模型，使用专门的部件分析流程")
        return generate_chapter_simulation_results_multiblock(model_info, model_data, description=description)
    
    # 检查是否有模型信息
    if model_info is None:
        logger.error("模型信息为空")
        return "## 3. 仿真结果\n\n模型信息读取失败，无法生成此章节内容。"
    
    # 获取模型类型
    model_type = model_info.model_type if model_info.model_type else "3D仿真模型"
    
    # 收集所有需要分析的数据场
    fields_to_analyze: List[Tuple[str, bool]] = []  # (field_name, use_cell_data)
    
    # 添加点数据场
    if model_info.point_data_fields:
        for field_name in model_info.point_data_fields:
            fields_to_analyze.append((field_name, False))
            logger.info(f"添加点数据场到分析列表: {field_name}")
    
    # 添加单元数据场
    if model_info.cell_data_fields:
        for field_name in model_info.cell_data_fields:
            fields_to_analyze.append((field_name, True))
            logger.info(f"添加单元数据场到分析列表: {field_name}")
    
    # 收集所有图片映射
    all_image_map: Dict[str, str] = {}
    
    # 如果没有数据场，生成说明性内容
    if not fields_to_analyze:
        logger.info("模型中未发现数据场，生成说明性章节内容")
        prompt = NO_DATA_CHAPTER_PROMPT.format(
            model_type=model_type,
            num_points=model_info.num_points,
            num_cells=model_info.num_cells
        )
        return call_llm(prompt), all_image_map
    
    # 分析每个数据场
    field_analyses: List[Dict] = []
    for field_name, use_cell_data in fields_to_analyze:
        # 返回单个结构化结果（标量或矢量包）
        result = analyze_single_field(
            model_data,
            field_name,
            use_cell_data,
            model_type,
            description=description
        )
        
        if result:
            field_analyses.append(result)
            
            # 合并图片映射（递归处理矢量子分析）
            if result.get('type') == 'vector':
                for sub in result.get('sub_analyses', []):
                    if 'image_map' in sub:
                         all_image_map.update(sub['image_map'])
            elif result.get('type') == 'scalar':
                if 'image_map' in result:
                    all_image_map.update(result['image_map'])
    
    # 如果所有分析都失败了
    if not field_analyses:
        logger.warning("所有标量场分析均失败")
        prompt = NO_DATA_CHAPTER_PROMPT.format(
            model_type=model_type,
            num_points=model_info.num_points,
            num_cells=model_info.num_cells
        )
        return call_llm(prompt), all_image_map
    
    # ========== 构建第三章完整内容 ==========
    
    # 1. 章节标题
    chapter_parts = ["## 3. 仿真结果\n"]
    
    # 2. 各仿真场的分析子章节
    analyses_summary_parts = []  # 用于传给综合评估的摘要
    
    for i, analysis in enumerate(field_analyses, 1):
        if analysis.get('type') == 'vector':
             # 矢量场处理
             field_name = analysis['field_name']
             description = analysis.get('description', '')
             
             # 3.i FieldName 分析
             section_header = f"### 3.{i} {field_name}分析\n\n{description}\n"
             chapter_parts.append(section_header)
             
             # 子分量分析
             sub_analyses = analysis.get('sub_analyses', [])
             for j, sub in enumerate(sub_analyses, 1):
                 sub_title = sub.get('subtitle', sub['field_name'])
                 data_type_str = "单元数据" if sub['data_type'] == 'cell_data' else "点数据"
                 
                 # 3.i.j SubName 分析
                 subsection = f"""#### 3.{i}.{j} {sub_title}
                 
**数据类型**：{data_type_str}
**数值范围**：[{sub['value_range'][0]:.6g}, {sub['value_range'][1]:.6g}]

{sub['analysis']}
"""
                 chapter_parts.append(subsection)
                 
                 # 摘要
                 summary = f"- **{sub['field_name']}**：数值范围 [{sub['value_range'][0]:.6g}, {sub['value_range'][1]:.6g}]"
                 analyses_summary_parts.append(summary)

        else:
             # 标量场处理
             field_name = analysis['field_name']
             data_type_str = "单元数据" if analysis['data_type'] == 'cell_data' else "点数据"
             
             # 添加矢量分量信息（如果有）
             vector_info_text = ""
             if analysis.get('vector_info'):
                 vi = analysis['vector_info']
                 vector_info_text = f"（{vi['base_name']} 的 {vi['direction']}分量）"
             
             # 3.i FieldName 分析
             subsection = f"""### 3.{i} {field_name}分析{vector_info_text}

**数据类型**：{data_type_str}
**数值范围**：[{analysis['value_range'][0]:.6g}, {analysis['value_range'][1]:.6g}]

{analysis['analysis']}
"""
             chapter_parts.append(subsection)
             
             # 构建摘要
             summary = f"""- **{field_name}**{vector_info_text}：数值范围 [{analysis['value_range'][0]:.6g}, {analysis['value_range'][1]:.6g}]"""
             analyses_summary_parts.append(summary)
    

    # # 3. 智能仿真结果分析 (调用 Filter 分析)
    # try:
    #     from SmartSimulationResultsGenerator import run_smart_filter_analysis
    #     logger.info("开始调用智能Filter仿真结果分析...")
    #     smart_content, smart_images = run_smart_filter_analysis(model_data, model_info, field_analyses)
        
    #     if smart_content:
    #         chapter_parts.append(smart_content)
    #         all_image_map.update(smart_images)
    #         logger.info(f"智能Filter分析完成，生成了章节内容和 {len(smart_images)} 张图片")
    # except Exception as e:
    #     logger.warning(f"智能Filter分析过程中发生错误 (跳过该步骤): {e}")

    # 4. 生成综合评估内容
    from utils import reset_dialogue
    import uuid
    chapter_conversation_id = f"chapter_integration_{uuid.uuid4().hex[:12]}"
    reset_dialogue("report_generator", chapter_conversation_id)
    logger.info(f"为章节整合创建独立对话会话: {chapter_conversation_id}")
    
    # 构建摘要文本
    analyses_summary_text = "\n".join(analyses_summary_parts)
    
    # 处理背景描述信息
    fengjing_description_str = ""
    if description:
        fengjing_description_str = f"""**用户提供的仿真背景描述**：
{description}

"""
    
    prompt = CHAPTER_INTEGRATION_PROMPT.format(
        fengjing_description=fengjing_description_str,
        model_type=model_type,
        num_points=model_info.num_points,
        num_cells=model_info.num_cells,
        field_analyses=analyses_summary_text
    )
    
    # 调用 LLM 生成综合评估
    expert_evaluation = call_llm(prompt)
    
    # 4. 添加综合评估子章节
    evaluation_section = f"""### 3.{len(field_analyses) + 1} 综合评估与结论

{expert_evaluation}
"""
    chapter_parts.append(evaluation_section)
    
    # 5. 拼接完整章节内容
    chapter_content = "\n".join(chapter_parts)
    
    logger.info(f"第三章：仿真结果 生成完成，共 {len(all_image_map)} 张图片")
    return chapter_content, all_image_map


# ============================================================================
# 部件模型辅助函数
# ============================================================================

def get_block_names(multiblock: vtk.vtkMultiBlockDataSet) -> Dict[int, str]:
    """
    获取MultiBlock数据集中每个block的名称
    
    Args:
        multiblock: VTK MultiBlock数据集
        
    Returns:
        字典，{block_index: block_name}
    """
    block_names = {}
    num_blocks = multiblock.GetNumberOfBlocks()
    
    for i in range(num_blocks):
        block = multiblock.GetBlock(i)
        if block is None:
            continue
        
        # 尝试从MetaData获取名称
        metadata = multiblock.GetMetaData(i)
        if metadata and metadata.Has(vtk.vtkCompositeDataSet.NAME()):
            name = metadata.Get(vtk.vtkCompositeDataSet.NAME())
        else:
            name = f"Part_{i}"
        
        block_names[i] = name
    
    return block_names


def get_block_scalar_statistics(
    multiblock: vtk.vtkMultiBlockDataSet,
    scalar_field_name: str,
    use_cell_data: bool = True,
    component_index: int = -1
) -> Dict[int, Dict]:
    """
    获取每个block中标量场的统计信息
    
    Args:
        multiblock: VTK MultiBlock数据集
        scalar_field_name: 标量场名称
        use_cell_data: 是否使用单元数据
        component_index: 分量索引
        
    Returns:
        字典，{block_index: {min, max, mean, std, count, has_data}}
    """
    from vtk.util import numpy_support
    
    stats = {}
    num_blocks = multiblock.GetNumberOfBlocks()
    
    for i in range(num_blocks):
        block = multiblock.GetBlock(i)
        if block is None or not isinstance(block, vtk.vtkDataSet):
            stats[i] = {'has_data': False}
            continue
        
        # 获取标量数组
        if use_cell_data:
            data_arrays = block.GetCellData()
        else:
            data_arrays = block.GetPointData()
        
        if not data_arrays.HasArray(scalar_field_name):
            stats[i] = {'has_data': False}
            continue
        
        array = data_arrays.GetArray(scalar_field_name)
        if array is None or array.GetNumberOfTuples() == 0:
            stats[i] = {'has_data': False}
            continue
        
        # 转换为numpy数组并计算统计
        np_array = numpy_support.vtk_to_numpy(array)
        
        # 处理分量
        if component_index >= 0:
            if len(np_array.shape) > 1 and np_array.shape[1] > component_index:
                np_array = np_array[:, component_index]
            elif len(np_array.shape) == 1 and component_index == 0:
                pass
            else:
                stats[i] = {'has_data': False}
                continue
        elif len(np_array.shape) > 1:
            # 计算幅值
            np_array = np.linalg.norm(np_array, axis=1)
        
        stats[i] = {
            'has_data': True,
            'min': float(np.min(np_array)),
            'max': float(np.max(np_array)),
            'mean': float(np.mean(np_array)),
            'std': float(np.std(np_array)),
            'count': int(np_array.size),
            'range': float(np.max(np_array) - np.min(np_array))
        }
    
    return stats


def detect_focus_regions(
    multiblock: vtk.vtkMultiBlockDataSet,
    scalar_field_name: str,
    use_cell_data: bool,
    block_names: Dict[int, str],
    component_index: int = -1
) -> List[Dict]:
    """
    检测需要关注的区域
    """
    # 获取统计信息
    stats = get_block_scalar_statistics(multiblock, scalar_field_name, use_cell_data, component_index)
    
    focus_regions = []
    
    # 筛选有数据的blocks
    valid_blocks = {k: v for k, v in stats.items() if v.get('has_data', False)}
    
    if not valid_blocks:
        return focus_regions
    
    # 计算全局统计
    all_means = [v['mean'] for v in valid_blocks.values()]
    all_maxs = [v['max'] for v in valid_blocks.values()]
    all_mins = [v['min'] for v in valid_blocks.values()]
    all_ranges = [v['range'] for v in valid_blocks.values()]
    
    global_max = max(all_maxs)
    global_min = min(all_mins)
    global_mean = np.mean(all_means)
    global_std = np.std(all_means) if len(all_means) > 1 else 0
    avg_range = np.mean(all_ranges)
    
    # 1. 检测最大值区域
    max_blocks = [k for k, v in valid_blocks.items() 
                  if abs(v['max'] - global_max) < 1e-10 * abs(global_max) or v['max'] == global_max]
    if max_blocks:
        block_names_str = ", ".join([block_names.get(i, f"Part_{i}") for i in max_blocks])
        focus_regions.append({
            'type': 'max_value',
            'block_indices': max_blocks,
            'description': f"标量场{scalar_field_name}的最大值（{global_max:.6g}）出现在部件：{block_names_str}",
            'priority': 5,
            'value': global_max
        })
    
    # 2. 检测最小值区域
    min_blocks = [k for k, v in valid_blocks.items() 
                  if abs(v['min'] - global_min) < 1e-10 * abs(global_min + 1e-10) or v['min'] == global_min]
    if min_blocks:
        block_names_str = ", ".join([block_names.get(i, f"Part_{i}") for i in min_blocks])
        focus_regions.append({
            'type': 'min_value',
            'block_indices': min_blocks,
            'description': f"标量场{scalar_field_name}的最小值（{global_min:.6g}）出现在部件：{block_names_str}",
            'priority': 4,
            'value': global_min
        })
    
    # 3. 检测高梯度区域（变化范围显著高于平均的block）
    if avg_range > 0 and len(all_ranges) > 1:
        range_std = np.std(all_ranges)
        high_gradient_threshold = avg_range + 1.5 * range_std
        high_gradient_blocks = [k for k, v in valid_blocks.items() 
                                 if v['range'] > high_gradient_threshold]
        if high_gradient_blocks:
            block_names_str = ", ".join([block_names.get(i, f"Part_{i}") for i in high_gradient_blocks])
            focus_regions.append({
                'type': 'high_gradient',
                'block_indices': high_gradient_blocks,
                'description': f"标量场{scalar_field_name}在以下部件存在高梯度变化：{block_names_str}",
                'priority': 3,
                'avg_range': avg_range,
                'high_ranges': [valid_blocks[k]['range'] for k in high_gradient_blocks]
            })
    
    # 4. 检测异常区域（均值显著偏离全局均值的block）
    if global_std > 0 and len(all_means) > 2:
        anomaly_threshold = 2.0 * global_std
        anomaly_blocks = [k for k, v in valid_blocks.items() 
                          if abs(v['mean'] - global_mean) > anomaly_threshold]
        if anomaly_blocks:
            block_names_str = ", ".join([block_names.get(i, f"Part_{i}") for i in anomaly_blocks])
            focus_regions.append({
                'type': 'anomaly',
                'block_indices': anomaly_blocks,
                'description': f"标量场{scalar_field_name}在以下部件存在异常值分布：{block_names_str}",
                'priority': 4,
                'global_mean': global_mean,
                'anomaly_means': {k: valid_blocks[k]['mean'] for k in anomaly_blocks}
            })
    
    # 按优先级排序
    focus_regions.sort(key=lambda x: x['priority'], reverse=True)
    
    # 限制返回的区域数量（最多4个）
    return focus_regions[:4]


def analyze_multiblock_scalar_field(
    multiblock: vtk.vtkMultiBlockDataSet,
    field_name: str,
    use_cell_data: bool,
    block_names: Dict[int, str],
    model_type: str = "3D仿真模型",
    num_global_views: int = 4,
    num_focus_views: int = 2,
    colormap_type: str = "diverging",
    component_index: int = -1
) -> Optional[Dict]:
    """
    分析部件模型的单个标量场（两阶段AI驱动流程）
    """
    import uuid
    import json
    import re
    from utils import save_image_to_temp, reset_dialogue
    
    try:
        data_type_str = "单元数据" if use_cell_data else "点数据"
        logger.info(f"开始两阶段分析部件模型标量场: {field_name} ({data_type_str})")
        
        num_blocks = multiblock.GetNumberOfBlocks()

        # 确定显示用的场名称
        display_field_name = field_name
        if component_index >= 0:
            axis_map = {0: 'X', 1: 'Y', 2: 'Z'}
            suffix = axis_map.get(component_index, str(component_index))
            display_field_name = f"{field_name}_{suffix}"
            logger.info(f"开始两阶段分析部件模型物理场分量: {display_field_name}")
        else:
            logger.info(f"开始两阶段分析部件模型物理场: {field_name} (全量/幅值)")
        
        # 1. 获取数值范围
        value_range = get_scalar_field_range(multiblock, field_name, use_cell_data, component_index)
        if value_range is None:
            logger.warning(f"无法获取场 '{field_name}' 的数值范围")
            value_range = (0.0, 1.0)
        
        # 2. 检测矢量分量信息
        vector_component_info_str = ""
        vector_info = None

        if component_index >= 0:
            # 明确指定了分量
            axis_map = {0: ('X', 'X方向'), 1: ('Y', 'Y方向'), 2: ('Z', 'Z方向')}
            axis_code, axis_dir = axis_map.get(component_index, (str(component_index), f"第{component_index}分量"))
            
            vector_info = {
                'base_name': field_name,
                'component': str(component_index),
                'direction': axis_dir,
                'axis': axis_code,
                'description': f"这是矢量场 **{field_name}** 的 **{axis_dir}**（{axis_code}轴分量）。该分量反映了{field_name}在{axis_code}轴方向上的投影值。"
            }
        else:
            # 尝试自动检测
            vector_info = detect_vector_component_info(field_name)

        if vector_info:
             vector_component_info_str = f"""
**矢量分量信息**：
{vector_info['description']}
- 基础矢量场：{vector_info['base_name']}
- 分量方向：{vector_info['direction']}（{vector_info['axis']}轴）
"""
        elif component_index == -1:
             # 如果是 Magnitude
             num_comps = get_field_num_components(multiblock, field_name, use_cell_data)
             if num_comps > 1:
                 vector_component_info_str = f"""
**场信息**：
这是矢量场 **{field_name}** 的 **幅值(Magnitude)** 分布。
"""
        
        # 3. 获取各部件统计信息
        stats = get_block_scalar_statistics(multiblock, field_name, use_cell_data, component_index)
        blocks_stats_parts = []
        blocks_list_parts = []
        for idx, name in sorted(block_names.items()):
            if idx in stats and stats[idx].get('has_data'):
                s = stats[idx]
                blocks_stats_parts.append(
                    f"- **{name}** (Block {idx}): "
                    f"最小值={s['min']:.6g}, 最大值={s['max']:.6g}, "
                    f"均值={s['mean']:.6g}, 标准差={s['std']:.6g}"
                )
                blocks_list_parts.append(f"- Block {idx}: {name}")
            else:
                blocks_stats_parts.append(f"- **{name}** (Block {idx}): 无标量场数据")
        blocks_stats = "\n".join(blocks_stats_parts)
        blocks_list = "\n".join(blocks_list_parts)
        
        # 4. 渲染全模型标量场云图
        global_images = render_multiblock_scalar_field_global(
            multiblock, field_name, use_cell_data,
            num_views=num_global_views, colormap_type=colormap_type,
            component_index=component_index
        )
        
        if not global_images:
            logger.warning(f"无法渲染标量场 '{field_name}' 的全模型视角")
            return None
        
        # 保存全模型图片
        image_map = {}
        global_image_list_parts = []
        global_image_inputs = []
        global_image_id_to_base64 = {}  # 保存ID到base64的映射，供第二阶段使用
        
        safe_field_name = display_field_name.replace(" ", "_").replace("/", "_")
        data_type_str_file = "cell" if use_cell_data else "point"
        
        for view_name, (image_array, base64_image) in global_images.items():
            image_id = f"img_{uuid.uuid4().hex[:12]}"
            image_filename = f"{safe_field_name}_{data_type_str_file}_global_{view_name}_{image_id}.png"
            image_path = save_image_to_temp(image_array, image_filename)
            
            if image_path:
                image_map[image_id] = image_path
                global_image_list_parts.append(f"- 全模型 {view_name} 视角: 图片ID = {image_id}")
                global_image_inputs.append(f"data:image/png;base64,{base64_image}")
                global_image_id_to_base64[image_id] = base64_image
                logger.info(f"保存全模型图片: {view_name} 视角, ID: {image_id}")
        
        global_image_list = "\n".join(global_image_list_parts)
        
        # ============================================================================
        # 第一阶段：让AI分析整体分布并决定需要聚焦的部件
        # ============================================================================
        logger.info(f"开始第一阶段：整体分析并选择聚焦部件")
        
        phase1_conversation_id = f"multiblock_phase1_{field_name}_{uuid.uuid4().hex[:12]}"
        reset_dialogue("report_generator", phase1_conversation_id)
        
        phase1_prompt = MULTIBLOCK_PHASE1_PROMPT.format(
            model_type=model_type,
            num_blocks=num_blocks,
            field_name=display_field_name,
            data_type=data_type_str,
            min_value=value_range[0],
            max_value=value_range[1],
            vector_component_info=vector_component_info_str,
            blocks_stats=blocks_stats,
            global_image_list=global_image_list,
            blocks_list=blocks_list
        )
        
        phase1_response = call_llm(phase1_prompt, images=global_image_inputs)
        
        # 解析第一阶段响应（JSON格式）
        global_analysis = ""
        selected_image_ids = []
        focus_blocks = []
        
        if phase1_response:
            try:
                # 尝试从响应中提取JSON
                json_match = re.search(r'```json\s*(.*?)\s*```', phase1_response, re.DOTALL)
                if json_match:
                    json_str = json_match.group(1)
                else:
                    # 尝试直接解析整个响应
                    json_str = phase1_response
                
                phase1_data = json.loads(json_str)
                global_analysis = phase1_data.get('global_analysis', '')
                selected_image_ids = phase1_data.get('selected_image_ids', [])
                focus_blocks = phase1_data.get('focus_blocks', [])
                
                logger.info(f"第一阶段完成：全局分析长度={len(global_analysis)}, 选择图片={len(selected_image_ids)}张, 聚焦部件={len(focus_blocks)}个")
                
                for fb in focus_blocks:
                    logger.info(f"  - 聚焦部件: Block {fb.get('block_idx')}: {fb.get('block_name')} - {fb.get('reason')}")
                    
            except json.JSONDecodeError as e:
                logger.warning(f"解析第一阶段JSON响应失败: {e}，使用默认策略")
                # 回退到自动检测
                focus_regions = detect_focus_regions(multiblock, field_name, use_cell_data, block_names, component_index)
                if focus_regions:
                    for region in focus_regions[:2]:
                        if region['block_indices']:
                            idx = region['block_indices'][0]
                            focus_blocks.append({
                                'block_idx': idx,
                                'block_name': block_names.get(idx, f"Part_{idx}"),
                                'reason': region['description']
                            })
                global_analysis = phase1_response  # 使用原始响应作为分析内容
        else:
            logger.warning("第一阶段未能获取响应，使用自动检测策略")
            focus_regions = detect_focus_regions(multiblock, field_name, use_cell_data, block_names, component_index)
            if focus_regions:
                for region in focus_regions[:2]:
                    if region['block_indices']:
                        idx = region['block_indices'][0]
                        focus_blocks.append({
                            'block_idx': idx,
                            'block_name': block_names.get(idx, f"Part_{idx}"),
                            'reason': region['description']
                        })
        
        # ============================================================================
        # 第二阶段：根据AI的决定渲染聚焦部件视图
        # ============================================================================
        focus_image_list_parts = []
        focus_image_inputs = []
        
        if focus_blocks:
            logger.info(f"开始第二阶段：渲染 {len(focus_blocks)} 个聚焦部件")
            
            for fb in focus_blocks[:3]:  # 最多3个
                focus_block_idx = fb.get('block_idx')
                focus_block_name = fb.get('block_name', f"Part_{focus_block_idx}")
                
                if focus_block_idx is None or focus_block_idx < 0 or focus_block_idx >= num_blocks:
                    logger.warning(f"无效的部件索引: {focus_block_idx}")
                    continue
                
                # 渲染聚焦视图
                focus_images = render_focused_block_scalar_field(
                    multiblock, focus_block_idx, field_name, use_cell_data,
                    num_views=num_focus_views, colormap_type=colormap_type,
                    component_index=component_index
                )
                
                if focus_images:
                    for view_name, (image_array, base64_image) in focus_images.items():
                        image_id = f"img_{uuid.uuid4().hex[:12]}"
                        image_filename = f"{safe_field_name}_{data_type_str_file}_focus_{focus_block_idx}_{view_name}_{image_id}.png"
                        image_path = save_image_to_temp(image_array, image_filename)
                        
                        if image_path:
                            image_map[image_id] = image_path
                            focus_image_list_parts.append(
                                f"- 聚焦部件 {focus_block_name} (Block {focus_block_idx}) {view_name} 视角: 图片ID = {image_id}"
                            )
                            focus_image_inputs.append(f"data:image/png;base64,{base64_image}")
                            logger.info(f"保存聚焦图片: {focus_block_name} {view_name} 视角, ID: {image_id}")
        else:
            logger.info("AI决定不需要聚焦任何部件")
        
        focus_image_list = "\n".join(focus_image_list_parts) if focus_image_list_parts else "（无聚焦部件）"
        
        # ============================================================================
        # 第二阶段：让AI生成最终分析报告
        # ============================================================================
        logger.info("开始生成最终分析报告")
        
        phase2_conversation_id = f"multiblock_phase2_{field_name}_{uuid.uuid4().hex[:12]}"
        reset_dialogue("report_generator", phase2_conversation_id)
        
        phase2_prompt = MULTIBLOCK_PHASE2_PROMPT.format(
            field_name=display_field_name,
            data_type=data_type_str,
            min_value=value_range[0],
            max_value=value_range[1],
            vector_component_info=vector_component_info_str,
            global_analysis=global_analysis,
            global_image_list=global_image_list,
            focus_image_list=focus_image_list
        )
        
        # 传入所有图片（全模型 + 聚焦）
        all_images = global_image_inputs + focus_image_inputs
        analysis = call_llm(phase2_prompt, images=all_images)
        
        if not analysis:
            logger.warning(f"第二阶段未能生成分析内容，使用第一阶段结果")
            analysis = global_analysis if global_analysis else f"标量场 {field_name} 的分析内容生成失败。"
        
        # 后处理：检查并补充缺失的图片标记
        analysis = _ensure_image_markers(
            text=analysis,
            image_map=image_map,
            field_name=display_field_name,
            value_range=value_range,
            vector_info=vector_info,
            use_smart_caption=True
        )
        
        logger.info(f"完成物理场 '{display_field_name}' 的两阶段分析，生成了 {len(image_map)} 张图片")
        
        return {
            'field_name': display_field_name,
            'original_field_name': field_name,
            'component_index': component_index,
            'data_type': 'cell_data' if use_cell_data else 'point_data',
            'value_range': value_range,
            'image_map': image_map,
            'analysis': analysis,
            'vector_info': vector_info,
            'focus_blocks': focus_blocks  # 返回AI选择的聚焦部件
        }
        
    except Exception as e:
        logger.error(f"分析部件模型标量场 '{field_name}' 时发生错误: {e}", exc_info=True)
        return None


def generate_chapter_simulation_results_multiblock(
    model_info,
    model_data: vtk.vtkMultiBlockDataSet,
    description: str = "",
) -> Tuple[str, Dict[str, str]]:
    """
    生成第三章：仿真结果（部件模型专用版本）
    
    新的生成逻辑：
    1. 每个标量场一个子章节
    2. 先生成全模型的标量场渲染图像（多视角，纯标量渲染）
    3. 整体性分析描述
    4. 如果有需要关注的部件，增加段落描述+聚焦视图图像
    
    Args:
        model_info: ModelInfo 对象，包含模型信息
        model_data: VTK MultiBlock数据集
        description: 仿真背景描述信息（可选）
        
    Returns:
        (生成的章节内容（Markdown 格式）, 图片ID到文件路径的映射字典)
    """
    logger.info("开始生成第三章：仿真结果（部件模型分析）")
    
    # 如果description为空，尝试从model_info中获取
    if not description and model_info.description:
        description = model_info.description
    
    if model_info is None:
        logger.error("模型信息为空")
        return "## 3. 仿真结果\n\n模型信息读取失败，无法生成此章节内容。", {}
    
    model_type = model_info.model_type if model_info.model_type else "3D仿真模型"
    num_blocks = model_data.GetNumberOfBlocks()
    
    # 获取block名称
    block_names = get_block_names(model_data)
    logger.info(f"检测到 {num_blocks} 个部件: {list(block_names.values())}")
    
    # 收集所有需要分析的数据场
    fields_to_analyze: List[Tuple[str, bool]] = []
    
    if model_info.point_data_fields:
        for field_name in model_info.point_data_fields:
            fields_to_analyze.append((field_name, False))
    
    if model_info.cell_data_fields:
        for field_name in model_info.cell_data_fields:
            fields_to_analyze.append((field_name, True))
    
    all_image_map: Dict[str, str] = {}
    
    if not fields_to_analyze:
        logger.info("模型中未发现数据场，生成说明性章节内容")
        prompt = NO_DATA_CHAPTER_PROMPT.format(
            model_type=model_type,
            num_points=model_info.num_points,
            num_cells=model_info.num_cells
        )
        return call_llm(prompt), all_image_map
    
    # 构建章节内容
    chapter_parts = ["## 3. 仿真结果\n"]
    

    
    # 分析每个标量场
    field_analyses = []
    subsection_idx = 1

    chapter_parts.append("""以下对各物理场的仿真结果进行分析。""")
    
    for field_name, use_cell_data in fields_to_analyze:
        data_type_str = "单元数据" if use_cell_data else "点数据"
        num_components = get_field_num_components(model_data, field_name, use_cell_data)
        
        sub_fields = []
        if num_components == 3:
            logger.info(f"发现矢量场 {field_name}, 将拆分为幅值和3个分量进行分析")
            # 幅值
            sub_fields.append((-1, "幅值(Magnitude)"))
            # X, Y, Z
            sub_fields.append((0, "X分量"))
            sub_fields.append((1, "Y分量"))
            sub_fields.append((2, "Z分量"))
        else:
            sub_fields.append((-1, ""))
            
        # 如果是矢量场，生成主标题
        if num_components == 3:
             chapter_parts.append(f"""### 3.{subsection_idx} {field_name}分析
             
矢量场 **{field_name}** 包含3个分量（X, Y, Z）及幅值(Magnitude)。以下将分别对幅值及各分量进行详细分析。

""")
        
        for idx, (comp_idx, sub_name) in enumerate(sub_fields):
            logger.info(f"分析物理场: {field_name} (Comp={comp_idx})")
            
            result = analyze_multiblock_scalar_field(
                multiblock=model_data,
                field_name=field_name,
                use_cell_data=use_cell_data,
                block_names=block_names,
                model_type=model_type,
                num_global_views=4,
                num_focus_views=2,
                component_index=comp_idx
            )
            
            if result is None:
                continue
            
            field_analyses.append(result)
            all_image_map.update(result['image_map'])
            
            vector_info_text = ""
            if result.get('vector_info'):
                vi = result['vector_info']
                vector_info_text = f"（{vi['base_name']} 的 {vi['direction']}分量）"
            
            # 生成子章节标题
            if num_components == 3:
                 # 使用4级标题
                 chapter_parts.append(f"""#### 3.{subsection_idx}.{idx+1} {result['field_name']}分析 ({sub_name})

{result['analysis']}

""")
            else:
                 # 标量场，使用3级标题
                 chapter_parts.append(f"""### 3.{subsection_idx} {field_name}分析{vector_info_text}

{result['analysis']}

""")
        
        subsection_idx += 1
    
    # 如果所有分析都失败了
    if not field_analyses:
        logger.warning("所有标量场分析均失败")
        prompt = NO_DATA_CHAPTER_PROMPT.format(
            model_type=model_type,
            num_points=model_info.num_points,
            num_cells=model_info.num_cells
        )
        return call_llm(prompt), all_image_map

    # # 3. 智能仿真结果分析 (调用 Filter 分析)
    # try:
    #     from SmartSimulationResultsGenerator import run_smart_filter_analysis
    #     logger.info("开始调用智能Filter仿真结果分析...")
    #     smart_content, smart_images = run_smart_filter_analysis(model_data, model_info, field_analyses)
        
    #     if smart_content:
    #         chapter_parts.append(smart_content)
    #         all_image_map.update(smart_images)
    #         logger.info(f"智能Filter分析完成，生成了章节内容和 {len(smart_images)} 张图片")
    # except Exception as e:
    #     logger.warning(f"智能Filter分析过程中发生错误 (跳过该步骤): {e}")

    # 生成综合评估（如果有多个标量场）
    if len(field_analyses) > 1:
        import uuid
        from utils import reset_dialogue
        
        chapter_conversation_id = f"multiblock_integration_{uuid.uuid4().hex[:12]}"
        reset_dialogue("report_generator", chapter_conversation_id)
        
        # 构建摘要
        blocks_list_for_prompt = "\n".join([f"- Block {idx}: {name}" for idx, name in sorted(block_names.items())])
        analyses_summary_parts = []
        for result in field_analyses:
            field_name = result['field_name']
            value_range = result['value_range']
            focus_blocks = result.get('focus_blocks', [])
            
            summary = f"- **{field_name}**：数值范围 [{value_range[0]:.6g}, {value_range[1]:.6g}]"
            if focus_blocks:
                block_names_list = [fb.get('block_name', f"Part_{fb.get('block_idx')}") for fb in focus_blocks[:3]]
                summary += f"，聚焦部件：{', '.join(block_names_list)}"
            analyses_summary_parts.append(summary)
        
        # 处理背景描述信息
        fengjing_description_str = ""
        if description:
            fengjing_description_str = f"""**用户提供的仿真背景描述**：
{description}

"""
        
        prompt = MULTIBLOCK_CHAPTER_INTEGRATION_PROMPT.format(
            fengjing_description=fengjing_description_str,
            model_type=model_type,
            num_points=model_info.num_points,
            num_cells=model_info.num_cells,
            num_blocks=num_blocks,
            blocks_list=blocks_list_for_prompt,
            region_analyses="\n".join(analyses_summary_parts)
        )
        
        expert_evaluation = call_llm(prompt)
        
        chapter_parts.append(f"""### 3.{subsection_idx} 综合评估与结论

{expert_evaluation}
""")
    
    chapter_content = "\n".join(chapter_parts)
    
    logger.info(f"第三章：仿真结果（部件模型）生成完成，共 {len(all_image_map)} 张图片")
    return chapter_content, all_image_map


__all__ = [
    "generate_chapter_simulation_results",
    "generate_chapter_simulation_results_multiblock",
    "render_scalar_field",
    "render_multiblock_scalar_field_global",
    "render_focused_block_scalar_field",
    "analyze_single_scalar_field",
    "analyze_multiblock_scalar_field",
    "get_colormap_description",
    "get_colormap_report_description",
    "detect_vector_component_info",
    "get_block_names",
    "get_block_scalar_statistics",
    "detect_focus_regions",
]
