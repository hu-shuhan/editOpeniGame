"""
报告类型和模板定义模块
定义CAE仿真分析报告的结构模板和格式规范
"""

from enum import Enum
from typing import Dict, List, Optional
from dataclasses import dataclass


class ReportElementType(Enum):
    """报告元素类型"""
    TITLE = "title"              # 报告主题/标题
    HEADING_1 = "heading_1"      # 一级标题
    HEADING_2 = "heading_2"      # 二级标题
    HEADING_3 = "heading_3"      # 三级标题
    PARAGRAPH = "paragraph"      # 正文段落
    BOLD = "bold"                # 加粗文本
    ITALIC = "italic"            # 斜体文本
    LIST_ITEM = "list_item"      # 列表项
    TABLE = "table"              # 表格
    IMAGE = "image"              # 图片
    REFERENCE = "reference"      # 参考文献条目
    REFERENCE_TITLE = "reference_title"  # 参考文献标题


@dataclass
class TextStyle:
    """文本样式配置"""
    font_name: str = "宋体"          # 字体名称
    font_size: int = 12              # 字号（磅）
    bold: bool = False               # 是否加粗
    italic: bool = False             # 是否斜体
    underline: bool = False          # 是否下划线
    color: Optional[str] = None      # 颜色（RGB十六进制，如"000000"表示黑色）
    alignment: str = "left"          # 对齐方式：left, center, right, justify
    space_before: int = 0            # 段前间距（磅）
    space_after: int = 0             # 段后间距（磅）
    line_spacing: float = 1.0        # 行距倍数
    first_line_indent: int = 0       # 首行缩进（磅），用于实现首行空两格


class CAEReportTemplate:
    """CAE仿真分析报告模板配置"""
    
    # 标记符号定义（用于AI生成文本时的标记）
    MARKERS = {
        "title": "# ",                    # 报告主题：以 # 开头
        "heading_1": "## ",               # 一级标题：以 ## 开头
        "heading_2": "### ",              # 二级标题：以 ### 开头
        "heading_3": "#### ",             # 三级标题：以 #### 开头
        "bold": "**",                     # 加粗：**文本**
        "italic": "*",                    # 斜体：*文本*
        "list_item": "- ",                # 列表项：以 - 开头
    }
    
    # 样式配置
    STYLES: Dict[ReportElementType, TextStyle] = {
        ReportElementType.TITLE: TextStyle(
            font_name="黑体",
            font_size=22,
            bold=True,
            alignment="center",
            space_before=0,
            space_after=12,
        ),
        ReportElementType.HEADING_1: TextStyle(
            font_name="黑体",
            font_size=18,
            bold=True,
            alignment="left",
            space_before=12,
            space_after=6,
        ),
        ReportElementType.HEADING_2: TextStyle(
            font_name="黑体",
            font_size=16,
            bold=True,
            alignment="left",
            space_before=10,
            space_after=6,
        ),
        ReportElementType.HEADING_3: TextStyle(
            font_name="黑体",
            font_size=14,
            bold=True,
            alignment="left",
            space_before=8,
            space_after=4,
        ),
        ReportElementType.PARAGRAPH: TextStyle(
            font_name="宋体",
            font_size=12,
            bold=False,
            alignment="left",
            space_before=0,
            space_after=6,
            line_spacing=1.5,
            first_line_indent=24,  # 首行缩进24磅（约2个字符宽度，实现首行空两格）
        ),
        ReportElementType.BOLD: TextStyle(
            font_name="宋体",
            font_size=12,
            bold=True,
        ),
        ReportElementType.ITALIC: TextStyle(
            font_name="宋体",
            font_size=12,
            italic=True,
        ),
        ReportElementType.LIST_ITEM: TextStyle(
            font_name="宋体",
            font_size=12,
            alignment="left",
            space_before=0,
            space_after=3,
            first_line_indent=24,  # 首行缩进24磅（约2个字符宽度，实现首行空两格）
        ),
        ReportElementType.REFERENCE_TITLE: TextStyle(
            font_name="黑体",
            font_size=14,
            bold=True,
            alignment="left",
            space_before=12,
            space_after=6,
        ),
        ReportElementType.REFERENCE: TextStyle(
            font_name="宋体",
            font_size=10,
            alignment="left",
            space_before=0,
            space_after=3,
            line_spacing=1.25,
            first_line_indent=0,  # 参考文献不需要首行缩进
        ),
    }
    
    
    @classmethod
    def get_marker_pattern(cls, element_type: ReportElementType) -> str:
        """获取指定元素类型的标记模式"""
        marker_name = element_type.value
        if marker_name in cls.MARKERS:
            return cls.MARKERS[marker_name]
        return ""
    
    @classmethod
    def get_style(cls, element_type: ReportElementType) -> TextStyle:
        """获取指定元素类型的样式配置"""
        return cls.STYLES.get(element_type, cls.STYLES[ReportElementType.PARAGRAPH])


# 导出常用配置
__all__ = [
    "ReportElementType",
    "TextStyle",
    "CAEReportTemplate",
]

