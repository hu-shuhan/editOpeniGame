# ============================================================================
# VTK 单文件 -> ReportGenerator 输入 的转换
#
# C++ 端 MeshReportGenerator 发来的始终是三角化+简化后的单个 legacy VTK 文件，
# 而 ReportGenerator.generate() 的部件分析流程要求输入是 vtkMultiBlockDataSet
# （通过 .vtm 文件传入）。这里按 cell 属性 "part_id"（对应 iGame 端
# P3SAMSegmenter::mapBackToOriginal 写入的 BlockMapping 属性）做拆分：
#   - 存在 part_id：按 part_id 分块，part_id < 0（未分配单元）直接丢弃
#   - 不存在 part_id：不做任何处理，整个模型作为单一 DataSet 输入
# ============================================================================

import logging
import os
from typing import Tuple

import vtk
from vtk.util import numpy_support

logger = logging.getLogger(__name__)

PART_ID_ARRAY_NAME = "part_id"


def convert_to_report_input(vtk_bytes: bytes, work_dir: str) -> Tuple[str, bool]:
    """
    将收到的 VTK 二进制数据转换为 ReportGenerator 可以直接使用的模型文件。

    Args:
        vtk_bytes: 收到的 legacy VTK 文件二进制内容
        work_dir: 本次请求专用的临时工作目录（调用方负责创建和清理）

    Returns:
        (model_path, is_multiblock_processed)
        model_path 是可直接传给 GenerateCAEReport 的文件路径，
        is_multiblock_processed 表明是否走部件分析流程
    """
    input_path = os.path.join(work_dir, "input.vtk")
    with open(input_path, "wb") as f:
        f.write(vtk_bytes)

    reader = vtk.vtkDataSetReader()
    reader.SetFileName(input_path)
    # 必须读取所有标量场，否则 part_id 若不是 legacy VTK 里的 "active scalar"
    # 会被 reader 默默忽略
    reader.ReadAllScalarsOn()
    reader.ReadAllFieldsOn()
    reader.Update()

    dataset = reader.GetOutput()
    if dataset is None or dataset.GetNumberOfPoints() == 0:
        raise ValueError(f"Failed to read VTK data or dataset is empty: {input_path}")

    cell_data = dataset.GetCellData()
    if not cell_data.HasArray(PART_ID_ARRAY_NAME):
        logger.info("No '%s' cell attribute found, using single-block input", PART_ID_ARRAY_NAME)
        return input_path, False

    part_id_array = cell_data.GetArray(PART_ID_ARRAY_NAME)
    part_ids = numpy_support.vtk_to_numpy(part_id_array)
    unique_ids = sorted(int(pid) for pid in set(part_ids.tolist()) if pid >= 0)

    if not unique_ids:
        logger.warning(
            "'%s' attribute present but no cell has a valid (>=0) part id, "
            "falling back to single-block input",
            PART_ID_ARRAY_NAME,
        )
        return input_path, False

    logger.info("Splitting mesh into %d parts by '%s'", len(unique_ids), PART_ID_ARRAY_NAME)

    multiblock = vtk.vtkMultiBlockDataSet()
    for block_index, part_id in enumerate(unique_ids):
        threshold = vtk.vtkThreshold()
        threshold.SetInputData(dataset)
        threshold.SetInputArrayToProcess(
            0, 0, 0, vtk.vtkDataObject.FIELD_ASSOCIATION_CELLS, PART_ID_ARRAY_NAME
        )
        threshold.SetLowerThreshold(float(part_id))
        threshold.SetUpperThreshold(float(part_id))
        threshold.Update()

        block = vtk.vtkUnstructuredGrid()
        block.DeepCopy(threshold.GetOutput())
        # part_id 只用于分块，对下游报告分析是无效的普通属性，
        # 去掉以免被当作数据场处理、混进报告
        block.GetCellData().RemoveArray(PART_ID_ARRAY_NAME)

        multiblock.SetBlock(block_index, block)
        multiblock.GetMetaData(block_index).Set(
            vtk.vtkCompositeDataSet.NAME(), f"Part_{part_id}"
        )

    mb_path = os.path.join(work_dir, "input.vtm")
    writer = vtk.vtkXMLMultiBlockDataWriter()
    writer.SetFileName(mb_path)
    writer.SetInputData(multiblock)
    if writer.Write() != 1:
        raise ValueError(f"Failed to write MultiBlock VTK file: {mb_path}")

    return mb_path, True
