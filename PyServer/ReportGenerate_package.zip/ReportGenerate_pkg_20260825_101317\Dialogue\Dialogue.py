# 功能说明：实现使用langchain框架，使用LCEL构建一个完整的对话系统用于RAG知识库的查询
# 包含：langchain框架的使用，RAG检索，对话管理

# 相关依赖库
# pip install langchain langchain-openai langchain-chroma sentence-transformers pillow requests

import os
import re
import sys
import logging
from typing import List, Optional, Dict, Iterator
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate, PromptTemplate, MessagesPlaceholder
from langchain_chroma import Chroma
from langchain_openai import OpenAIEmbeddings
from langchain_core.runnables import RunnablePassthrough, ConfigurableFieldSpec, RunnableLambda
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage
from langchain_core.retrievers import BaseRetriever
from langchain_core.documents import Document
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_community.chat_message_histories import SQLChatMessageHistory
from pydantic import Field
from sentence_transformers import CrossEncoder

# 将项目根目录添加到 Python 路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from PredefinedStrs.Config import CAE_COLLECTION, CHAT_API_BASE_URL, CHAT_API_KEY, CHAT_MODEL, EMBEDDING_MODEL, CHROMADB_DIR, MEMORY_DB_PATH
from Dialogue.Prompt import DEFAULT_PROMPT_TEMPLATE, SYSTEM_PROMPT
from Dialogue.ProcessImage import process_images, ImageInput

# 设置日志模版
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 禁用 httpx 的 INFO 级别日志（避免每次 HTTP 请求都打印日志）
logging.getLogger("httpx").setLevel(logging.WARNING)


def get_session_history(user_id: str, conversation_id: str) -> SQLChatMessageHistory:
    """
    获取对话历史
    根据用户ID和会话ID获取SQL数据库中的聊天历史
    
    参数:
        user_id: 用户ID
        conversation_id: 会话ID
        
    返回:
        SQLChatMessageHistory对象，用于存储特定用户和会话的历史记录
    """
    memory_db_path = MEMORY_DB_PATH
    # 使用connection参数替代已弃用的connection_string
    from sqlalchemy import create_engine
    engine = create_engine(f"sqlite:///{memory_db_path}")
    return SQLChatMessageHistory(
        session_id=f"{user_id}--{conversation_id}",
        connection=engine
    )


class Dialogue:
    """
    对话系统类，结合RAG和LLM进行知识问答
    """
    
    def __init__(
        self,
        chromadb_dir: str,
        collection_name: str = CAE_COLLECTION,
        api_base: str = CHAT_API_BASE_URL,
        api_key: str = CHAT_API_KEY,
        chat_model: str = CHAT_MODEL,
        embedding_model: str = EMBEDDING_MODEL,
        prompt_template: Optional[str] = None,
        search_k: int = 5,
        temperature: float = 0,
        max_retries: int = 2,
        user_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
        stream: bool = True,
        enable_rerank: bool = True,
        rerank_model: str = "BAAI/bge-reranker-large",
        rerank_top_k: int = 2,
        rerank_relative_threshold: float = 0.9,
        rerank_absolute_threshold: Optional[float] = 0.8,
        rerank_max_count: int = 5,
    ):
        """
        初始化对话系统（默认启用记忆功能和流式输出）
        
        参数:
            chromadb_dir: ChromaDB向量数据库的持久化路径
            collection_name: 待查询的chromaDB向量数据库的集合名称
            api_base: API服务地址
            api_key: API密钥
            chat_model: 聊天模型名称
            embedding_model: 嵌入模型名称
            prompt_template: prompt模板内容，如果为None则使用默认模板
            search_k: 检索返回的最相似文档数量
            temperature: LLM温度参数
            max_retries: 失败重试最大次数
            user_id: 用户ID，用于对话历史管理
            conversation_id: 会话ID，用于对话历史管理
            stream: 是否使用流式输出，默认为True
            enable_rerank: 是否启用rerank功能，默认为True
            rerank_model: rerank模型名称，默认使用BAAI/bge-reranker-large
            rerank_top_k: rerank后返回的最大文档数量（已弃用，保留用于兼容性）
            rerank_relative_threshold: rerank相对阈值（0.0-1.0），只选择分数>=最高分*该阈值的文档，默认为0.9
                例如：如果最高分是0.9，阈值为0.9，则只选择分数>=0.81的文档；如果最高分是0.8，则只选择分数>=0.72的文档
            rerank_absolute_threshold: rerank绝对阈值（可选），作为兜底，只选择分数>=该绝对阈值的文档
                如果为None则不使用绝对阈值，只使用相对阈值
            rerank_max_count: rerank后返回的最大文档数量上限，防止返回过多文档，默认为5
        """
        if user_id is None:
            user_id = "default_user"
        if conversation_id is None:
            conversation_id = "default_conversation"
        self.user_id = user_id
        self.conversation_id = conversation_id
        self.chromadb_dir = chromadb_dir
        self.collection_name = collection_name
        self.api_base = api_base
        self.api_key = api_key
        self.chat_model = chat_model
        self.embedding_model = embedding_model
        self.search_k = search_k
        self.temperature = temperature
        self.max_retries = max_retries
        self.stream = stream
        self.enable_rerank = enable_rerank
        self.rerank_model = rerank_model
        self.rerank_top_k = rerank_top_k  # 保留用于兼容性
        self.rerank_relative_threshold = rerank_relative_threshold
        self.rerank_absolute_threshold = rerank_absolute_threshold
        self.rerank_max_count = rerank_max_count
        
        # 初始化组件
        self.model = None
        self.embeddings = None
        self.vectorstore = None
        self.prompt = None
        self.chain = None
        self.with_message_history = None
        self.reranker = None
        
        # 初始化系统
        self._initialize()
        
        # 设置prompt模板
        if prompt_template is None:
            prompt_template = DEFAULT_PROMPT_TEMPLATE
        self._setup_prompt(prompt_template)
        
        # 构建chain
        self._build_chain()
    
    def _initialize(self):
        """初始化模型和向量数据库"""
        try:
            logger.info("正在初始化模型...")
            
            # （1）初始化LLM模型
            self.model = ChatOpenAI(
                base_url=self.api_base,
                api_key=self.api_key,
                model=self.chat_model,
                temperature=self.temperature,
                max_retries=self.max_retries,
            )
            
            # （2）初始化embeddings处理模型（仅在需要向量数据库时）
            if self.collection_name is not None:
                logger.info("正在初始化向量数据库...")
                self.embeddings = OpenAIEmbeddings(
                    base_url=self.api_base,
                    api_key=self.api_key,
                    model=self.embedding_model,
                )
                
                # （3）实例化Chroma对象
                self.vectorstore = Chroma(
                    persist_directory=self.chromadb_dir,
                    collection_name=self.collection_name,
                    embedding_function=self.embeddings,
                )
                logger.info("向量数据库初始化完成")
            else:
                logger.info("未指定知识库集合，跳过向量数据库初始化（将不使用RAG功能）")
                self.embeddings = None
                self.vectorstore = None
            
            # （4）初始化rerank模型（如果启用）
            if self.enable_rerank:
                logger.info(f"正在加载Rerank模型: {self.rerank_model}...")
                self.reranker = CrossEncoder(self.rerank_model, max_length=512)
                logger.info("Rerank模型加载完成")
            
            logger.info("初始化完成")
            
        except Exception as e:
            logger.error(f"初始化过程中出错: {str(e)}")
            raise
    
    def _setup_prompt(self, prompt_template: str):
        """
        设置prompt模板（始终启用记忆功能）
        
        参数:
            prompt_template: 提示词模板字符串
        """
        try:
            # 从字符串创建PromptTemplate
            prompt_template_obj = PromptTemplate.from_template(prompt_template)
            
            # 始终启用记忆功能，在prompt中添加历史消息占位符
            # system, history, human
            self.prompt = ChatPromptTemplate.from_messages([
                ("system", SYSTEM_PROMPT),
                MessagesPlaceholder(variable_name="history"),
                ("human", prompt_template_obj.template)
            ])
            logger.info("Prompt模板设置完成")
        except Exception as e:
            logger.error(f"设置prompt模板时出错: {str(e)}")
            raise
    
    def _build_chain(self):
        """构建RAG chain（始终启用记忆功能）"""
        try:
            # chain只处理prompt和model，检索在外部手动进行
            base_chain = self.prompt | self.model
            
            # 使用RunnableWithMessageHistory包装chain，启用记忆功能
            self.with_message_history = RunnableWithMessageHistory(
                base_chain,
                get_session_history,
                input_messages_key="query",
                history_messages_key="history",
                history_factory_config=[
                    ConfigurableFieldSpec(
                        id="user_id",
                        annotation=str,
                        name="User ID",
                        description="Unique identifier for the user.",
                        default="",
                        is_shared=True,
                    ),
                    ConfigurableFieldSpec(
                        id="conversation_id",
                        annotation=str,
                        name="Conversation ID",
                        description="Unique identifier for the conversation.",
                        default="",
                        is_shared=True,
                    ),
                ],
            )
            self.chain = self.with_message_history
            
            logger.info("Chain构建完成")
        except Exception as e:
            logger.error(f"构建chain时出错: {str(e)}")
            raise
    
    def _rerank_documents(self, query: str, documents: List[Document]) -> List[Document]:
        """
        使用rerank模型对检索到的文档重新排序，并根据相对阈值筛选
        
        参数:
            query: 用户查询
            documents: 检索到的文档列表
            
        返回:
            重新排序并筛选后的文档列表（只包含满足阈值条件的文档，可能为空）
        """
        if not self.enable_rerank or not self.reranker or not documents:
            return documents
        
        try:
            logger.info(f"开始Rerank处理，原始文档数: {len(documents)}")
            
            # 使用CrossEncoder计算query和每个文档的相似度分数
            scores = self.reranker.predict([(query, doc.page_content) for doc in documents])
            
            # 将分数和文档组合并排序（按分数降序）
            scored_docs = sorted(
                zip(scores, documents), 
                key=lambda x: x[0], 
                reverse=True
            )
            
            if not scored_docs:
                logger.warning("Rerank后没有文档")
                return []
            
            # 获取最高分
            max_score = scored_docs[0][0]
            
            # 计算相对阈值（基于最高分）
            relative_threshold_value = max_score * self.rerank_relative_threshold
            
            # 确定最终阈值：使用相对阈值和绝对阈值中的较大者（更严格）
            if self.rerank_absolute_threshold is not None:
                final_threshold = max(relative_threshold_value, self.rerank_absolute_threshold)
                threshold_type = f"相对阈值({self.rerank_relative_threshold}×{max_score:.4f}={relative_threshold_value:.4f})和绝对阈值({self.rerank_absolute_threshold:.4f})中的较大者"
            else:
                final_threshold = relative_threshold_value
                threshold_type = f"相对阈值({self.rerank_relative_threshold}×{max_score:.4f}={relative_threshold_value:.4f})"
            
            logger.info(f"最高分: {max_score:.4f}, 最终阈值: {final_threshold:.4f} ({threshold_type})")
            
            # # 记录所有文档的排序结果
            # logger.info("Rerank排序结果:")
            # for i, (score, doc) in enumerate(scored_docs, 1):
            #     preview = doc.page_content[:100] + "..." if len(doc.page_content) > 100 else doc.page_content
            #     threshold_mark = "✓" if score >= final_threshold else "✗"
            #     score_ratio = (score / max_score * 100) if max_score > 0 else 0
            #     logger.info(f"  {i}. 得分: {score:.4f} ({score_ratio:.1f}%) {threshold_mark} | 内容: {preview}")
            
            # 根据阈值筛选文档：只选择分数>=最终阈值的文档
            filtered_docs = [
                doc for score, doc in scored_docs 
                if score >= final_threshold
            ]
            
            # 允许返回空列表（不再强制返回最高分文档）
            if not filtered_docs:
                #logger.info(f"没有文档满足阈值条件（阈值: {final_threshold:.4f}），返回空列表")
                return filtered_docs
            
            # 应用最大数量限制
            if len(filtered_docs) > self.rerank_max_count:
                #logger.info(f"筛选后的文档数 {len(filtered_docs)} 超过最大限制 {self.rerank_max_count}，截取前 {self.rerank_max_count} 个")
                filtered_docs = filtered_docs[:self.rerank_max_count]
            
            # logger.info(f"Rerank完成，筛选出 {len(filtered_docs)} 个文档")
            
            return filtered_docs
            
        except Exception as e:
            logger.error(f"Rerank处理时出错: {str(e)}，返回原始文档")
            return documents
    
    def format_response(self, response: str) -> str:
        """
        格式化响应，对输入的文本进行段落分隔、添加适当的换行符，以及在代码块中增加标记
        
        参数:
            response: 原始响应文本
            
        返回:
            格式化后的文本
        """
        # 使用正则表达式 \n{2,} 将输入的response按照两个或更多的连续换行符进行分割
        paragraphs = re.split(r'\n{2,}', response)
        formatted_paragraphs = []
        
        # 遍历每个段落进行处理
        for para in paragraphs:
            # 检查段落中是否包含代码块标记
            if '```' in para:
                # 将段落按照```分割成多个部分，代码块和普通文本交替出现
                parts = para.split('```')
                for i, part in enumerate(parts):
                    # 检查当前部分的索引是否为奇数，奇数部分代表代码块
                    if i % 2 == 1:  # 这是代码块
                        # 将代码块部分用换行符和```包围，并去除多余的空白字符
                        parts[i] = f"\n```\n{part.strip()}\n```\n"
                # 将分割后的部分重新组合成一个字符串
                para = ''.join(parts)
            else:
                # 否则，将句子中的句点后面的空格替换为换行符，以便句子之间有明确的分隔
                para = para.replace('. ', '.\n')
            # 将格式化后的段落添加到formatted_paragraphs列表
            formatted_paragraphs.append(para.strip())
        
        # 将所有格式化后的段落用两个换行符连接起来
        return '\n\n'.join(formatted_paragraphs)
    
    def chat(self, query: str, images: Optional[List[ImageInput]] = None):
        """
        进行单轮对话，支持图像输入
        
        参数:
            query: 用户问题
            images: 可选的图像列表，支持文件路径、Base64字符串或URL

        返回:
            格式化后的回答（生成器）
        """
        if not self.chain:
            raise RuntimeError("对话系统未初始化，请先调用初始化方法")
        
        try:
            # logger.info(f"用户问题是: {query}")
            
            # 处理图像输入
            processed_images = []
            if images:
                # logger.info(f"检测到 {len(images)} 个图像输入，正在处理...")
                processed_images = process_images(images)
                # logger.info(f"成功处理 {len(processed_images)} 个图像")
            
            # 知识库检索（仅在vectorstore存在时）
            if self.vectorstore is not None:
                # print("\n" + "="*60)
                # print("📚 正在调用知识库进行检索...")
                # print(f"🔍 检索查询: {query}")
                # if processed_images:
                #     print(f"🖼️ 已处理图像数量: {len(processed_images)}")
                # print("="*60)
                
                retriever_result = self.vectorstore.similarity_search(
                    query=query,
                    k=self.search_k,
                )
                
                # print(f"✅ 知识库检索完成，找到 {len(retriever_result)} 条相关文档")
                
                # 应用rerank（如果启用）
                if self.enable_rerank and len(retriever_result) > 0:
                    # print(f"🔄 正在使用Rerank模型重新排序...")
                    retriever_result = self._rerank_documents(query, retriever_result)
                    print(f"✅ Rerank完成，筛选出 {len(retriever_result)} 条最相关文档")
            else:
                # 没有向量数据库，使用空上下文
                retriever_result = []
                # logger.info("未使用知识库，直接使用LLM生成回答")
            
            # if retriever_result:
            #     print("\n📄 检索到的文档片段预览:")
            #     for i, doc in enumerate(retriever_result[:3], 1):  # 只显示前3条
            #         preview = doc.page_content[:100] + "..." if len(doc.page_content) > 100 else doc.page_content
            #         print(f"  {i}. {preview}")
            # print("="*60 + "\n")
            
            # 准备配置
            config = {
                "configurable": {
                    "user_id": self.user_id,
                    "conversation_id": self.conversation_id
                }
            }
            
            # 调试：检查历史消息
            session_history = get_session_history(self.user_id, self.conversation_id)
            history_messages = session_history.messages
            # print(f"\n💭 当前对话历史记录数: {len(history_messages)}")
            # if history_messages:
            #     print("📜 历史消息预览:")
            #     for i, msg in enumerate(history_messages[-4:], 1):  # 显示最后4条
            #         role = "用户" if isinstance(msg, HumanMessage) else "助手"
            #         content_preview = msg.content[:80] + "..." if len(msg.content) > 80 else msg.content
            #         print(f"  {i}. [{role}]: {content_preview}")
            # print()
            
            # 如果有图像，使用图像问答模式
            if processed_images:
                return self._chat_with_images(query, retriever_result, processed_images, config)
            
            # 无图像时使用普通模式
            # 统一的数据格式：{"query": query_string, "context": retriever_result}
            invoke_input = {"query": query, "context": retriever_result}
            
            # 根据stream参数决定使用流式或非流式输出
            if self.stream:
                return self._chat_stream(invoke_input, config)
            else:
                return self._chat_non_stream(invoke_input, config)

            
        except Exception as e:
            logger.error(f"处理对话时出错: {str(e)}")
            raise
    
    def _chat_stream(self, invoke_input, config: dict) -> Iterator[str]:
        """
        流式对话输出
        
        参数:
            invoke_input: chain的输入
            config: chain的配置
            
        返回:
            生成器，逐个返回响应片段
        """
        try:
            # 使用stream方法获取流式响应
            if config:
                stream_result = self.chain.stream(invoke_input, config=config)
            else:
                stream_result = self.chain.stream(invoke_input)
            
            # 逐块输出
            # 对于标准的 ChatOpenAI，stream 方法统一返回 AIMessageChunk 对象（有 content 属性）
            for chunk in stream_result:
                # 标准格式：AIMessageChunk 对象，直接获取 content 属性
                if hasattr(chunk, 'content'):
                    content = chunk.content
                    if content:  # 只处理非空内容
                        yield content
                else:
                    # 如果遇到非标准格式，记录警告（理论上不应该发生）
                    logger.warning(f"收到非标准格式的 chunk: {type(chunk)}, 值: {chunk}")
            
        except Exception as e:
            logger.error(f"流式输出时出错: {str(e)}")
            raise
    
    def _chat_non_stream(self, invoke_input, config: dict) -> Iterator[str]:
        """
        非流式对话输出
        
        参数:
            invoke_input: chain的输入
            config: chain的配置
            
        返回:
            生成器，只包含一个完整的响应字符串
        """
        try:
            # 使用invoke方法获取完整响应
            if config:
                response = self.chain.invoke(invoke_input, config=config)
            else:
                response = self.chain.invoke(invoke_input)
            
            # 处理响应对象
            # 对于标准的 ChatOpenAI，invoke 方法统一返回 AIMessage 对象（有 content 属性）
            if hasattr(response, 'content'):
                content = response.content
                if content:
                    # 非流式模式下，一次性返回完整内容
                    yield content
                else:
                    logger.warning("响应内容为空")
                    yield ""
            else:
                # 如果遇到非标准格式，记录警告（理论上不应该发生）
                logger.warning(f"收到非标准格式的响应: {type(response)}, 值: {response}")
                yield ""
            
        except Exception as e:
            logger.error(f"非流式输出时出错: {str(e)}")
            raise
    
    def _chat_with_images(
        self, 
        query: str, 
        context: List[Document], 
        images: List[Dict[str, str]], 
        config: dict
    ) -> Iterator[str]:
        """
        带图像的对话处理
        参数:
            query: 用户问题
            context: 检索到的文档上下文
            images: 处理后的图像数据列表
            config: chain的配置（此处仅用于保持接口一致）
            
        返回:
            生成器，返回响应内容
        """
        try:
            # 格式化上下文（与普通chat相同的逻辑）
            context_str = "\n".join([doc.page_content for doc in context]) if context else "无相关信息"
            
            # 使用相同的提示词模板格式化文本内容
            text_content = DEFAULT_PROMPT_TEMPLATE.format(
                context=context_str,
                query=query
            )
            
            # 构建多模态消息内容：文本 + 图像列表
            # 这是与普通chat的唯一区别：content是列表而非字符串
            message_content = [{"type": "text", "text": text_content}]
            message_content.extend(images)
            
            # 获取对话历史（只读取，不修改）
            session_history = get_session_history(self.user_id, self.conversation_id)
            history_messages = session_history.messages
            
            # 构建消息列表：system + history + 当前多模态消息
            # 注意：只使用历史消息中的文本内容，确保格式一致，避免重复
            messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            
            # 添加历史消息（只添加文本内容，确保格式正确）
            # 重要：只提取纯文本内容，避免包含上下文信息导致重复
            for msg in history_messages:
                if isinstance(msg, HumanMessage):
                    # 只保存原始用户问题，不包含上下文
                    content = msg.content
                    if isinstance(content, list):
                        # 如果是列表格式，提取文本部分
                        text_parts = [item.get("text", "") for item in content if isinstance(item, dict) and item.get("type") == "text"]
                        content = " ".join(text_parts) if text_parts else str(content)
                    # 确保是字符串格式
                    if not isinstance(content, str):
                        content = str(content)
                    messages.append({"role": "user", "content": content})
                elif isinstance(msg, AIMessage):
                    # 只保存AI的回复内容
                    content = msg.content
                    if isinstance(content, list):
                        # 如果是列表格式，提取文本部分
                        text_parts = [item.get("text", "") for item in content if isinstance(item, dict) and item.get("type") == "text"]
                        content = " ".join(text_parts) if text_parts else str(content)
                    # 确保是字符串格式
                    if not isinstance(content, str):
                        content = str(content)
                    messages.append({"role": "assistant", "content": content})
            
            # 添加当前用户消息（多模态格式）
            messages.append({"role": "user", "content": message_content})
            
            # 调用模型并处理响应
            response_content = ""
            if self.stream:
                for chunk in self.model.stream(messages):
                    if hasattr(chunk, 'content') and chunk.content:
                        response_content += chunk.content
                        yield chunk.content
            else:
                response = self.model.invoke(messages)
                response_content = response.content if hasattr(response, 'content') else ""
                yield response_content
            
            # 保存对话历史（只保存文本query和文本response，不保存图像数据）
            # 注意：这里保存的是原始的query，而不是包含上下文的text_content
            # 这样可以保持历史记录的一致性
            session_history.add_user_message(query)
            session_history.add_ai_message(response_content)
                
        except Exception as e:
            logger.error(f"图像对话处理时出错: {str(e)}")
            raise
    
    def clear_history(self):
        """清空对话历史"""
        try:
            session_history = get_session_history(self.user_id, self.conversation_id)
            session_history.clear()
            logger.info(f"已清空用户 {self.user_id} 会话 {self.conversation_id} 的对话历史")
        except Exception as e:
            logger.error(f"清空对话历史时出错: {str(e)}")
    
    def get_history(self) -> List[Dict[str, str]]:
        """
        获取对话历史
        
        返回:
            对话历史列表，每个元素包含role和content
        """
        try:
            session_history = get_session_history(self.user_id, self.conversation_id)
            messages = session_history.messages
            history = []
            for msg in messages:
                if isinstance(msg, HumanMessage):
                    history.append({"role": "user", "content": msg.content})
                elif isinstance(msg, AIMessage):
                    history.append({"role": "assistant", "content": msg.content})
            return history
        except Exception as e:
            logger.error(f"获取对话历史时出错: {str(e)}")
            return []
    
    def set_user_and_conversation(self, user_id: str, conversation_id: str):
        """
        设置用户ID和会话ID
        
        参数:
            user_id: 用户ID
            conversation_id: 会话ID
        """
        self.user_id = user_id
        self.conversation_id = conversation_id
        logger.info(f"已设置用户ID: {user_id}, 会话ID: {conversation_id}")
    
    def set_collection(self, collection_name: Optional[str]):
        """
        切换知识库（collection）
        
        参数:
            collection_name: 新的知识库名称，如果为None则禁用知识库功能
        """
        if collection_name == self.collection_name:
            if collection_name is None:
                logger.info("知识库未变更，仍为禁用状态")
            else:
                logger.info(f"知识库未变更，仍为: {collection_name}")
            return
        
        if collection_name is None:
            logger.info(f"正在禁用知识库（从 {self.collection_name} 切换到 None）")
            self.collection_name = None
            self.vectorstore = None
            # 如果之前没有embeddings，也不需要初始化
            if self.embeddings is None:
                logger.info("未初始化embeddings模型（知识库已禁用）")
        else:
            logger.info(f"正在切换知识库: {self.collection_name} -> {collection_name}")
            self.collection_name = collection_name
            
            # 如果embeddings未初始化，需要先初始化
            if self.embeddings is None:
                logger.info("正在初始化embeddings模型...")
                self.embeddings = OpenAIEmbeddings(
                    base_url=self.api_base,
                    api_key=self.api_key,
                    model=self.embedding_model,
                )
            
            # 重新创建 vectorstore（使用已有的 embeddings，无需重新加载模型）
            self.vectorstore = Chroma(
                persist_directory=self.chromadb_dir,
                collection_name=self.collection_name,
                embedding_function=self.embeddings,
            )
        
        # 重新构建 chain（因为 retriever 变了）
        self._build_chain()
        
        if collection_name is None:
            logger.info("知识库已禁用（将不使用RAG功能）")
        else:
            logger.info(f"知识库已切换到: {collection_name}")


# 便捷函数：创建对话实例
def create_dialogue(
    chromadb_dir: Optional[str] = None,
    collection_name: str = CAE_COLLECTION,
    api_base: str = CHAT_API_BASE_URL,
    api_key: str = CHAT_API_KEY,
    chat_model: str = CHAT_MODEL,
    embedding_model: str = EMBEDDING_MODEL,
    prompt_template: Optional[str] = None,
    search_k: int = 5,
    user_id: Optional[str] = None,
    conversation_id: Optional[str] = None,
    stream: bool = True,
    enable_rerank: bool = False,
    rerank_model: str = "BAAI/bge-reranker-large",
    rerank_top_k: int = 2,
    rerank_relative_threshold: float = 0.9,
    rerank_absolute_threshold: Optional[float] = 0.8,
    rerank_max_count: int = 5,
) -> Dialogue:
    """
    便捷函数：创建并初始化对话系统实例
    
    参数:
        chromadb_dir: ChromaDB向量数据库的持久化路径，如果为None则使用项目根目录下的Chromadb
        user_id: 用户ID，用于对话历史管理
        conversation_id: 会话ID，用于对话历史管理
        stream: 是否使用流式输出，默认为True
        enable_rerank: 是否启用rerank功能，默认为True
        rerank_model: rerank模型名称
        rerank_top_k: rerank后返回的最大文档数量（已弃用，保留用于兼容性）
        rerank_relative_threshold: rerank相对阈值（0.0-1.0），只选择分数>=最高分*该阈值的文档，默认为0.9
        rerank_absolute_threshold: rerank绝对阈值（可选），作为兜底，只选择分数>=该绝对阈值的文档
        rerank_max_count: rerank后返回的最大文档数量上限，默认为5
        其他参数同Dialogue.__init__
        
    返回:
        初始化完成的Dialogue实例
    """
    if chromadb_dir is None:
        chromadb_dir = CHROMADB_DIR
    
    return Dialogue(
        chromadb_dir=chromadb_dir,
        collection_name=collection_name,
        api_base=api_base,
        api_key=api_key,
        chat_model=chat_model,
        embedding_model=embedding_model,
        prompt_template=prompt_template,
        search_k=search_k,
        user_id=user_id,
        conversation_id=conversation_id,
        stream=stream,
        enable_rerank=enable_rerank,
        rerank_model=rerank_model,
        rerank_top_k=rerank_top_k,
        rerank_relative_threshold=rerank_relative_threshold,
        rerank_absolute_threshold=rerank_absolute_threshold,
        rerank_max_count=rerank_max_count,
    )


if __name__ == "__main__":
    # 持续对话示例
    print("\n【测试1】用户ID=123, 会话ID=123, 问题: '你好，我是xs!'")
    dialogue1 = create_dialogue(user_id="123", conversation_id="123")
    response1 = ''.join(dialogue1.chat("你好，我是xs!"))
    print(f"回答: {response1}")
