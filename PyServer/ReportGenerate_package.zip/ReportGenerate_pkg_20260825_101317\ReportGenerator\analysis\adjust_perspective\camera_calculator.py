"""
Camera view calculator for optimal visualization of 3D blocks.

Supports multiple bounding box types:
- AABB: Axis-Aligned Bounding Box
- OBB: Oriented Bounding Box
- MVBB: Minimum Volume Bounding Box
"""

import numpy as np
import vtk
from scipy.spatial import ConvexHull
from scipy.optimize import minimize


def get_block_points(block):
    """
    Extract points from a VTK data block as numpy array.
    
    Parameters:
    - block: VTK data object (PolyData or UnstructuredGrid)
    
    Returns:
    - points: Nx3 numpy array of point coordinates
    """
    if hasattr(block, 'GetPoints'):
        points_vtk = block.GetPoints()
        num_points = points_vtk.GetNumberOfPoints()
        points = np.zeros((num_points, 3))
        for i in range(num_points):
            points[i] = points_vtk.GetPoint(i)
        return points
    else:
        return np.zeros((0, 3))


def get_block_bounds(block):
    """
    Get the AABB bounds of a VTK data block.
    
    Parameters:
    - block: VTK data object (PolyData or UnstructuredGrid)
    
    Returns:
    - bounds: (xmin, xmax, ymin, ymax, zmin, zmax)
    """
    return block.GetBounds()


def compute_obb(points):
    """
    Compute Oriented Bounding Box using PCA.
    
    Parameters:
    - points: Nx3 numpy array of point coordinates
    
    Returns:
    - center: Center of OBB
    - axes: 3x3 array where each row is a principal axis (normalized)
    - extents: Half-sizes along each axis (3,)
    """
    if len(points) == 0:
        return np.zeros(3), np.eye(3), np.zeros(3)
    
    # Compute center
    center = np.mean(points, axis=0)
    
    # Center the points
    centered = points - center
    
    # Compute covariance matrix
    cov = np.cov(centered.T)
    
    # Eigen decomposition
    eigenvalues, eigenvectors = np.linalg.eigh(cov)
    
    # Sort by eigenvalues (descending)
    idx = eigenvalues.argsort()[::-1]
    axes = eigenvectors[:, idx].T
    
    # Ensure right-handed coordinate system
    if np.linalg.det(axes) < 0:
        axes[2] = -axes[2]
    
    # Project points onto principal axes to find extents
    projected = centered @ axes.T
    extents = np.max(np.abs(projected), axis=0)
    
    return center, axes, extents


def compute_mvbb(points):
    """
    Compute Minimum Volume Bounding Box using convex hull and rotation search.
    
    Parameters:
    - points: Nx3 numpy array of point coordinates
    
    Returns:
    - center: Center of MVBB
    - axes: 3x3 array where each row is a box axis (normalized)
    - extents: Half-sizes along each axis (3,)
    """
    if len(points) < 4:
        # Fall back to OBB for small point sets
        return compute_obb(points)
    
    try:
        # Compute convex hull
        hull = ConvexHull(points)
        hull_points = points[hull.vertices]
        
        # Start with OBB as initial guess
        _, obb_axes, _ = compute_obb(points)
        
        def compute_volume_for_rotation(rotation_matrix):
            """Compute bounding box volume for a given rotation."""
            # Rotate points
            rotated = points @ rotation_matrix.T
            # Compute axis-aligned bounds
            mins = np.min(rotated, axis=0)
            maxs = np.max(rotated, axis=0)
            dims = maxs - mins
            return np.prod(dims)
        
        # Try multiple rotations based on convex hull faces
        best_volume = float('inf')
        best_axes = obb_axes.copy()
        
        # Test OBB orientation
        volume = compute_volume_for_rotation(obb_axes)
        if volume < best_volume:
            best_volume = volume
            best_axes = obb_axes.copy()
        
        # Test orientations aligned with hull faces (sample a few)
        num_faces_to_test = min(20, len(hull.simplices))
        for i in range(0, len(hull.simplices), max(1, len(hull.simplices) // num_faces_to_test)):
            face_indices = hull.simplices[i]
            face_points = points[face_indices]
            
            # Compute face normal
            v1 = face_points[1] - face_points[0]
            v2 = face_points[2] - face_points[0]
            normal = np.cross(v1, v2)
            normal = normal / (np.linalg.norm(normal) + 1e-10)
            
            # Create rotation matrix with normal as one axis
            if abs(normal[2]) < 0.9:
                tangent = np.cross(normal, np.array([0, 0, 1]))
            else:
                tangent = np.cross(normal, np.array([0, 1, 0]))
            tangent = tangent / (np.linalg.norm(tangent) + 1e-10)
            
            binormal = np.cross(normal, tangent)
            binormal = binormal / (np.linalg.norm(binormal) + 1e-10)
            
            axes = np.vstack([tangent, binormal, normal])
            
            volume = compute_volume_for_rotation(axes)
            if volume < best_volume:
                best_volume = volume
                best_axes = axes.copy()
        
        # Compute final bounding box with best orientation
        rotated = points @ best_axes.T
        mins = np.min(rotated, axis=0)
        maxs = np.max(rotated, axis=0)
        center_rotated = (mins + maxs) / 2
        extents = (maxs - mins) / 2
        
        # Transform center back to original space
        center = center_rotated @ best_axes
        
        return center, best_axes, extents
        
    except Exception as e:
        print(f"Warning: MVBB computation failed ({e}), falling back to OBB")
        return compute_obb(points)


def compute_bounding_box(block, bbox_type='aabb'):
    """
    Compute bounding box for a block using specified method.
    
    Parameters:
    - block: VTK data object
    - bbox_type: Type of bounding box ('aabb', 'obb', 'mvbb')
    
    Returns:
    - center: Center of bounding box
    - axes: 3x3 rotation matrix (axes as rows), identity for AABB
    - extents: Half-sizes along each axis (3,)
    - bounds_tuple: (xmin, xmax, ymin, ymax, zmin, zmax) for compatibility
    """
    points = get_block_points(block)
    
    if bbox_type.lower() == 'aabb':
        # Axis-Aligned Bounding Box
        bounds = get_block_bounds(block)
        center = compute_block_center(bounds)
        axes = np.eye(3)  # Identity matrix for axis-aligned
        extents = np.array([
            (bounds[1] - bounds[0]) / 2,
            (bounds[3] - bounds[2]) / 2,
            (bounds[5] - bounds[4]) / 2
        ])
        return center, axes, extents, bounds
        
    elif bbox_type.lower() == 'obb':
        # Oriented Bounding Box
        center, axes, extents = compute_obb(points)
        # Compute bounds tuple (approximation using AABB of OBB)
        bounds = get_block_bounds(block)
        return center, axes, extents, bounds
        
    elif bbox_type.lower() == 'mvbb':
        # Minimum Volume Bounding Box
        center, axes, extents = compute_mvbb(points)
        # Compute bounds tuple (approximation using AABB of MVBB)
        bounds = get_block_bounds(block)
        return center, axes, extents, bounds
        
    else:
        raise ValueError(f"Unknown bounding box type: {bbox_type}. Use 'aabb', 'obb', or 'mvbb'.")


def compute_block_center(bounds):
    """
    Compute the center point of a bounding box.
    
    Parameters:
    - bounds: (xmin, xmax, ymin, ymax, zmin, zmax)
    
    Returns:
    - center: (x, y, z) center point
    """
    center = np.array([
        (bounds[0] + bounds[1]) / 2.0,
        (bounds[2] + bounds[3]) / 2.0,
        (bounds[4] + bounds[5]) / 2.0
    ])
    return center


def compute_block_diagonal(bounds):
    """
    Compute the diagonal length of a bounding box.
    
    Parameters:
    - bounds: (xmin, xmax, ymin, ymax, zmin, zmax)
    
    Returns:
    - diagonal: Length of the bounding box diagonal
    """
    dx = bounds[1] - bounds[0]
    dy = bounds[3] - bounds[2]
    dz = bounds[5] - bounds[4]
    diagonal = np.sqrt(dx**2 + dy**2 + dz**2)
    return diagonal


def compute_scene_bounds(all_blocks, bbox_type='aabb'):
    """
    Compute the bounding box of the entire scene (all blocks combined).
    For oriented boxes (OBB/MVBB), computes AABB of all oriented boxes combined.
    
    Parameters:
    - all_blocks: List of all blocks in the scene
    - bbox_type: Bounding box type ('aabb', 'obb', 'mvbb')
    
    Returns:
    - scene_bounds: (xmin, xmax, ymin, ymax, zmin, zmax) for entire scene
    - scene_center: Center point of the scene
    - scene_diagonal: Diagonal length of the scene bounding box
    """
    # Collect all points from all blocks to compute overall AABB
    all_points = []
    
    for block in all_blocks:
        if block is not None:
            if bbox_type.lower() == 'aabb':
                # For AABB, just use the bounds
                bounds = get_block_bounds(block)
                # Add corner points
                all_points.extend([
                    [bounds[0], bounds[2], bounds[4]],
                    [bounds[1], bounds[3], bounds[5]]
                ])
            else:
                # For OBB/MVBB, get the corner points in world space
                center, axes, extents, _ = compute_bounding_box(block, bbox_type)
                # Generate 8 corners of the oriented box
                corners = []
                for i in [-1, 1]:
                    for j in [-1, 1]:
                        for k in [-1, 1]:
                            local_corner = np.array([i, j, k]) * extents
                            # Transform to world space
                            world_corner = center + local_corner @ axes
                            corners.append(world_corner)
                all_points.extend(corners)
    
    # Convert to numpy array
    all_points = np.array(all_points)
    
    # Compute AABB of all points
    if len(all_points) > 0:
        mins = np.min(all_points, axis=0)
        maxs = np.max(all_points, axis=0)
        scene_bounds = (mins[0], maxs[0], mins[1], maxs[1], mins[2], maxs[2])
    else:
        scene_bounds = (0, 1, 0, 1, 0, 1)
    
    scene_center = compute_block_center(scene_bounds)
    scene_diagonal = compute_block_diagonal(scene_bounds)
    
    return scene_bounds, scene_center, scene_diagonal


def compute_block_principal_directions(block):
    """
    Compute principal directions of a block using PCA on its points.
    
    Parameters:
    - block: VTK data object
    
    Returns:
    - principal_dirs: 3x3 array where each row is a principal direction (sorted by variance)
    - center: Center point of the block
    """
    # Get points from block
    if hasattr(block, 'GetPoints'):
        points = block.GetPoints()
        num_points = points.GetNumberOfPoints()
        
        # Convert to numpy array
        points_array = np.zeros((num_points, 3))
        for i in range(num_points):
            points_array[i] = points.GetPoint(i)
        
        # Compute center
        center = np.mean(points_array, axis=0)
        
        # Center the points
        centered_points = points_array - center
        
        # Compute covariance matrix
        cov_matrix = np.cov(centered_points.T)
        
        # Compute eigenvalues and eigenvectors
        eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
        
        # Sort by eigenvalues (descending)
        idx = eigenvalues.argsort()[::-1]
        principal_dirs = eigenvectors[:, idx].T
        
        return principal_dirs, center
    else:
        # Fallback: use bounding box
        bounds = block.GetBounds()
        center = compute_block_center(bounds)
        # Default directions (axis-aligned)
        principal_dirs = np.eye(3)
        return principal_dirs, center


def evaluate_view_quality(view_direction, target_block, target_center, all_blocks, target_index, scene_center):
    """
    Evaluate the quality of a view direction for observing a target block.
    
    Parameters:
    - view_direction: Normalized viewing direction (from camera to target)
    - target_block: The block we want to observe
    - target_center: Center of the target block
    - all_blocks: List of all blocks in the scene
    - target_index: Index of the target block
    - scene_center: Center of the entire scene
    
    Returns:
    - score: Higher score means better view (considers occlusion and viewing angle)
    """
    score = 0.0
    
    # Get target block bounds
    target_bounds = get_block_bounds(target_block)
    target_size = compute_block_diagonal(target_bounds)
    
    # Factor 1: Prefer views that show the block from a good angle
    # (not too edge-on)
    target_dims = np.array([
        target_bounds[1] - target_bounds[0],
        target_bounds[3] - target_bounds[2],
        target_bounds[5] - target_bounds[4]
    ])
    
    # Compute projected area (rough approximation)
    projected_area = abs(view_direction[0] * target_dims[1] * target_dims[2]) + \
                     abs(view_direction[1] * target_dims[0] * target_dims[2]) + \
                     abs(view_direction[2] * target_dims[0] * target_dims[1])
    score += projected_area * 0.5
    
    # Factor 2: Penalize bottom-up views (looking from below)
    # Y-axis is typically up, so negative Y component means looking from below
    if view_direction[1] < -0.3:  # Looking significantly from below
        score -= abs(view_direction[1]) * 10.0  # Strong penalty
    
    # Factor 3: Prefer views from above or at eye level
    if view_direction[1] > 0.1:  # Looking from above or slightly elevated
        score += view_direction[1] * 2.0  # Bonus for elevated views
    
    # Factor 4: Penalize occlusion by other blocks
    for i, block in enumerate(all_blocks):
        if i == target_index or block is None:
            continue
        
        other_bounds = get_block_bounds(block)
        other_center = compute_block_center(other_bounds)
        
        # Vector from target to other block
        target_to_other = other_center - target_center
        distance = np.linalg.norm(target_to_other)
        
        if distance < 1e-6:
            continue
        
        target_to_other_normalized = target_to_other / distance
        
        # Check if other block is between camera and target
        # (i.e., if view direction is similar to target-to-other direction)
        alignment = np.dot(-view_direction, target_to_other_normalized)
        
        if alignment > 0.5:  # Other block is somewhat in the way
            # Penalize based on how much it occludes
            other_size = compute_block_diagonal(other_bounds)
            occlusion_penalty = alignment * (other_size / max(distance, 0.1))
            score -= occlusion_penalty * 2.0
    
    return score


def compute_adaptive_camera_position(target_block, target_center, target_extents, target_axes, 
                                    all_blocks, target_index, bbox_type='aabb'):
    """
    Adaptively compute the best camera position for viewing a specific block,
    while keeping the entire scene visible. Camera distance is based on scene size,
    and focal point is the scene center to ensure the whole model is in view.
    
    Parameters:
    - target_block: The block to observe
    - target_center: Center of the target block's bounding box
    - target_extents: Half-sizes of the target block's bounding box
    - target_axes: Axes of the target block's bounding box (3x3)
    - all_blocks: List of all blocks in the scene
    - target_index: Index of the target block
    - bbox_type: Bounding box type used ('aabb', 'obb', 'mvbb')
    
    Returns:
    - camera_position: (x, y, z) camera position
    - focal_point: (x, y, z) focal point (scene center for full model view)
    - view_up: (x, y, z) camera up vector
    """
    
    # Compute scene bounds to ensure entire model is visible
    scene_bounds, scene_center, scene_diagonal = compute_scene_bounds(all_blocks, bbox_type)
    
    # Use scene size for camera distance to show the entire model
    distance = scene_diagonal * 1.5  # 1.5x to ensure good framing
    
    # Use bounding box axes as principal directions
    # For OBB and MVBB, these are already oriented; for AABB, they're world axes
    principal_dirs = target_axes
    
    # Generate candidate viewing directions
    candidate_directions = []
    
    # Add bounding box axes and their negatives (but filter out bottom views)
    for pd in principal_dirs:
        dir_norm = pd / (np.linalg.norm(pd) + 1e-10)
        # Only add if not looking from below
        if dir_norm[1] > -0.5:  # Filter out strong bottom-up views
            candidate_directions.append(dir_norm)
        if (-dir_norm[1]) > -0.5:
            candidate_directions.append(-dir_norm)
    
    # Add some standard directions (excluding bottom)
    standard_dirs = [
        np.array([1, 0, 0]),   # right
        np.array([-1, 0, 0]),  # left
        np.array([0, 1, 0]),   # top (looking down)
        # Removed bottom view: np.array([0, -1, 0])
        np.array([0, 0, 1]),   # front
        np.array([0, 0, -1]),  # back
    ]
    candidate_directions.extend(standard_dirs)
    
    # Add isometric-style directions (only those with positive or neutral Y)
    isometric_dirs = [
        np.array([1, 1, 1]),
        np.array([1, 1, -1]),
        np.array([1, 0.5, 1]),   # Slightly elevated
        np.array([1, 0.5, -1]),
        np.array([-1, 1, 1]),
        np.array([-1, 1, -1]),
        np.array([-1, 0.5, 1]),
        np.array([-1, 0.5, -1]),
        np.array([0, 0.3, 1]),   # Slight elevation, front
        np.array([0, 0.3, -1]),  # Slight elevation, back
    ]
    for iso_dir in isometric_dirs:
        candidate_directions.append(iso_dir / np.linalg.norm(iso_dir))
    
    # Evaluate each candidate direction
    best_score = -np.inf
    best_direction = candidate_directions[0]
    
    for direction in candidate_directions:
        direction = direction / np.linalg.norm(direction)  # Ensure normalized
        score = evaluate_view_quality(direction, target_block, target_center, all_blocks, target_index, scene_center)
        
        if score > best_score:
            best_score = score
            best_direction = direction
    
    # Compute camera position from best direction
    # Position camera away from SCENE center (not just block center)
    # This ensures the entire model is visible
    camera_position = scene_center - best_direction * distance
    
    # Set focal point to scene center to keep entire model in view
    focal_point = scene_center
    
    # Compute view_up vector (perpendicular to viewing direction, prefer upward)
    if abs(best_direction[1]) < 0.9:  # Not looking straight up/down
        view_up = np.array([0, 1, 0])
        # Make sure view_up is perpendicular to view direction
        view_up = view_up - np.dot(view_up, best_direction) * best_direction
        view_up = view_up / np.linalg.norm(view_up)
    else:
        # Looking up or down, use a different up vector
        view_up = np.array([0, 0, 1])
        view_up = view_up - np.dot(view_up, best_direction) * best_direction
        view_up = view_up / np.linalg.norm(view_up)
    
    return camera_position, focal_point, view_up


def compute_bbox_size(extents, axes):
    """
    Compute the diagonal size of a bounding box.
    
    Parameters:
    - extents: Half-sizes along each axis (3,)
    - axes: 3x3 rotation matrix (axes as rows)
    
    Returns:
    - diagonal: Diagonal length of the bounding box
    """
    # Full dimensions
    dims = extents * 2.0
    diagonal = np.linalg.norm(dims)
    return diagonal


def compute_optimal_camera_position(center, extents, axes, view_direction='isometric'):
    """
    Compute optimal camera position for viewing a block with any bounding box type.
    
    Parameters:
    - center: Center point of the block (x, y, z)
    - extents: Half-sizes along each bounding box axis (3,)
    - axes: 3x3 rotation matrix where rows are bounding box axes
    - view_direction: Camera view direction ('isometric', 'front', 'top', etc.)
    
    Returns:
    - camera_position: (x, y, z) camera position
    - focal_point: (x, y, z) focal point (usually the center)
    - view_up: (x, y, z) camera up vector
    """
    diagonal = compute_bbox_size(extents, axes)
    distance = diagonal * 2.0  # Camera distance from center
    
    # Define view directions
    if view_direction == 'front':
        # View from front (negative Z direction)
        offset = np.array([0, 0, -distance])
        view_up = np.array([0, 1, 0])
    elif view_direction == 'back':
        # View from back (positive Z direction)
        offset = np.array([0, 0, distance])
        view_up = np.array([0, 1, 0])
    elif view_direction == 'top':
        # View from top (positive Y direction)
        offset = np.array([0, distance, 0])
        view_up = np.array([0, 0, -1])
    elif view_direction == 'bottom':
        # View from bottom (negative Y direction)
        offset = np.array([0, -distance, 0])
        view_up = np.array([0, 0, 1])
    elif view_direction == 'left':
        # View from left (negative X direction)
        offset = np.array([-distance, 0, 0])
        view_up = np.array([0, 1, 0])
    elif view_direction == 'right':
        # View from right (positive X direction)
        offset = np.array([distance, 0, 0])
        view_up = np.array([0, 1, 0])
    elif view_direction == 'isometric':
        # Isometric view (from an angle)
        angle = np.pi / 4  # 45 degrees
        offset = np.array([
            distance * np.cos(angle),
            distance * 0.5,
            distance * np.sin(angle)
        ])
        view_up = np.array([0, 1, 0])
    else:
        # Default to isometric
        angle = np.pi / 4
        offset = np.array([
            distance * np.cos(angle),
            distance * 0.5,
            distance * np.sin(angle)
        ])
        view_up = np.array([0, 1, 0])
    
    camera_position = center + offset
    focal_point = center
    
    return camera_position, focal_point, view_up


def compute_optimal_camera_views(multiblock_data, view_direction='adaptive', bbox_type='aabb'):
    """
    Compute optimal camera views for all blocks in a multiblock dataset.
    
    Parameters:
    - multiblock_data: VTK multiblock dataset
    - view_direction: Preferred view direction
                     'adaptive' (default): Automatically find best view avoiding occlusion
                     'isometric', 'front', 'top', 'bottom', 'left', 'right', 'back': Fixed views
    - bbox_type: Bounding box type ('aabb', 'obb', 'mvbb')
                'aabb': Axis-Aligned Bounding Box (fastest, default)
                'obb': Oriented Bounding Box (better for rotated objects)
                'mvbb': Minimum Volume Bounding Box (most accurate, slowest)
    
    Returns:
    - camera_views: Dictionary mapping block names to camera parameters
                    {block_name: {'position': (x,y,z), 'focal_point': (x,y,z), 'view_up': (x,y,z)}}
    """
    num_blocks = multiblock_data.GetNumberOfBlocks()
    camera_views = {}
    
    # Collect all blocks for adaptive mode
    all_blocks = []
    for i in range(num_blocks):
        all_blocks.append(multiblock_data.GetBlock(i))
    
    for i in range(num_blocks):
        block = multiblock_data.GetBlock(i)
        if block is not None:
            # Get block name (or use index if no name is set)
            block_name = multiblock_data.GetMetaData(i).Get(vtk.vtkCompositeDataSet.NAME())
            if not block_name:
                block_name = f"part_{i}"
            
            # Compute bounding box using specified method
            center, axes, extents, bounds = compute_bounding_box(block, bbox_type)
            
            # Compute optimal camera position
            if view_direction == 'adaptive':
                # Use adaptive algorithm considering all blocks
                camera_position, focal_point, view_up = compute_adaptive_camera_position(
                    block, center, extents, axes, all_blocks, i, bbox_type
                )
            else:
                # Use predefined view direction
                camera_position, focal_point, view_up = compute_optimal_camera_position(
                    center, extents, axes, view_direction
                )
            
            # Store camera parameters
            camera_views[block_name] = {
                'position': tuple(camera_position),
                'focal_point': tuple(focal_point),
                'view_up': tuple(view_up),
                'block_index': i
            }
    
    return camera_views


def compute_multiblock_bounds(multiblock_data):
    """
    Compute the overall bounding box of a multiblock dataset.
    
    Parameters:
    - multiblock_data: VTK multiblock dataset
    
    Returns:
    - bounds: Tuple of (xmin, xmax, ymin, ymax, zmin, zmax)
    """
    num_blocks = multiblock_data.GetNumberOfBlocks()
    
    overall_bounds = [float('inf'), float('-inf'), float('inf'), float('-inf'), float('inf'), float('-inf')]
    
    for i in range(num_blocks):
        block = multiblock_data.GetBlock(i)
        if block is not None:
            block_bounds = block.GetBounds()
            overall_bounds[0] = min(overall_bounds[0], block_bounds[0])
            overall_bounds[1] = max(overall_bounds[1], block_bounds[1])
            overall_bounds[2] = min(overall_bounds[2], block_bounds[2])
            overall_bounds[3] = max(overall_bounds[3], block_bounds[3])
            overall_bounds[4] = min(overall_bounds[4], block_bounds[4])
            overall_bounds[5] = max(overall_bounds[5], block_bounds[5])
    
    return tuple(overall_bounds)


def compute_eight_views(bounds):
    """
    Compute camera parameters for 8 standard views of a model.
    
    Parameters:
    - bounds: Tuple of (xmin, xmax, ymin, ymax, zmin, zmax)
    
    Returns:
    - views: Dictionary mapping view names to camera parameters
    """
    # Calculate center and size
    center = np.array([
        (bounds[0] + bounds[1]) / 2,
        (bounds[2] + bounds[3]) / 2,
        (bounds[4] + bounds[5]) / 2
    ])
    
    size = np.array([
        bounds[1] - bounds[0],
        bounds[3] - bounds[2],
        bounds[5] - bounds[4]
    ])
    
    # Distance from center (should be large enough to see the whole model)
    distance = max(size) * 2.5
    
    # Define 8 standard views
    views = {
        'front': {
            'position': tuple(center + np.array([0, -distance, 0])),
            'focal_point': tuple(center),
            'view_up': (0, 0, 1)
        },
        'back': {
            'position': tuple(center + np.array([0, distance, 0])),
            'focal_point': tuple(center),
            'view_up': (0, 0, 1)
        },
        'left': {
            'position': tuple(center + np.array([-distance, 0, 0])),
            'focal_point': tuple(center),
            'view_up': (0, 0, 1)
        },
        'right': {
            'position': tuple(center + np.array([distance, 0, 0])),
            'focal_point': tuple(center),
            'view_up': (0, 0, 1)
        },
        'top': {
            'position': tuple(center + np.array([0, 0, distance])),
            'focal_point': tuple(center),
            'view_up': (0, 1, 0)
        },
        'bottom': {
            'position': tuple(center + np.array([0, 0, -distance])),
            'focal_point': tuple(center),
            'view_up': (0, -1, 0)
        },
        'isometric': {
            'position': tuple(center + np.array([distance, -distance, distance]) / np.sqrt(3)),
            'focal_point': tuple(center),
            'view_up': (0, 0, 1)
        },
        'isometric_back': {
            'position': tuple(center + np.array([-distance, distance, distance]) / np.sqrt(3)),
            'focal_point': tuple(center),
            'view_up': (0, 0, 1)
        }
    }
    
    return views


def compute_eight_views_for_multiblock(multiblock_data):
    """
    Compute camera parameters for 8 standard views of a multiblock dataset.
    This is a convenience function that computes bounds and camera views in one call.
    
    Parameters:
    - multiblock_data: VTK multiblock dataset
    
    Returns:
    - camera_views: Dictionary mapping view names to camera parameters
                    {view_name: {'position': (x,y,z), 'focal_point': (x,y,z), 'view_up': (x,y,z)}}
    """
    # Compute overall bounds
    bounds = compute_multiblock_bounds(multiblock_data)
    
    # Compute 8 standard camera views
    camera_views = compute_eight_views(bounds)
    
    return camera_views


def apply_camera_view(camera, camera_params):
    """
    Apply camera parameters to a VTK camera.
    
    Parameters:
    - camera: VTK camera object
    - camera_params: Dictionary with 'position', 'focal_point', 'view_up'
    """
    camera.SetPosition(camera_params['position'])
    camera.SetFocalPoint(camera_params['focal_point'])
    camera.SetViewUp(camera_params['view_up'])


def analyze_block_geometry_from_points(points, bounds):
    """
    Analyze block geometry using PCA to determine optimal viewing directions.
    
    Parameters:
    - points: Nx3 numpy array of point coordinates
    - bounds: Tuple of (xmin, xmax, ymin, ymax, zmin, zmax)
    
    Returns:
    - result: Dictionary with 'optimal_views' (list of view names) and 'shape_type' (str)
    """
    try:
        from sklearn.decomposition import PCA
        
        if len(points) < 3:
            return {'optimal_views': ['isometric', 'front', 'side'], 'shape_type': 'small'}

        pca = PCA(n_components=3)
        pca.fit(points)
        explained_variance = pca.explained_variance_ratio_
        eigenvectors = pca.components_

        dimensions = [bounds[1] - bounds[0], bounds[3] - bounds[2], bounds[5] - bounds[4]]
        max_dim = max(dimensions)
        min_dim = min(dimensions)
        aspect_ratio = max_dim / min_dim if min_dim > 0 else 10

        if aspect_ratio > 5:
            shape_type = 'elongated'
        elif aspect_ratio > 2:
            shape_type = 'extended'
        elif explained_variance[0] > 0.8:
            shape_type = 'planar'
        else:
            shape_type = 'complex'

        optimal_views = []
        is_circular = (explained_variance[0] > 0.7 and explained_variance[1] > 0.7) or \
                     (aspect_ratio < 2.0 and explained_variance[0] > 0.6)

        if is_circular:
            optimal_views.extend(['side', 'isometric', 'front', 'rear'])
        else:
            primary_dir = eigenvectors[2]
            optimal_views.append(vector_to_view_name(primary_dir))

            if shape_type == 'planar':
                optimal_views.extend(['top', 'side'])
            elif shape_type == 'elongated':
                secondary_dir = eigenvectors[0]
                optimal_views.append(vector_to_view_name(secondary_dir))
                optimal_views.append('isometric')
            else:
                optimal_views.extend(['isometric', 'front', 'side'])

        optimal_views = list(dict.fromkeys(optimal_views))
        if len(optimal_views) < 3:
            for view in ['isometric', 'front', 'side', 'top']:
                if view not in optimal_views and len(optimal_views) < 4:
                    optimal_views.append(view)

        return {'optimal_views': optimal_views[:4], 'shape_type': shape_type}

    except Exception as e:
        print(f"Warning: Geometry analysis failed: {str(e)}, using default views")
        return {'optimal_views': ['isometric', 'front', 'side'], 'shape_type': 'unknown'}


def vector_to_view_name(direction):
    """
    Convert direction vector to view name.
    
    Parameters:
    - direction: 3D direction vector (numpy array)
    
    Returns:
    - view_name: String name of the view ('front', 'rear', 'left', 'right', 'top', 'bottom', 'isometric')
    """
    direction = direction / (np.linalg.norm(direction) + 1e-10)
    views = {
        'front': np.array([0, -1, 0]), 
        'rear': np.array([0, 1, 0]), 
        'left': np.array([-1, 0, 0]), 
        'right': np.array([1, 0, 0]),
        'top': np.array([0, 0, 1]), 
        'bottom': np.array([0, 0, -1]), 
        'isometric': np.array([1, -1, 1]) / np.sqrt(3)
    }

    best_view = 'isometric'
    best_dot = -1
    for view_name, view_dir in views.items():
        dot_product = abs(np.dot(direction, view_dir))
        if dot_product > best_dot:
            best_dot = dot_product
            best_view = view_name
    return best_view


def compute_isometric_view_from_bounds(bounds, distance_factor=2.5):
    """
    Compute isometric camera view from bounds.
    
    Parameters:
    - bounds: Tuple of (xmin, xmax, ymin, ymax, zmin, zmax)
    - distance_factor: Multiplier for distance calculation (default: 2.5)
    
    Returns:
    - camera_params: Dictionary with 'position', 'focal_point', 'view_up'
    """
    center = compute_block_center(bounds)
    size = np.array([
        bounds[1] - bounds[0],
        bounds[3] - bounds[2],
        bounds[5] - bounds[4]
    ])
    distance = max(size) * distance_factor
    
    return {
        'position': tuple(center + np.array([1.5, -1.5, 1.0]) / np.sqrt(3) * distance),
        'focal_point': tuple(center),
        'view_up': (0, 0, 1)
    }


def evaluate_context_view_quality(view_direction, target_block, target_center, target_size, 
                                  all_blocks, target_index, scene_center, scene_diagonal):
    """
    Evaluate the quality of a context view direction for observing a target block in the full scene.
    Optimized for showing both the complete model and maximizing target block visibility.
    
    Parameters:
    - view_direction: Normalized viewing direction (from camera to scene)
    - target_block: The block we want to observe
    - target_center: Center of the target block
    - target_size: Size (diagonal) of the target block
    - all_blocks: List of all blocks in the scene
    - target_index: Index of the target block
    - scene_center: Center of the entire scene
    - scene_diagonal: Diagonal size of the scene
    
    Returns:
    - score: Higher score means better view
    """
    score = 0.0
    
    # Get target block bounds
    target_bounds = get_block_bounds(target_block)
    target_dims = np.array([
        target_bounds[1] - target_bounds[0],
        target_bounds[3] - target_bounds[2],
        target_bounds[5] - target_bounds[4]
    ])
    
    # Factor 1: Maximize projected area of target block
    # For elongated vertical parts, prefer side views
    dims_sorted = sorted(target_dims, reverse=True)
    aspect_ratio = dims_sorted[0] / max(dims_sorted[1], 1e-6) if dims_sorted[1] > 0 else 10.0
    long_axis_idx = np.argmax(target_dims)
    
    if aspect_ratio > 3.0 and long_axis_idx == 1:  # Very elongated vertical (like air curtain)
        # For vertical fins, prefer side views (perpendicular to vertical axis)
        vertical_axis = np.array([0, 1, 0])
        perp_alignment = 1.0 - abs(np.dot(view_direction, vertical_axis))
        projected_area = perp_alignment * max(target_dims) * np.mean(target_dims[1:])
        score += projected_area * 3.0  # Strong bonus for side views of vertical parts
    else:
        # Standard projected area calculation
        projected_area = abs(view_direction[0] * target_dims[1] * target_dims[2]) + \
                         abs(view_direction[1] * target_dims[0] * target_dims[2]) + \
                         abs(view_direction[2] * target_dims[0] * target_dims[1])
        score += projected_area * 2.0  # Increased weight
    
    # Factor 2: Prefer views that make target block appear larger relative to scene
    # Small blocks need more emphasis
    size_ratio = target_size / max(scene_diagonal, 1e-6)
    if size_ratio < 0.1:  # Small block - needs more emphasis
        score += (1.0 - size_ratio) * 5.0
    
    # Factor 3: Penalize bottom-up views
    if view_direction[1] < -0.3:
        score -= abs(view_direction[1]) * 10.0
    
    # Factor 4: Prefer elevated views
    if view_direction[1] > 0.1:
        score += view_direction[1] * 3.0
    
    # Factor 5: Check if target block is well-positioned in view
    # Camera position (approximate)
    distance = scene_diagonal * 2.5
    camera_pos = scene_center - view_direction * distance
    view_to_block = target_center - camera_pos
    view_to_block_norm = view_to_block / (np.linalg.norm(view_to_block) + 1e-10)
    alignment = np.dot(-view_direction, view_to_block_norm)
    score += alignment * 5.0  # Strong bonus for good alignment
    
    # Factor 6: For small blocks, prefer views where block is near center of view
    # This helps AI focus on the small part
    if size_ratio < 0.15:
        # Calculate how close block center is to view center
        # View center is approximately at scene_center
        block_offset = target_center - scene_center
        block_offset_norm = np.linalg.norm(block_offset)
        if block_offset_norm > 0:
            # Prefer views where block is visible but not too far from center
            # This helps small parts stand out
            center_score = 1.0 / (1.0 + block_offset_norm / scene_diagonal)
            score += center_score * 3.0
        
        # For very small vertical parts, add extra bonus for side views
        if aspect_ratio > 3.0 and long_axis_idx == 1:  # Very elongated vertical
            vertical_axis = np.array([0, 1, 0])
            perp_to_vertical = 1.0 - abs(np.dot(view_direction, vertical_axis))
            score += perp_to_vertical * 5.0  # Strong bonus for side views
    
    # Factor 7: Penalize occlusion by other blocks
    for i, block in enumerate(all_blocks):
        if i == target_index or block is None:
            continue
        
        other_bounds = get_block_bounds(block)
        other_center = compute_block_center(other_bounds)
        other_size = compute_block_diagonal(other_bounds)
        
        # Vector from target to other block
        target_to_other = other_center - target_center
        distance_to_other = np.linalg.norm(target_to_other)
        
        if distance_to_other < 1e-6:
            continue
        
        target_to_other_norm = target_to_other / distance_to_other
        
        # Check if other block occludes target from this view
        occlusion_alignment = np.dot(-view_direction, target_to_other_norm)
        
        if occlusion_alignment > 0.3:  # Other block is in the way
            occlusion_penalty = occlusion_alignment * (other_size / max(distance_to_other, 0.1))
            score -= occlusion_penalty * 3.0
    
    return score


def compute_context_view_for_block(block, block_index, multiblock_data, distance_factor=2.5):
    """
    Compute optimal context view that shows the complete model while maximizing visibility of the target block.
    This view helps AI understand the block's position in the overall model.
    
    Parameters:
    - block: VTK block object (target block to highlight)
    - block_index: Index of the target block
    - multiblock_data: VTK multiblock dataset (complete model)
    - distance_factor: Multiplier for camera distance (default: 2.5)
    
    Returns:
    - camera_params: Dictionary with 'position', 'focal_point', 'view_up'
    """
    # Get block bounds and center
    block_bounds = get_block_bounds(block)
    block_center = compute_block_center(block_bounds)
    block_size = compute_block_diagonal(block_bounds)
    
    # Compute overall model bounds
    model_bounds = compute_multiblock_bounds(multiblock_data)
    model_center = compute_block_center(model_bounds)
    model_diagonal = compute_block_diagonal(model_bounds)
    
    # Collect all blocks
    all_blocks = []
    num_blocks = multiblock_data.GetNumberOfBlocks()
    for i in range(num_blocks):
        all_blocks.append(multiblock_data.GetBlock(i))
    
    # Use model size for camera distance to ensure full model visibility
    distance = model_diagonal * distance_factor
    
    # Generate candidate viewing directions that maximize target block visibility
    candidate_directions = []
    
    # Use block's principal directions (from PCA or bounding box)
    principal_dirs, _ = compute_block_principal_directions(block)
    for pd in principal_dirs:
        dir_norm = pd / (np.linalg.norm(pd) + 1e-10)
        # Avoid bottom-up views
        if dir_norm[1] > -0.3:
            candidate_directions.append(dir_norm)
        if (-dir_norm[1]) > -0.3:
            candidate_directions.append(-dir_norm)
    
    # Add directions that show block relative to its position in model
    block_to_model = model_center - block_center
    block_dims = np.array([
        block_bounds[1] - block_bounds[0],
        block_bounds[3] - block_bounds[2],
        block_bounds[5] - block_bounds[4]
    ])
    dims_sorted = sorted(block_dims, reverse=True)
    aspect_ratio = dims_sorted[0] / max(dims_sorted[1], 1e-6) if dims_sorted[1] > 0 else 10.0
    long_axis_idx = np.argmax(block_dims)
    
    if np.linalg.norm(block_to_model) > 1e-6:
        block_to_model_norm = block_to_model / np.linalg.norm(block_to_model)
        # Directions perpendicular to block-to-model vector show block in context
        if abs(block_to_model_norm[1]) < 0.9:
            perp1 = np.cross(block_to_model_norm, np.array([0, 1, 0]))
            perp1 = perp1 / (np.linalg.norm(perp1) + 1e-10)
            candidate_directions.append(perp1)
            candidate_directions.append(-perp1)
            # Also add slightly angled versions
            angled1 = (perp1 + block_to_model_norm * 0.3) / np.linalg.norm(perp1 + block_to_model_norm * 0.3)
            candidate_directions.append(angled1)
            candidate_directions.append(-angled1)
    
    # For very elongated vertical parts, add specific side-view directions
    if aspect_ratio > 3.0 and long_axis_idx == 1:  # Very elongated vertical (like air curtain)
        # Add side views that clearly show the vertical feature
        side_views = [
            np.array([1, 0.3, 0]),    # Side view from X
            np.array([-1, 0.3, 0]),   # Side view from -X
            np.array([0, 0.3, 1]),    # Side view from Z
            np.array([0, 0.3, -1]),   # Side view from -Z
            np.array([0.7, 0.4, 0.7]),  # Angled side view
            np.array([-0.7, 0.4, 0.7]), # Angled side view
        ]
        for sv in side_views:
            candidate_directions.append(sv / np.linalg.norm(sv))
    
    # Add more isometric-style directions with emphasis on showing small blocks
    isometric_dirs = [
        np.array([1, 0.8, 1]),
        np.array([1, 0.8, -1]),
        np.array([-1, 0.8, 1]),
        np.array([-1, 0.8, -1]),
        np.array([1, 0.6, 0]),
        np.array([-1, 0.6, 0]),
        np.array([0, 0.6, 1]),
        np.array([0, 0.6, -1]),
        np.array([1, 0.4, 0.5]),
        np.array([-1, 0.4, 0.5]),
        np.array([0.5, 0.7, 1]),
        np.array([-0.5, 0.7, 1]),
    ]
    for iso_dir in isometric_dirs:
        candidate_directions.append(iso_dir / np.linalg.norm(iso_dir))
    
    # For small blocks, add more directions that might show them better
    if block_size / model_diagonal < 0.15:  # Small block
        # Analyze block shape to determine best viewing angles
        block_dims = np.array([
            block_bounds[1] - block_bounds[0],
            block_bounds[3] - block_bounds[2],
            block_bounds[5] - block_bounds[4]
        ])
        dims_sorted = sorted(block_dims, reverse=True)
        if dims_sorted[0] > 0:
            aspect_ratio = dims_sorted[0] / max(dims_sorted[1], 1e-6)
            
            # For elongated/vertical parts (like air curtain), prefer side views
            if aspect_ratio > 3.0:  # Very elongated (likely vertical fin)
                # Add side views that show the long dimension
                long_axis_idx = np.argmax(block_dims)
                if long_axis_idx == 1:  # Vertical (Y-axis)
                    # Prefer views from side (X or Z direction) to show vertical feature
                    small_block_dirs = [
                        np.array([1, 0.4, 0]),   # Side view
                        np.array([-1, 0.4, 0]),  # Opposite side
                        np.array([0, 0.4, 1]),   # Front/back view
                        np.array([0, 0.4, -1]),   # Opposite front/back
                    ]
                else:
                    # Horizontal elongation
                    small_block_dirs = [
                        np.array([0.8, 0.6, 0.8]),
                        np.array([-0.8, 0.6, 0.8]),
                    ]
            else:
                # More compact small parts
                small_block_dirs = [
                    np.array([0.8, 0.5, 0.8]),
                    np.array([-0.8, 0.5, 0.8]),
                    np.array([0.8, 0.5, -0.8]),
                    np.array([-0.8, 0.5, -0.8]),
                ]
        else:
            small_block_dirs = [
                np.array([0.8, 0.5, 0.8]),
                np.array([-0.8, 0.5, 0.8]),
            ]
        
        for sbd in small_block_dirs:
            candidate_directions.append(sbd / np.linalg.norm(sbd))
    
    # Evaluate each candidate direction
    best_score = -np.inf
    best_direction = candidate_directions[0] if candidate_directions else np.array([1, 0.5, 1]) / np.sqrt(1.5**2 + 0.5**2 + 1)
    
    for direction in candidate_directions:
        direction = direction / (np.linalg.norm(direction) + 1e-10)
        score = evaluate_context_view_quality(
            direction, block, block_center, block_size, 
            all_blocks, block_index, model_center, model_diagonal
        )
        
        if score > best_score:
            best_score = score
            best_direction = direction
    
    # Compute camera position
    camera_position = model_center - best_direction * distance
    
    # Focal point is model center to keep entire model in view
    focal_point = model_center
    
    # Compute view_up vector
    if abs(best_direction[1]) < 0.9:
        view_up = np.array([0, 1, 0])
        view_up = view_up - np.dot(view_up, best_direction) * best_direction
        view_up = view_up / (np.linalg.norm(view_up) + 1e-10)
    else:
        view_up = np.array([0, 0, 1])
        view_up = view_up - np.dot(view_up, best_direction) * best_direction
        view_up = view_up / (np.linalg.norm(view_up) + 1e-10)
    
    return {
        'position': tuple(camera_position),
        'focal_point': tuple(focal_point),
        'view_up': tuple(view_up)
    }


def compute_pca_based_detail_views(block, max_views=3, distance_factor=2.5):
    """
    Compute optimal detail views for a block using PCA analysis with OBB-based camera positioning.
    Finds viewing directions that maximize the visible surface area and show distinctive features.
    Uses Oriented Bounding Box (OBB) for better focal point calculation.
    
    Parameters:
    - block: VTK block object
    - max_views: Maximum number of detail views (default: 3)
    - distance_factor: Multiplier for camera distance (default: 2.5)
    
    Returns:
    - detail_cameras: Dictionary mapping view names to camera parameters
                     {view_name: {'position': (x,y,z), 'focal_point': (x,y,z), 'view_up': (x,y,z)}}
    """
    points = get_block_points(block)
    block_bounds = get_block_bounds(block)
    
    # ʹ�� OBB�������Χ�У�����ȡ���õļ������ĺͳߴ�
    if len(points) >= 3:
        obb_center, obb_axes, obb_extents = compute_obb(points)
        # OBB �ĶԽ��߳�����Ϊ�������Ļ���
        obb_diagonal = 2.0 * np.sqrt(np.sum(obb_extents ** 2))
        # ʹ�� OBB ������Ϊ���㣨�������ģ�
        focus_center = obb_center
        distance = obb_diagonal * distance_factor
        # ʹ�� OBB extents ��Ϊ block_size�����ں������֣�
        block_size = 2.0 * obb_extents  # ת��Ϊȫ�ߴ�
    else:
        # Fallback to AABB for small point sets
        obb_center = compute_block_center(block_bounds)
        obb_axes = np.eye(3)
        obb_extents = np.array([
            (block_bounds[1] - block_bounds[0]) / 2,
            (block_bounds[3] - block_bounds[2]) / 2,
            (block_bounds[5] - block_bounds[4]) / 2
        ])
        focus_center = obb_center
        block_size = np.array([
            block_bounds[1] - block_bounds[0],
            block_bounds[3] - block_bounds[2],
            block_bounds[5] - block_bounds[4]
        ])
        distance = max(block_size) * distance_factor
    
    # Compute PCA
    try:
        from sklearn.decomposition import PCA
        pca = PCA(n_components=3)
        pca.fit(points)
        eigenvectors = pca.components_  # Principal directions
        eigenvalues = pca.explained_variance_  # Variance along each direction
    except ImportError:
        # Fallback to numpy PCA
        centered = points - np.mean(points, axis=0)
        cov = np.cov(centered.T)
        eigenvalues, eigenvectors = np.linalg.eigh(cov)
        idx = eigenvalues.argsort()[::-1]
        eigenvectors = eigenvectors[:, idx].T
    
    # Normalize eigenvalues for scoring
    total_variance = np.sum(eigenvalues)
    if total_variance > 0:
        eigenvalues = eigenvalues / total_variance
    
    # Generate candidate viewing directions based on PCA
    candidate_directions = []
    
    # Primary: Use principal directions (these show maximum variation)
    for i, eigenvec in enumerate(eigenvectors):
        dir_norm = eigenvec / (np.linalg.norm(eigenvec) + 1e-10)
        # Avoid bottom-up views
        if dir_norm[1] > -0.3:
            candidate_directions.append((dir_norm, eigenvalues[i] * 15.0, 'principal'))
        if (-dir_norm[1]) > -0.3:
            candidate_directions.append((-dir_norm, eigenvalues[i] * 15.0, 'principal'))
    
    # Secondary: Combinations of principal directions for better coverage
    if len(eigenvectors) >= 2:
        for i in range(len(eigenvectors)):
            for j in range(i+1, len(eigenvectors)):
                # Combine eigenvectors with weights based on variance
                combined = eigenvectors[i] * eigenvalues[i] + eigenvectors[j] * eigenvalues[j]
                combined = combined / (np.linalg.norm(combined) + 1e-10)
                if combined[1] > -0.3:
                    weight = (eigenvalues[i] + eigenvalues[j]) * 10.0
                    candidate_directions.append((combined, weight, 'combined'))
    
    # Tertiary: Perpendicular to principal directions (show cross-sections)
    if len(eigenvectors) >= 2:
        for i in range(len(eigenvectors)):
            for j in range(i+1, len(eigenvectors)):
                perp = np.cross(eigenvectors[i], eigenvectors[j])
                perp = perp / (np.linalg.norm(perp) + 1e-10)
                if perp[1] > -0.3:
                    weight = (eigenvalues[i] + eigenvalues[j]) * 8.0
                    candidate_directions.append((perp, weight, 'perpendicular'))
                    candidate_directions.append((-perp, weight, 'perpendicular'))
    
    # Quaternary: Isometric-style views for general coverage
    iso_dirs = [
        np.array([1, 0.7, 1]),
        np.array([1, 0.7, -1]),
        np.array([-1, 0.7, 1]),
        np.array([-1, 0.7, -1]),
        np.array([1, 0.5, 0]),
        np.array([-1, 0.5, 0]),
    ]
    for iso_dir in iso_dirs:
        iso_dir = iso_dir / np.linalg.norm(iso_dir)
        candidate_directions.append((iso_dir, 3.0, 'isometric'))
    
    # Score and select best directions
    scored_directions = []
    for direction, base_score, direction_type in candidate_directions:
        direction = direction / (np.linalg.norm(direction) + 1e-10)
        score = base_score
        
        # Penalize bottom views
        if direction[1] < 0:
            score -= abs(direction[1]) * 8.0
        
        # Bonus for elevated views (better for seeing details)
        if direction[1] > 0.3:
            score += direction[1] * 5.0
        
        # Bonus for principal directions (they show most variation)
        if direction_type == 'principal':
            score += 2.0
        
        # Consider block dimensions for optimal viewing angle
        # Prefer views that show distinctive features
        dims_sorted = sorted(block_size, reverse=True)
        if dims_sorted[0] > 0:
            aspect_ratio = dims_sorted[0] / max(dims_sorted[1], 1e-6)
            long_axis_idx = np.argmax(block_size)
            
            if aspect_ratio > 3.0:  # Very elongated block (like air curtain, thin vertical fin)
                # For very elongated blocks, prefer side views perpendicular to long axis
                axis_vec = np.zeros(3)
                axis_vec[long_axis_idx] = 1.0
                # Prefer views perpendicular to long axis (showing the cross-section)
                perp_alignment = 1.0 - abs(np.dot(direction, axis_vec))
                score += perp_alignment * 8.0  # Very strong bonus for side views
                
                # Extra bonus if it's a vertical part (Y-axis) and view is from side
                if long_axis_idx == 1:  # Vertical axis
                    vertical_axis = np.array([0, 1, 0])
                    perp_to_vertical = 1.0 - abs(np.dot(direction, vertical_axis))
                    score += perp_to_vertical * 4.0  # Additional bonus for side views of vertical parts
            elif aspect_ratio > 2.0:  # Moderately elongated block (like pillars)
                # For elongated blocks, prefer views that show the long dimension
                axis_vec = np.zeros(3)
                axis_vec[long_axis_idx] = 1.0
                alignment = abs(np.dot(direction, axis_vec))
                score += alignment * 4.0
            elif aspect_ratio < 1.3:  # Nearly circular/compact block (like wheel rim)
                # For circular/compact blocks, prefer views that show the center/face
                # Check if this is likely a wheel rim (circular, medium size)
                if dims_sorted[1] / max(dims_sorted[0], 1e-6) > 0.8:  # Nearly circular
                    # Prefer front/back views or slightly angled views
                    # These show the circular shape and center hub
                    if direction_type == 'principal' or direction_type == 'perpendicular':
                        score += 3.0
                    # Prefer views that show the face (not edge-on)
                    face_score = abs(direction[1])  # Y-component (vertical)
                    score += face_score * 2.0
            else:  # More compact block
                # For compact blocks, prefer isometric views that show multiple faces
                if direction_type == 'isometric' or direction_type == 'combined':
                    score += 2.0
        
        scored_directions.append((direction, score))
    
    # Sort by score and select diverse directions
    scored_directions.sort(key=lambda x: x[1], reverse=True)
    
    selected_directions = []
    min_angle_separation = 0.6  # Minimum angle between selected directions (cosine similarity)
    
    for direction, score in scored_directions:
        if len(selected_directions) >= max_views:
            break
        
        # Check diversity: ensure new direction is sufficiently different
        is_diverse = True
        for selected_dir, _ in selected_directions:
            similarity = abs(np.dot(direction, selected_dir))
            if similarity > (1.0 - min_angle_separation):
                is_diverse = False
                break
        
        if is_diverse:
            selected_directions.append((direction, score))
    
    # If we don't have enough diverse directions, fill with remaining best
    while len(selected_directions) < max_views and len(selected_directions) < len(scored_directions):
        for direction, score in scored_directions:
            if (direction, score) not in selected_directions:
                selected_directions.append((direction, score))
                break
    
    # Generate camera parameters for selected directions
    detail_cameras = {}
    for idx, (direction, _) in enumerate(selected_directions[:max_views], 1):
        camera_position = focus_center - direction * distance
        
        # Compute view_up vector
        if abs(direction[1]) < 0.9:
            view_up = np.array([0, 1, 0])
            view_up = view_up - np.dot(view_up, direction) * direction
            view_up = view_up / (np.linalg.norm(view_up) + 1e-10)
        else:
            view_up = np.array([0, 0, 1])
            view_up = view_up - np.dot(view_up, direction) * direction
            view_up = view_up / (np.linalg.norm(view_up) + 1e-10)
        
        detail_cameras[f'detail_{idx}'] = {
            'position': tuple(camera_position),
            'focal_point': tuple(focus_center),
            'view_up': tuple(view_up)
        }
    
    return detail_cameras


def compute_detail_views_for_block(block_center, block_bounds, view_names, distance_factor=2.5):
    """
    Compute detail camera views for a block from multiple viewing directions.
    (Legacy function, kept for compatibility)
    
    Parameters:
    - block_center: Center point of the block (x, y, z) as numpy array
    - block_bounds: Tuple of (xmin, xmax, ymin, ymax, zmin, zmax)
    - view_names: List of view names ('isometric', 'front', 'rear', 'side', 'top', etc.)
    - distance_factor: Multiplier for distance calculation (default: 2.5)
    
    Returns:
    - detail_cameras: Dictionary mapping view names to camera parameters
                     {view_name: {'position': (x,y,z), 'focal_point': (x,y,z), 'view_up': (x,y,z)}}
    """
    # View configurations (relative positions and view_up vectors)
    view_configs_base = {
        'isometric': {'position': (1.5, -1.5, 1.0), 'viewup': (0, 0, 1)},
        'front': {'position': (0, -2.5, 0.3), 'viewup': (0, 0, 1)},
        'rear': {'position': (0, 2.5, 0.3), 'viewup': (0, 0, 1)},
        'side': {'position': (2.5, 0, 0.3), 'viewup': (0, 0, 1)},
        'top': {'position': (0, 0, 2.5), 'viewup': (0, 1, 0)},
    }
    
    # Calculate block size and distance
    block_size = np.array([
        block_bounds[1] - block_bounds[0],
        block_bounds[3] - block_bounds[2],
        block_bounds[5] - block_bounds[4]
    ])
    block_distance = max(block_size) * distance_factor
    
    detail_cameras = {}
    for view_name in view_names:
        if view_name in view_configs_base:
            view_config = view_configs_base[view_name]
            # Scale position by block distance for close-up
            position = np.array(view_config['position']) * block_distance / 2.5
            detail_cameras[view_name] = {
                'position': tuple(block_center + position),
                'focal_point': tuple(block_center),
                'view_up': view_config['viewup']
            }
    
    return detail_cameras


def compute_block_rendering_views(block, block_index, multiblock_data, 
                                  auto_analyze_geometry=True, 
                                  default_views=None,
                                  context_distance_factor=2.5,
                                  detail_distance_factor=2.5,
                                  max_detail_views=3):
    """
    Compute all camera views for rendering a single block (context + detail views).
    This is a unified function that encapsulates all view calculations for a block.
    
    Parameters:
    - block: VTK block object to render
    - block_index: Index of the block in the multiblock dataset
    - multiblock_data: VTK multiblock dataset (for computing overall bounds)
    - auto_analyze_geometry: If True, automatically analyze block geometry using PCA to determine optimal views
    - default_views: List of default view names if auto_analyze_geometry is False or fails (not used if PCA is available)
                     (default: ['isometric', 'front', 'side'])
    - context_distance_factor: Distance factor for context view (default: 2.5)
    - detail_distance_factor: Distance factor for detail views (default: 2.5)
    - max_detail_views: Maximum number of detail views (default: 3)
    
    Returns:
    - camera_views: Dictionary mapping view names to camera parameters
                   {
                       'context_iso': {'position': (x,y,z), 'focal_point': (x,y,z), 'view_up': (x,y,z)},
                       'detail_1': {'position': (x,y,z), 'focal_point': (x,y,z), 'view_up': (x,y,z)},
                       'detail_2': {...},
                       'detail_3': {...},
                   }
    """
    if block is None:
        return {}
    
    # Initialize result dictionary
    camera_views = {}
    
    # 1. Compute context view (adaptive view showing complete model while maximizing target block visibility)
    try:
        context_view = compute_context_view_for_block(
            block, block_index, multiblock_data, context_distance_factor
        )
        camera_views['context_iso'] = context_view
    except Exception as e:
        print(f"Warning: Context view computation failed for block {block_index}: {str(e)}, using fallback")
        # Fallback to isometric view
        model_bounds = compute_multiblock_bounds(multiblock_data)
        context_view = compute_isometric_view_from_bounds(model_bounds, context_distance_factor)
        camera_views['context_iso'] = context_view
    
    # 2. Compute detail views using PCA-based analysis
    if auto_analyze_geometry:
        try:
            # For small blocks, use closer detail views
            block_bounds = get_block_bounds(block)
            block_size = compute_block_diagonal(block_bounds)
            model_bounds = compute_multiblock_bounds(multiblock_data)
            model_size = compute_block_diagonal(model_bounds)
            
            # Adjust distance factor for small blocks to get closer views
            adjusted_distance_factor = detail_distance_factor
            block_dims = np.array([
                block_bounds[1] - block_bounds[0],
                block_bounds[3] - block_bounds[2],
                block_bounds[5] - block_bounds[4]
            ])
            dims_sorted = sorted(block_dims, reverse=True)
            aspect_ratio = dims_sorted[0] / max(dims_sorted[1], 1e-6) if dims_sorted[1] > 0 else 10.0
            long_axis_idx = np.argmax(block_dims)
            
            if block_size / model_size < 0.15:  # Small block
                if aspect_ratio > 3.0 and long_axis_idx == 1:  # Very elongated vertical (like air curtain)
                    adjusted_distance_factor = detail_distance_factor * 0.4  # Very close for thin vertical parts
                elif aspect_ratio > 2.0:  # Elongated parts
                    adjusted_distance_factor = detail_distance_factor * 0.6
                else:
                    adjusted_distance_factor = detail_distance_factor * 0.7  # Closer view for small parts
            
            detail_cameras = compute_pca_based_detail_views(
                block, max_views=max_detail_views, distance_factor=adjusted_distance_factor
            )
            camera_views.update(detail_cameras)
        except Exception as e:
            print(f"Warning: PCA-based detail view computation failed for block {block_index}: {str(e)}, using fallback")
            # Fallback to simple views
            block_bounds = get_block_bounds(block)
            block_center = compute_block_center(block_bounds)
            block_size = np.array([
                block_bounds[1] - block_bounds[0],
                block_bounds[3] - block_bounds[2],
                block_bounds[5] - block_bounds[4]
            ])
            distance = max(block_size) * detail_distance_factor
            
            # Generate a few simple views
            simple_views = [
                (np.array([1, 0.6, 1]) / np.sqrt(1.36), 'detail_1'),
                (np.array([-1, 0.6, 1]) / np.sqrt(1.36), 'detail_2'),
                (np.array([0, 0.6, -1]) / np.sqrt(1.36), 'detail_3'),
            ]
            
            for direction, view_name in simple_views[:max_detail_views]:
                camera_position = block_center - direction * distance
                view_up = np.array([0, 1, 0])
                view_up = view_up - np.dot(view_up, direction) * direction
                view_up = view_up / (np.linalg.norm(view_up) + 1e-10)
                
                camera_views[view_name] = {
                    'position': tuple(camera_position),
                    'focal_point': tuple(block_center),
                    'view_up': tuple(view_up)
                }
    else:
        # Use default views (legacy mode)
        if default_views is None:
            default_views = ['isometric', 'front', 'side']
        
        block_bounds = get_block_bounds(block)
        block_center = compute_block_center(block_bounds)
        detail_cameras = compute_detail_views_for_block(
            block_center, block_bounds, default_views[:max_detail_views], detail_distance_factor
        )
        
        # Add 'detail_' prefix to detail view names
        for view_name, camera_params in detail_cameras.items():
            camera_views[f'detail_{view_name}'] = camera_params
    
    return camera_views

