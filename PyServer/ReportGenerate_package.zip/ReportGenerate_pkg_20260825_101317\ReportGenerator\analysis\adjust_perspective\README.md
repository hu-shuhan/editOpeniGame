# Camera Perspective Adjustment

This module provides functions to compute optimal camera views for 3D blocks in VTM files.

## Features

- **Automatic Camera Positioning**: Computes optimal camera position, focal point, and view-up vector for each block
- **Multiple Bounding Box Types**: Supports three methods for computing block bounds:
  - `aabb` (default): Axis-Aligned Bounding Box - fastest, good for general use
  - `obb`: Oriented Bounding Box - uses PCA for better fit on rotated objects
  - `mvbb`: Minimum Volume Bounding Box - most accurate, uses convex hull optimization
- **Multiple View Directions**: Supports different viewing angles:
  - `adaptive` (default): Automatically finds the best view angle for each block, considering:
    - Block geometry and bounding box orientation
    - Occlusion from other blocks
    - Projected area visibility
    - Avoids bottom-up views for natural appearance
  - `isometric`: Angled view (45 degrees)
  - `front`: View from the front (-Z direction)
  - `back`: View from the back (+Z direction)
  - `top`: View from above (+Y direction)
  - `bottom`: View from below (-Y direction)
  - `left`: View from the left (-X direction)
  - `right`: View from the right (+X direction)

## Usage

### In Code

```python
from adjust_perspective import compute_optimal_camera_views
from adjust_perspective.camera_calculator import apply_camera_view

# Compute camera views with adaptive mode and AABB (default, fastest)
camera_views = compute_optimal_camera_views(
    multiblock_data, 
    view_direction='adaptive', 
    bbox_type='aabb'
)

# Or use OBB for better handling of rotated objects
camera_views = compute_optimal_camera_views(
    multiblock_data, 
    view_direction='adaptive', 
    bbox_type='obb'
)

# Or use MVBB for maximum accuracy
camera_views = compute_optimal_camera_views(
    multiblock_data, 
    view_direction='adaptive', 
    bbox_type='mvbb'
)

# Or use a fixed direction with specific bbox type
camera_views = compute_optimal_camera_views(
    multiblock_data, 
    view_direction='isometric',
    bbox_type='obb'
)

# Apply camera view to a VTK camera
camera = renderer.GetActiveCamera()
apply_camera_view(camera, camera_views['block_name'])
```

### Integration with visualize_segmentation.py

This module is used by `visualize_segmentation.py` for per-block rendering. See the main visualization guide for command-line usage instructions.

## Camera Parameters

The `compute_optimal_camera_views` function returns a dictionary:

```python
{
    'block_name': {
        'position': (x, y, z),      # Camera position
        'focal_point': (x, y, z),   # Where camera looks at
        'view_up': (x, y, z),       # Camera up vector
        'block_index': int          # Block index in multiblock data
    }
}
```

## Algorithm

### Bounding Box Computation

Three methods are available for computing block bounding boxes:

1. **AABB (Axis-Aligned Bounding Box)**:
   - Compute min/max coordinates along world X, Y, Z axes
   - Fastest method, O(n) complexity
   - Identity rotation matrix

2. **OBB (Oriented Bounding Box)**:
   - Extract all points from the block mesh
   - Compute covariance matrix and perform PCA
   - Principal axes become box orientation
   - Project points onto axes to find extents
   - Better fit for rotated objects

3. **MVBB (Minimum Volume Bounding Box)**:
   - Compute convex hull of point cloud
   - Test multiple orientations (PCA + hull face normals)
   - Evaluate bounding box volume for each orientation
   - Select orientation with minimum volume
   - Most accurate but computationally expensive

### Fixed View Direction Mode (isometric, front, top, etc.)

1. **Compute Bounding Box**: Calculate bbox using specified type (AABB/OBB/MVBB)
2. **Extract Parameters**: Get center, axes, and extents from bounding box
3. **Calculate Distance**: Set camera distance based on bbox diagonal (2� diagonal)
4. **Position Camera**: Place camera at computed distance in the specified world direction
5. **Set Focal Point**: Point camera at the block center
6. **Define Up Vector**: Set appropriate up vector based on view direction

### Adaptive Mode (default)

The adaptive algorithm intelligently finds the best viewing angle for each block while keeping the entire model visible:

1. **Compute Bounding Box**: 
   - Calculate bounding box for target block using specified type (AABB/OBB/MVBB)
   - Extract center, orientation axes, and extents
   - For OBB/MVBB, orientation axes reflect the natural geometry

2. **Compute Scene Bounds**: 
   - Calculate bounding box of the entire scene (all blocks combined)
   - For OBB/MVBB, compute AABB of all oriented boxes combined
   - Use scene size to determine camera distance (1.5� scene diagonal)
   - Set focal point to scene center (ensures entire model is visible)

3. **Generate Candidate Views**:
   - **Bbox-aligned directions**: Use bounding box axes as candidates (especially effective for OBB/MVBB)
   - Standard orthogonal directions (front, back, left, right, top)
   - Isometric and elevated views with various angles
   - **Filtered**: Excludes bottom-up views and extreme low angles

4. **Evaluate Each Candidate**:
   - **Visibility Score**: Calculate projected area to prefer views showing more of the block
   - **View Angle Penalty**: Heavily penalize bottom-up views (looking from below)
   - **Elevation Bonus**: Prefer views from above or at eye level
   - **Occlusion Penalty**: Detect and penalize views where other blocks obstruct the target block

5. **Select Best View**:
   - Choose the direction with highest score (max visibility, min occlusion, good angle)
   - Position camera to show entire scene from optimal angle
   - Compute appropriate up vector perpendicular to viewing direction

This ensures each block is viewed from an angle that:
- **Shows the complete model** (not just the target block)
- **Respects block orientation** (OBB/MVBB provide better geometry-aware views)
- Provides a natural viewing angle (avoids looking from below)
- Maximizes visibility of the target block
- Minimizes obstruction from other parts

**Key Improvement**: Unlike focusing only on individual blocks, this approach maintains context by keeping the entire model visible, making it ideal for applications requiring full scene understanding (e.g., image recognition tasks).

**Bounding Box Impact**:
- **AABB**: Uses world-aligned axes, fastest but may not align with object geometry
- **OBB**: Candidate views aligned with principal axes, better for rotated objects
- **MVBB**: Views optimized for minimum volume orientation, best for complex shapes

